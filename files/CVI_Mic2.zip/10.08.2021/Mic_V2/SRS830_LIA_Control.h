// GPIB Control of SRS830 Lock-In ammplifier


#ifndef SRS830_LIA_INCLUDE
#define SRS830_LIA_INCLUDE

#ifdef __cplusplus
	extern "C" {
#endif
		
#include <gpib.h>

		
void SRS830_setup_LIA (int ParametersPanel);		
void SRS830_LIA_AutoPhase(void);
void SRS830_LIA_AutoOffset(void);
int SRS830_LIA_SendGPIB_cmd(char *cmd);
void SRS830_LIA_AutoSensitivity(void);
int SRS830_LIA_Read_V_Sensitivity_Setting(void) ;
double SRS830_Read_Sensitivity_Double(void);
void SRS830_Change_SensitivityBy(int SettingNumChange);
void SRS830_LIA_Set_Sensitivity(int NewSetting) ;
int SRS830_OverloadCheck(void);  
void SRS830_Clear_Status_Bits(void)  ;
#ifdef __cplusplus
	}
#endif

#endif // ifndef AOTF_INCLUDE
