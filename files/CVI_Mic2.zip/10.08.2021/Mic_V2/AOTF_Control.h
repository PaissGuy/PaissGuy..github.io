#ifndef AOTF_INCLUDE
#define AOTF_INCLUDE

#include <visa.h>
#include <windows.h> 

#ifdef __cplusplus
	extern "C" {
#endif

#define VIS 1
#define NIR 2
#define NIR2 3
#define MAX_AOTF_CMD_LEN 256
#define AOTF_DEV_NUM 3
		
		
//***** 	AOTF dll	*******
//define AOTF dll functions signature.
typedef int (*AOTFOPENCLOSE)(int);  //int AotfHandle = AOTFOpen(int deviceID=0/1/2/...)
typedef int (*AOTFSEND) (int, unsigned int, char*); //int status = AOTFWrite(AotfHandle, uint dataLength,  char *pData)

HINSTANCE hinstLib; 				   //handle to AOTF dll library.
AOTFOPENCLOSE AOTF_Open, AOTF_Close;   //Pointer to the dll functions. 
AOTFSEND AOTF_Send; 				   //Pointer to the dll functions. 

int hAOTF;

int AOTFInitLibrary(void);  //Load the AOTF dll and get proc address.
int AOTFCloseLibrary(void);	//Unload the AOTF dll. 
//**********************


int SetAOTF_IDs(int vis_id, int nir_id, int nir2_id);  
int AOTFSendStringCmd(char *cmd, int DevID);		
double Find_Freq_From_Wavelength_Dev(int aotf,int wavelength); 
int Set_AOTF_ALL_Zero(void);
int Set_AOTF_gain(int DevID, int chan, int gain) ;
int Set_AOTF_freq(int DevID, int chan ,double freq) ;
int Set_AOTF_freq_gain(int DevID, int chan ,double freq, int gain) ;
int GetAOTF_Power(int wavelength, int aotf_type, int MaxPower); 






#ifdef __cplusplus
	}
#endif

#endif // ifndef AOTF_INCLUDE
