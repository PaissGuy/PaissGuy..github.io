#include "MG17MO~1.h"
#include <userint.h>

static void CVIFUNC _DMG17MotorEventsRegOnMoveComplete_EventVTableFunc (void *thisPtr,
                                                                        long lChanID);

static void CVIFUNC _DMG17MotorEventsRegOnHomeComplete_EventVTableFunc (void *thisPtr,
                                                                        long lChanID);

static void CVIFUNC _DMG17MotorEventsRegOnMoveStopped_EventVTableFunc (void *thisPtr,
                                                                       long lChanID);

static void CVIFUNC _DMG17MotorEventsRegOnHWResponse_EventVTableFunc (void *thisPtr,
                                                                      long lHWCode,
                                                                      long lMsgIdent);

static void CVIFUNC _DMG17MotorEventsRegOnSettingsChanged_EventVTableFunc (void *thisPtr,
                                                                           long lFlags);

static void CVIFUNC _DMG17MotorEventsRegOnEncCalibComplete_EventVTableFunc (void *thisPtr,
                                                                            long lChanID);

static void CVIFUNC _DMG17MotorEventsRegOnPositionClick_EventVTableFunc (void *thisPtr,
                                                                         float fCurrentPosition);

static void CVIFUNC _DMG17MotorEventsRegOnPositionDblClick_EventVTableFunc (void *thisPtr,
                                                                            float fCurrentPosition);

#define __ActiveXCtrlErrorHandler() \
if ((ctrlId) > 0) \
	{ \
	if (controlID) \
		*controlID = (ctrlId); \
	if (UILError) \
		*UILError = 0; \
	__result = S_OK; \
	} \
else if ((ctrlId) == UIEActiveXError) \
	{ \
	if (controlID) \
		*controlID = 0; \
	if (UILError) \
		*UILError = 0; \
	} \
else \
	{ \
	if (controlID) \
		*controlID = 0; \
	if (UILError) \
		*UILError = (ctrlId); \
	__result = E_CVIAUTO_CVI_UI_ERROR; \
	}

static CA_PARAMDATA __DMG17MotorEvents_RegOnMoveComplete_CA_PARAMDATA[] =
	{
		{"lChanID", VT_I4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnHomeComplete_CA_PARAMDATA[] =
	{
		{"lChanID", VT_I4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnMoveStopped_CA_PARAMDATA[] =
	{
		{"lChanID", VT_I4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnHWResponse_CA_PARAMDATA[] =
	{
		{"lHWCode", VT_I4},
        {"lMsgIdent", VT_I4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnSettingsChanged_CA_PARAMDATA[] =
	{
		{"lFlags", VT_I4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnEncCalibComplete_CA_PARAMDATA[] =
	{
		{"lChanID", VT_I4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnPositionClick_CA_PARAMDATA[] =
	{
		{"fCurrentPosition", VT_R4}
	};

static CA_PARAMDATA __DMG17MotorEvents_RegOnPositionDblClick_CA_PARAMDATA[] =
	{
		{"fCurrentPosition", VT_R4}
	};

static CA_METHODDATA __DMG17MotorEvents_CA_METHODDATA[] =
	{
		{"MoveComplete", __DMG17MotorEvents_RegOnMoveComplete_CA_PARAMDATA, 2, 0, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY},
        {"HomeComplete", __DMG17MotorEvents_RegOnHomeComplete_CA_PARAMDATA, 3, 1, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY},
        {"MoveStopped", __DMG17MotorEvents_RegOnMoveStopped_CA_PARAMDATA, 4, 2, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY},
        {"HWResponse", __DMG17MotorEvents_RegOnHWResponse_CA_PARAMDATA, 5, 3, CC_STDCALL, 2, DISPATCH_METHOD, VT_EMPTY},
        {"SettingsChanged", __DMG17MotorEvents_RegOnSettingsChanged_CA_PARAMDATA, 6, 4, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY},
        {"EncCalibComplete", __DMG17MotorEvents_RegOnEncCalibComplete_CA_PARAMDATA, 9, 5, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY},
        {"PositionClick", __DMG17MotorEvents_RegOnPositionClick_CA_PARAMDATA, 10, 6, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY},
        {"PositionDblClick", __DMG17MotorEvents_RegOnPositionDblClick_CA_PARAMDATA, 11, 7, CC_STDCALL, 1, DISPATCH_METHOD, VT_EMPTY}
	};

static CA_INTERFACEDATA __DMG17MotorEvents_CA_INTERFACEDATA =
	{
		__DMG17MotorEvents_CA_METHODDATA,
        (unsigned int)(sizeof (__DMG17MotorEvents_CA_METHODDATA) / sizeof (*__DMG17MotorEvents_CA_METHODDATA))
	};

static void * __DMG17MotorEvents_EventVTable[] =
	{
		_DMG17MotorEventsRegOnMoveComplete_EventVTableFunc,
        _DMG17MotorEventsRegOnHomeComplete_EventVTableFunc,
        _DMG17MotorEventsRegOnMoveStopped_EventVTableFunc,
        _DMG17MotorEventsRegOnHWResponse_EventVTableFunc,
        _DMG17MotorEventsRegOnSettingsChanged_EventVTableFunc,
        _DMG17MotorEventsRegOnEncCalibComplete_EventVTableFunc,
        _DMG17MotorEventsRegOnPositionClick_EventVTableFunc,
        _DMG17MotorEventsRegOnPositionDblClick_EventVTableFunc
	};

static CAEventClassDefn __DMG17MotorEvents_CAEventClassDefn =
	{
		(int)sizeof(CAEventClassDefn),
        &MG17MotorLib_IID__DMG17MotorEvents,
        __DMG17MotorEvents_EventVTable,
        &__DMG17MotorEvents_CA_INTERFACEDATA,
        0
	};

const IID MG17MotorLib_IID__DMG17Motor =
	{
		0x83D03B54, 0xE1C4, 0x466F, 0x97, 0xA2, 0xCB, 0xBF, 0x33, 0x30, 0x92, 0x7A
	};

const IID MG17MotorLib_IID__DMG17MotorEvents =
	{
		0x641DF21F, 0x2956, 0x4F93, 0xB4, 0x42, 0x2C, 0xA5, 0x91, 0xC7, 0x36, 0x28
	};

HRESULT CVIFUNC MG17MotorLib_New_DMG17Motor (int panel, const char *label,
                                             int top, int left, int *controlID,
                                             int *UILError)
{
	HRESULT __result = S_OK;
	int ctrlId;
	GUID clsid = {0x3CE35BF3, 0x1E13, 0x4D2C, 0x8C, 0xB, 0xDE, 0xF6, 0x31,
	              0x44, 0x20, 0xB3};
	const char * licStr = NULL;

	ctrlId = NewActiveXCtrl (panel, label, top, left, &clsid,
	                         &MG17MotorLib_IID__DMG17Motor, licStr, &__result);

	__ActiveXCtrlErrorHandler();

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorAboutBox (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xFFFFFDD8,
	                              CAVT_EMPTY, NULL, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStartCtrl (CAObjHandle objectHandle,
                                                   ERRORINFO *errorInfo,
                                                   long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStopCtrl (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPosition (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lChanID,
                                                     float *pfPosition,
                                                     long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, pfPosition);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPosParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plPosControlMode,
                                                           long *plMicroStepDivider,
                                                           long *plPosStepRes,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              bSet, lChanID, plPosControlMode,
	                              plMicroStepDivider, plPosStepRes);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetVelParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plMinVel,
                                                           long *plAccn,
                                                           long *plMaxVel,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              bSet, lChanID, plMinVel, plAccn, plMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetJogParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plJogMode,
                                                           long *plJogStepSize,
                                                           long *plMinVel,
                                                           long *plAccn,
                                                           long *plMaxVel,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xD,
	                              CAVT_LONG, returnValue, 7, __paramTypes,
	                              bSet, lChanID, plJogMode, plJogStepSize,
	                              plMinVel, plAccn, plMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetLimSwitchParams (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 VBOOL bSet,
                                                                 long lChanID,
                                                                 long *plCWHardLimit,
                                                                 long *plCCWHardLimit,
                                                                 long *plCWSoftLimit,
                                                                 long *plCCWSoftLimit,
                                                                 long *plSoftLimitMode,
                                                                 long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xE,
	                              CAVT_LONG, returnValue, 7, __paramTypes,
	                              bSet, lChanID, plCWHardLimit, plCCWHardLimit,
	                              plCWSoftLimit, plCCWSoftLimit,
	                              plSoftLimitMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPowerParams (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             VBOOL bSet,
                                                             long lChanID,
                                                             long *plRestFactor,
                                                             long *plMoveFactor,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xF,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              bSet, lChanID, plRestFactor, plMoveFactor);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetHomeParams (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            VBOOL bSet,
                                                            long lChanID,
                                                            long *plDirection,
                                                            long *plLimSwitch,
                                                            long *plHomeVel,
                                                            long *plOffsetDist,
                                                            long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x10,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              bSet, lChanID, plDirection, plLimSwitch,
	                              plHomeVel, plOffsetDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetMoveRelParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               VBOOL bSet,
                                                               long lChanID,
                                                               long *plRelDist,
                                                               long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x11,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              bSet, lChanID, plRelDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetMoveAbsParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               VBOOL bSet,
                                                               long lChanID,
                                                               long *plAbsPos,
                                                               long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x12,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              bSet, lChanID, plAbsPos);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveVelocity (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long lDirection,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x16,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lDirection);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLMoveStop (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID, long lStopMode,
                                                    long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x17,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lStopMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLReqHWParams (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long lParamID,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x18,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lParamID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEnableHWChannel (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x19,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorDisableHWChannel (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x1A,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetDevParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long *plDevParams,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x1B,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              bSet, plDevParams);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveHome (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long lChanID, VBOOL bWait,
                                                  long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x1D,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStopImmediate (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x1E,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStopProfiled (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x1F,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveRelativeEx (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fRelDistCh1,
                                                        float fRelDistCh2,
                                                        VBOOL bWait,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x20,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, fRelDistCh1, fRelDistCh2, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsoluteEx (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fAbsPosCh1,
                                                        float fAbsPosCh2,
                                                        VBOOL bWait,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x21,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, fAbsPosCh1, fAbsPosCh2, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveRelative (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID, VBOOL bWait,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x22,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsolute (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID, VBOOL bWait,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x23,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetStatusBits (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *plStatusBits,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x24,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plStatusBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetGenMoveParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               VBOOL bSet,
                                                               long lChanID,
                                                               long *plBLashDist,
                                                               long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x25,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              bSet, lChanID, plBLashDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetVelParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float fMinVel, float fAccn,
                                                      float fMaxVel,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x26,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, fMinVel, fAccn, fMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float *pfMinVel,
                                                      float *pfAccn,
                                                      float *pfMaxVel,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x27,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, pfMinVel, pfAccn, pfMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxis (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      char **pbstrStageAxisName,
                                                      long *plStageID,
                                                      long *plAxisID,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_CSTRING | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x28,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, pbstrStageAxisName, plStageID,
	                              plAxisID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxisInfo (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          float *pfMinPos,
                                                          float *pfMaxPos,
                                                          long *plUnits,
                                                          float *pfPitch,
                                                          long *plDirSense,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x29,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, pfMinPos, pfMaxPos, plUnits,
	                              pfPitch, plDirSense);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParamLimits (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *pfMaxAccn,
                                                           float *pfMaxVel,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x2A,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, pfMaxAccn, pfMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetJogMode (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID, long lMode,
                                                    long lStopMode,
                                                    long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x2B,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lMode, lStopMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogMode (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID, long *plMode,
                                                    long *plStopMode,
                                                    long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x2C,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plMode, plStopMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetJogStepSize (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fStepSize,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x2D,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, fStepSize);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogStepSize (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float *pfStepSize,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x2E,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, pfStepSize);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetJogVelParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fMinVel,
                                                         float fAccn,
                                                         float fMaxVel,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x2F,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, fMinVel, fAccn, fMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogVelParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float *pfMinVel,
                                                         float *pfAccn,
                                                         float *pfMaxVel,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x30,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, pfMinVel, pfAccn, pfMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetRelMoveDist (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fRelDist,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x31,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, fRelDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetRelMoveDist (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float *pfRelDist,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x32,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, pfRelDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetAbsMovePos (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       float fAbsPos,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x33,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, fAbsPos);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetAbsMovePos (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       float *pfAbsPos,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x34,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, pfAbsPos);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetDigOPs (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bSet, long *plBits,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x36,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              bSet, plBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetDigIPs (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long *plBits,
                                                     long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x37,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              plBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetADCInputs (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long *plADCVal1,
                                                        long *plADCVal2,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x38,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              plADCVal1, plADCVal2);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetPosition (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plPosition,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x39,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plPosition);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetBLashDist (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float fBLashDist,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x3A,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, fBLashDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBLashDist (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float *pfBLashDist,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x3B,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, pfBLashDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorIdentify (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x3C,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetSWPosLimits (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fRevPosLimit,
                                                        float fFwdPosLimit,
                                                        long lLimitMode,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x3D,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, fRevPosLimit, fFwdPosLimit,
	                              lLimitMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetSWPosLimits (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float *pfRevPosLimit,
                                                        float *pfFwdPosLimit,
                                                        long *plLimitMode,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x3E,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, pfRevPosLimit, pfFwdPosLimit,
	                              plLimitMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetStageAxisInfo (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          float fMinPos,
                                                          float fMaxPos,
                                                          long lUnits,
                                                          float fPitch,
                                                          long lDirSense,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_LONG, CAVT_FLOAT, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x3F,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, fMinPos, fMaxPos, lUnits, fPitch,
	                              lDirSense);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSaveHWDefaults (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x40,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetHomeParams (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long lDirection,
                                                       long lLimSwitch,
                                                       float fHomeVel,
                                                       float fZeroOffset,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_FLOAT,
	                               CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x41,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, lDirection, lLimSwitch, fHomeVel,
	                              fZeroOffset);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHomeParams (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plDirection,
                                                       long *plLimSwitch,
                                                       float *pfHomeVel,
                                                       float *pfZeroOffset,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x42,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, plDirection, plLimSwitch, pfHomeVel,
	                              pfZeroOffset);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetHWLimSwitches (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lRevLimSwitch,
                                                          long lFwdLimSwitch,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x43,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lRevLimSwitch, lFwdLimSwitch);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHWLimSwitches (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plRevLimSwitch,
                                                          long *plFwdLimSwitch,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x44,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plRevLimSwitch, plFwdLimSwitch);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetPhaseCurrents (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lRestVal,
                                                          long lMoveVal,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x47,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lRestVal, lMoveVal);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPhaseCurrents (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plRestVal,
                                                          long *plMoveVal,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x48,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plRestVal, plMoveVal);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPositionEx (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       float *pfCalibPosition,
                                                       float *pfUncalibPosition,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x49,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, pfCalibPosition, pfUncalibPosition);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorDoEvents (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4A,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetEncoderCount (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long lEncCount,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4B,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lEncCount);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetEncoderCount (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long *plEncCount,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4C,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plEncCount);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetTrigBits (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          VBOOL bSet,
                                                          long lChanID,
                                                          long *plBits,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4D,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              bSet, lChanID, plBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveJog (CAObjHandle objectHandle,
                                                 ERRORINFO *errorInfo,
                                                 long lChanID, long lJogDir,
                                                 long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4E,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lJogDir);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetMotorParams (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        long lStepsPerRev,
                                                        long lGearBoxRatio,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4F,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lStepsPerRev, lGearBoxRatio);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetMotorParams (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        long *plStepsPerRev,
                                                        long *plGearBoxRatio,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x50,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plStepsPerRev, plGearBoxRatio);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetTriggerParams (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lTrigMode,
                                                          long lTrigMove,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x51,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lTrigMode, lTrigMove);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetTriggerParams (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plTrigMode,
                                                          long *plTrigMove,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x52,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plTrigMode, plTrigMove);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSaveParamSet (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      const char *bstrName,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_CSTRING};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x53,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bstrName);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLoadParamSet (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      const char *bstrName,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_CSTRING};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x54,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bstrName);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorDeleteParamSet (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        const char *btsrName,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_CSTRING};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x55,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              btsrName);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetDSPProgState (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bProg,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x56,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bProg);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSendDSPProgData (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lNumBytes,
                                                           unsigned char *lpbyData,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_UCHAR | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x57,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lNumBytes, lpbyData);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsoluteEnc (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fAbsPosCh1,
                                                         float fAbsPosCh2,
                                                         long lTimeInc,
                                                         VBOOL bWait,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x58,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, fAbsPosCh1, fAbsPosCh2, lTimeInc,
	                              bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveRelativeEnc (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fRelDistCh1,
                                                         float fRelDistCh2,
                                                         long lTimeInc,
                                                         VBOOL bWait,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x59,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, fRelDistCh1, fRelDistCh2, lTimeInc,
	                              bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorCalibrateEnc (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID, VBOOL bWait,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5A,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetEncCalibTableParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lEncCalib,
                                                                float fCalibStep,
                                                                long lCalibDwell,
                                                                long lQEPSense,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_FLOAT, CAVT_LONG,
	                               CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5B,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, lEncCalib, fCalibStep, lCalibDwell,
	                              lQEPSense);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetEncCalibTableParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plEncCalib,
                                                                float *pfCalibStep,
                                                                long *plCalibDwell,
                                                                long *plQEPSense,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5C,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, plEncCalib, pfCalibStep,
	                              plCalibDwell, plQEPSense);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetEncPosCorrectParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lPosSetPtWnd,
                                                                long lSnguStepWnd,
                                                                long lStopShortDist,
                                                                long lCorrMoveStep,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_LONG,
	                               CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5D,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, lPosSetPtWnd, lSnguStepWnd,
	                              lStopShortDist, lCorrMoveStep);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetEncPosCorrectParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plPosSetPtWnd,
                                                                long *plSnguStepWnd,
                                                                long *plStopShortDist,
                                                                long *plCorrMoveStep,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5E,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, plPosSetPtWnd, plSnguStepWnd,
	                              plStopShortDist, plCorrMoveStep);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetEncPosControlParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lPosSrcMode,
                                                                long lPosCorrMode,
                                                                VBOOL bUseCalib,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x5F,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, lPosSrcMode, lPosCorrMode,
	                              bUseCalib);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetEncPosControlParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plPosSrcMode,
                                                                long *plPosCorrMode,
                                                                VBOOL *pbUseCalib,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_BOOL | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x60,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, plPosSrcMode, plPosCorrMode,
	                              pbUseCalib);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetHostDigOPs (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            VBOOL bSet,
                                                            long *plBits,
                                                            long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x62,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              bSet, plBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetHostStatusBits (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long *plStatusBits,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x63,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              plStatusBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPIDParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plProp,
                                                           long *plInt,
                                                           long *plDeriv,
                                                           long *plIntLimit,
                                                           long *plFilterCtrl,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x64,
	                              CAVT_LONG, returnValue, 7, __paramTypes,
	                              bSet, lChanID, plProp, plInt, plDeriv,
	                              plIntLimit, plFilterCtrl);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetAdvancedDCParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long lChanID,
                                                               long *plTargetPos,
                                                               long *plTargetVel,
                                                               long *plIntSum,
                                                               long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x65,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, plTargetPos, plTargetVel, plIntSum);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPotParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plZeroWnd,
                                                           long *plVel1,
                                                           long *plWnd1,
                                                           long *plVel2,
                                                           long *plWnd2,
                                                           long *plVel3,
                                                           long *plWnd3,
                                                           long *plVel4,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x66,
	                              CAVT_LONG, returnValue, 10, __paramTypes,
	                              bSet, lChanID, plZeroWnd, plVel1, plWnd1,
	                              plVel2, plWnd2, plVel3, plWnd3, plVel4);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetIndicatorLEDMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long lLEDMode,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x67,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lLEDMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetIndicatorLEDMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long *plLEDMode,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x68,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plLEDMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetAVMode (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bSet, long lChanID,
                                                        long *plModeBits,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x69,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              bSet, lChanID, plModeBits);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetButtonParams (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              VBOOL bSet,
                                                              long lChanID,
                                                              long *plMode,
                                                              long *plPos1,
                                                              long *plPos2,
                                                              long *plTimeout1,
                                                              long *plTimeout2,
                                                              long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6A,
	                              CAVT_LONG, returnValue, 7, __paramTypes,
	                              bSet, lChanID, plMode, plPos1, plPos2,
	                              plTimeout1, plTimeout2);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetOptoDCVelParams (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              long *plMinVel,
                                                              long *plAccn,
                                                              long *plMaxVel,
                                                              long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6B,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, plMinVel, plAccn, plMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetOptoDCJogParams (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              long *plJogMode,
                                                              long *plJogStepSize,
                                                              long *plMinVel,
                                                              long *plAccn,
                                                              long *plMaxVel,
                                                              long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6C,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, plJogMode, plJogStepSize, plMinVel,
	                              plAccn, plMaxVel);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetOptoDCHomeParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long lChanID,
                                                               long *plDirection,
                                                               long *plLimSwitch,
                                                               long *plHomeVel,
                                                               long *plOffsetDist,
                                                               long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6D,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, plDirection, plLimSwitch, plHomeVel,
	                              plOffsetDist);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetParentHWInfo (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long *plHWSerialNum,
                                                         long *plHWType,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6E,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              plHWSerialNum, plHWType);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetButtonParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long lButMode,
                                                         float fLeftButPos,
                                                         float fRightButPos,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_FLOAT,
	                               CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x6F,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, lButMode, fLeftButPos, fRightButPos);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetButtonParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *plButMode,
                                                         float *pfLeftButPos,
                                                         float *pfRightButPos,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x70,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, plButMode, pfLeftButPos,
	                              pfRightButPos);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetPotParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long lVel1PotVal,
                                                      float fVel1,
                                                      long lVel2PotVal,
                                                      float fVel2,
                                                      long lVel3PotVal,
                                                      float fVel3,
                                                      long lVel4PotVal,
                                                      float fVel4,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_FLOAT, CAVT_LONG,
	                               CAVT_FLOAT, CAVT_LONG, CAVT_FLOAT,
	                               CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x71,
	                              CAVT_LONG, returnValue, 9, __paramTypes,
	                              lChanID, lVel1PotVal, fVel1, lVel2PotVal,
	                              fVel2, lVel3PotVal, fVel3, lVel4PotVal,
	                              fVel4);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPotParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long *plVel1PotVal,
                                                      float *pfVel1,
                                                      long *plVel2PotVal,
                                                      float *pfVel2,
                                                      long *plVel3PotVal,
                                                      float *pfVel3,
                                                      long *plVel4PotVal,
                                                      float *pfVel4,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x72,
	                              CAVT_LONG, returnValue, 9, __paramTypes,
	                              lChanID, plVel1PotVal, pfVel1, plVel2PotVal,
	                              pfVel2, plVel3PotVal, pfVel3, plVel4PotVal,
	                              pfVel4);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetEEPROMParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long lMsgID,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x73,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lMsgID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorShowSettingsDlg (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x77,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetCtrlStarted (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL *pbStarted,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x78,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              pbStarted);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHWCommsOK (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      VBOOL *pbCommsOK,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x79,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              pbCommsOK);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetPositionOffset (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float fPosOffset,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x7E,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, fPosOffset);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGUIEnable (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bEnable,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x7F,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bEnable);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetContextMenuEnable (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                VBOOL bEnabled,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x80,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bEnabled);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetPosDispClickEventEnable (CAObjHandle objectHandle,
                                                                      ERRORINFO *errorInfo,
                                                                      VBOOL bEnabled,
                                                                      long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x81,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bEnabled);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetPosDispDblClickEventEnable (CAObjHandle objectHandle,
                                                                         ERRORINFO *errorInfo,
                                                                         VBOOL bEnabled,
                                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x82,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bEnabled);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPositionOffset (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *pfPosOffset,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x83,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, pfPosOffset);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDispMode (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lDispMode,
                                                     long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x84,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lDispMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDispMode (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long *plDispMode,
                                                     long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x85,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              plDispMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetChannelSwitch (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x86,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetChannelSwitch (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long *plChanID,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x87,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              plChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsoluteRot (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fAnglePosCh1,
                                                         float fAnglePosCh2,
                                                         long lMoveMode,
                                                         VBOOL bWait,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_LONG, CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x88,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, fAnglePosCh1, fAnglePosCh2,
	                              lMoveMode, bWait);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParams_Accn (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x89,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParams_MaxVel (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8A,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxisInfo_MinPos (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8B,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxisInfo_MaxPos (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8C,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetRelMoveDist_RelDist (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8D,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetAbsMovePos_AbsPos (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8E,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBLashDist_BLashDist (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x8F,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPosition_Position (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x90,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPositionEx_UncalibPosition (CAObjHandle objectHandle,
                                                                       ERRORINFO *errorInfo,
                                                                       long lChanID,
                                                                       float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x91,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogMode_Mode (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x92,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogMode_StopMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x93,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogStepSize_StepSize (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x94,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStatusBits_Bits (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x95,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogVelParams_Accn (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x96,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogVelParams_MaxVel (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x97,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHomeParams_HomeVel (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long lChanID,
                                                               float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x98,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHomeParams_ZeroOffset (CAObjHandle objectHandle,
                                                                  ERRORINFO *errorInfo,
                                                                  long lChanID,
                                                                  float *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x99,
	                              CAVT_FLOAT, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPIDParams_Prop (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x9A,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPIDParams_Int (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x9B,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPIDParams_Deriv (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x9C,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_SetOperatingMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long lMode,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x9D,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_GetOperatingMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long *plMode,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x9E,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_SetCycleParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float fOnTime,
                                                           float fOffTime,
                                                           long lNumCycles,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x9F,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, fOnTime, fOffTime, lNumCycles);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_GetCycleParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *pfOnTime,
                                                           float *pfOffTime,
                                                           long *plNumCycles,
                                                           long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA0,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, pfOnTime, pfOffTime, plNumCycles);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_Enable (CAObjHandle objectHandle,
                                                   ERRORINFO *errorInfo,
                                                   long lChanID,
                                                   long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA3,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_Disable (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID,
                                                    long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA4,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              lChanID);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_GetOPState (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plState,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA5,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plState);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetBrakeState (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID, long lState,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA6,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lState);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBrakeState (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plState,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA7,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plState);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSuspendEndOfMoveMsgs (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA8,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLResumeEndOfMoveMsgs (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xA9,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEnableEventDlg (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bEnable,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xAA,
	                              CAVT_LONG, returnValue, 1, __paramTypes,
	                              bEnable);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorShowEventDlg (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xAB,
	                              CAVT_LONG, returnValue, 0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetRotStageModes (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lMoveMode,
                                                          long lPosReportMode,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xAC,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lMoveMode, lPosReportMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetRotStageModes (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plMoveMode,
                                                          long *plPosReportMode,
                                                          long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xAD,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plMoveMode, plPosReportMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetPMDParam (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lCommandCode,
                                                       long lParamCode,
                                                       long lVal,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xAE,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lCommandCode, lParamCode, lVal);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetPMDParam (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lCommandCode,
                                                       long lParamCode,
                                                       long *plVal,
                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xAF,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lCommandCode, lParamCode, plVal);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCCurrentLoopParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lProp,
                                                                long lInt,
                                                                long lIntLim,
                                                                long lIntDeadBand,
                                                                long lFFwd,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_LONG,
	                               CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB0,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, lProp, lInt, lIntLim, lIntDeadBand,
	                              lFFwd);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCCurrentLoopParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plProp,
                                                                long *plInt,
                                                                long *plIntLim,
                                                                long *plIntDeadBand,
                                                                long *plFFwd,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB1,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, plProp, plInt, plIntLim,
	                              plIntDeadBand, plFFwd);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCPositionLoopParams (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 long lProp,
                                                                 long lInt,
                                                                 long lIntLim,
                                                                 long lDeriv,
                                                                 long lDerivTime,
                                                                 long lLoopGain,
                                                                 long lVelFFwd,
                                                                 long lAccFFwd,
                                                                 long lPosErrLim,
                                                                 long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_LONG,
	                               CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_LONG,
	                               CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB2,
	                              CAVT_LONG, returnValue, 10, __paramTypes,
	                              lChanID, lProp, lInt, lIntLim, lDeriv,
	                              lDerivTime, lLoopGain, lVelFFwd, lAccFFwd,
	                              lPosErrLim);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCPositionLoopParams (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 long *plProp,
                                                                 long *plInt,
                                                                 long *plIntLim,
                                                                 long *plDeriv,
                                                                 long *plDerivTime,
                                                                 long *plLoopGain,
                                                                 long *plVelFFwd,
                                                                 long *plAccFFwd,
                                                                 long *plPosErrLim,
                                                                 long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB3,
	                              CAVT_LONG, returnValue, 10, __paramTypes,
	                              lChanID, plProp, plInt, plIntLim, plDeriv,
	                              plDerivTime, plLoopGain, plVelFFwd,
	                              plAccFFwd, plPosErrLim);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCMotorOutputParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float fContCurrLim,
                                                                float fEnergyLim,
                                                                float fMotorLim,
                                                                float fMotorBias,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_FLOAT, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB4,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, fContCurrLim, fEnergyLim, fMotorLim,
	                              fMotorBias);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCMotorOutputParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *pfContCurrLim,
                                                                float *pfEnergyLim,
                                                                float *pfMotorLim,
                                                                float *pfMotorBias,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB5,
	                              CAVT_LONG, returnValue, 5, __paramTypes,
	                              lChanID, pfContCurrLim, pfEnergyLim,
	                              pfMotorLim, pfMotorBias);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCTrackSettleParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lSettleTime,
                                                                long lSettleWnd,
                                                                long lTrackWnd,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB6,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, lSettleTime, lSettleWnd, lTrackWnd);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCTrackSettleParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plSettleTime,
                                                                long *plSettleWnd,
                                                                long *plTrackWnd,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB7,
	                              CAVT_LONG, returnValue, 4, __paramTypes,
	                              lChanID, plSettleTime, plSettleWnd,
	                              plTrackWnd);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCProfileModeParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lProfMode,
                                                                float fJerk,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_FLOAT};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB8,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lProfMode, fJerk);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCProfileModeParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plProfMode,
                                                                float *pfJerk,
                                                                long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xB9,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plProfMode, pfJerk);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCJoystickParams (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             float fMaxVelLO,
                                                             float fMaxVelHI,
                                                             float fAccnLO,
                                                             float fAccnHI,
                                                             long lDirSense,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT, CAVT_FLOAT,
	                               CAVT_FLOAT, CAVT_FLOAT, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xBA,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, fMaxVelLO, fMaxVelHI, fAccnLO,
	                              fAccnHI, lDirSense);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCJoystickParams (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             float *pfMaxVelLO,
                                                             float *pfMaxVelHI,
                                                             float *pfAccnLO,
                                                             float *pfAccnHI,
                                                             long *plDirSense,
                                                             long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_FLOAT | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xBB,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, pfMaxVelLO, pfMaxVelHI, pfAccnLO,
	                              pfAccnHI, plDirSense);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCSettledCurrentLoopParams (CAObjHandle objectHandle,
                                                                       ERRORINFO *errorInfo,
                                                                       long lChanID,
                                                                       long lSettledProp,
                                                                       long lSettledInt,
                                                                       long lSettledIntLim,
                                                                       long lSettledIntDeadBand,
                                                                       long lSettledFFwd,
                                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG, CAVT_LONG,
	                               CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xBC,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, lSettledProp, lSettledInt,
	                              lSettledIntLim, lSettledIntDeadBand,
	                              lSettledFFwd);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCSettledCurrentLoopParams (CAObjHandle objectHandle,
                                                                       ERRORINFO *errorInfo,
                                                                       long lChanID,
                                                                       long *plSettledProp,
                                                                       long *plSettledInt,
                                                                       long *plSettledIntLim,
                                                                       long *plSettledIntDeadBand,
                                                                       long *plSettledFFwd,
                                                                       long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xBD,
	                              CAVT_LONG, returnValue, 6, __paramTypes,
	                              lChanID, plSettledProp, plSettledInt,
	                              plSettledIntLim, plSettledIntDeadBand,
	                              plSettledFFwd);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetBowIndex (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lChanID,
                                                     long lBowIndex,
                                                     long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xBE,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, lBowIndex);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBowIndex (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lChanID,
                                                     long *plBowIndex,
                                                     long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xBF,
	                              CAVT_LONG, returnValue, 2, __paramTypes,
	                              lChanID, plBowIndex);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCTriggerParams (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long lTrigInMode,
                                                            long lTrigOutMode,
                                                            long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG, CAVT_LONG};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xC0,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, lTrigInMode, lTrigOutMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCTriggerParams (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long *plTrigInMode,
                                                            long *plTrigOutMode,
                                                            long *returnValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG, CAVT_LONG | CAVT_BYREFI,
	                               CAVT_LONG | CAVT_BYREFI};

	__result = CA_MethodInvokeEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0xC1,
	                              CAVT_LONG, returnValue, 3, __paramTypes,
	                              lChanID, plTrigInMode, plTrigOutMode);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHWSerialNum (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4,
	                              DISPATCH_PROPERTYGET, CAVT_LONG, returnValue,
	                              0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetHWSerialNum (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long newValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4,
	                              DISPATCH_PROPERTYPUT, CAVT_EMPTY, NULL, 1,
	                              __paramTypes, newValue);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetByRefHWSerialNum (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long *newValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI};

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x4,
	                              DISPATCH_PROPERTYPUTREF, CAVT_EMPTY, NULL, 1,
	                              __paramTypes, newValue);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetAPTHelp (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    VBOOL *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x45,
	                              DISPATCH_PROPERTYGET, CAVT_BOOL, returnValue,
	                              0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetAPTHelp (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    VBOOL newValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL};

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x45,
	                              DISPATCH_PROPERTYPUT, CAVT_EMPTY, NULL, 1,
	                              __paramTypes, newValue);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetByRefAPTHelp (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         VBOOL *newValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_BOOL | CAVT_BYREFI};

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x45,
	                              DISPATCH_PROPERTYPUTREF, CAVT_EMPTY, NULL, 1,
	                              __paramTypes, newValue);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDISPLAYMODE (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long *returnValue)
{
	HRESULT __result = S_OK;

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x61,
	                              DISPATCH_PROPERTYGET, CAVT_LONG, returnValue,
	                              0, NULL);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDISPLAYMODE (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long newValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG};

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x61,
	                              DISPATCH_PROPERTYPUT, CAVT_EMPTY, NULL, 1,
	                              __paramTypes, newValue);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetByRefDISPLAYMODE (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long *newValue)
{
	HRESULT __result = S_OK;
	unsigned int __paramTypes[] = {CAVT_LONG | CAVT_BYREFI};

	__result = CA_InvokeHelperEx (objectHandle, errorInfo,
	                              &MG17MotorLib_IID__DMG17Motor, 0x61,
	                              DISPATCH_PROPERTYPUTREF, CAVT_EMPTY, NULL, 1,
	                              __paramTypes, newValue);

	return __result;
}

static void CVIFUNC _DMG17MotorEventsRegOnMoveComplete_EventVTableFunc (void *thisPtr,
                                                                        long lChanID)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnMoveComplete_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 0, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData, lChanID);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnHomeComplete_EventVTableFunc (void *thisPtr,
                                                                        long lChanID)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnHomeComplete_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 1, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData, lChanID);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnMoveStopped_EventVTableFunc (void *thisPtr,
                                                                       long lChanID)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnMoveStopped_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 2, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData, lChanID);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnHWResponse_EventVTableFunc (void *thisPtr,
                                                                      long lHWCode,
                                                                      long lMsgIdent)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnHWResponse_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 3, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData, lHWCode,
		                               lMsgIdent);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnSettingsChanged_EventVTableFunc (void *thisPtr,
                                                                           long lFlags)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnSettingsChanged_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 4, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData, lFlags);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnEncCalibComplete_EventVTableFunc (void *thisPtr,
                                                                            long lChanID)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnEncCalibComplete_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 5, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData, lChanID);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnPositionClick_EventVTableFunc (void *thisPtr,
                                                                         float fCurrentPosition)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnPositionClick_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 6, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData,
		                               fCurrentPosition);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

static void CVIFUNC _DMG17MotorEventsRegOnPositionDblClick_EventVTableFunc (void *thisPtr,
                                                                            float fCurrentPosition)
{
	HRESULT __result = S_OK;
	void * __callbackData;
	CAObjHandle __serverObjHandle;
	_DMG17MotorEventsRegOnPositionDblClick_CallbackType __callbackFunction;
	
	

	__caErrChk (CA_GetEventCallback (thisPtr, 7, &__callbackFunction,
	                                 &__callbackData, &__serverObjHandle));

	if (__callbackFunction != NULL)
		{
	
		__result = __callbackFunction (__serverObjHandle, __callbackData,
		                               fCurrentPosition);
	
		__caErrChk (__result);
		
		}
Error:

	return;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnMoveComplete (CAObjHandle serverObject,
                                                                 _DMG17MotorEventsRegOnMoveComplete_CallbackType callbackFunction,
                                                                 void *callbackData,
                                                                 int enableCallbacks,
                                                                 int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     0, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnHomeComplete (CAObjHandle serverObject,
                                                                 _DMG17MotorEventsRegOnHomeComplete_CallbackType callbackFunction,
                                                                 void *callbackData,
                                                                 int enableCallbacks,
                                                                 int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     1, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnMoveStopped (CAObjHandle serverObject,
                                                                _DMG17MotorEventsRegOnMoveStopped_CallbackType callbackFunction,
                                                                void *callbackData,
                                                                int enableCallbacks,
                                                                int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     2, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnHWResponse (CAObjHandle serverObject,
                                                               _DMG17MotorEventsRegOnHWResponse_CallbackType callbackFunction,
                                                               void *callbackData,
                                                               int enableCallbacks,
                                                               int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     3, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnSettingsChanged (CAObjHandle serverObject,
                                                                    _DMG17MotorEventsRegOnSettingsChanged_CallbackType callbackFunction,
                                                                    void *callbackData,
                                                                    int enableCallbacks,
                                                                    int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     4, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnEncCalibComplete (CAObjHandle serverObject,
                                                                     _DMG17MotorEventsRegOnEncCalibComplete_CallbackType callbackFunction,
                                                                     void *callbackData,
                                                                     int enableCallbacks,
                                                                     int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     5, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnPositionClick (CAObjHandle serverObject,
                                                                  _DMG17MotorEventsRegOnPositionClick_CallbackType callbackFunction,
                                                                  void *callbackData,
                                                                  int enableCallbacks,
                                                                  int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     6, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnPositionDblClick (CAObjHandle serverObject,
                                                                     _DMG17MotorEventsRegOnPositionDblClick_CallbackType callbackFunction,
                                                                     void *callbackData,
                                                                     int enableCallbacks,
                                                                     int *callbackId)
{
	HRESULT __result = S_OK;

	__result = CA_RegisterEventCallback (serverObject,
	                                     &__DMG17MotorEvents_CAEventClassDefn,
	                                     7, callbackFunction, callbackData,
	                                     enableCallbacks, callbackId);

	return __result;
}
