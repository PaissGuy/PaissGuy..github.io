#ifndef PI_CONTROL_INCLUDE  

#define PI_CONTROL_INCLUDE  

#include <visa.h> 


#define PI_COM_PORT    "COM13"  //"COM13" 

#define ViErrChk(WrappedFunc) {ViErr = (WrappedFunc); if (ViErr < 0) {goto Error;}}
#define ViNullChk(WrappedFunc) {if (0 == (WrappedFunc)) {ViErr = VI_ERROR_ALLOC; goto Error;}}
#define MAX_ARRAY_SIZE 4096
#define MAX_PI_CMD_LEN 128


// PO commands for use swich case, for multithreading
#define PI_MOVE_REL 100  
#define PI_SET_SPEED 101
#define PI_SET_ACCELERATION 102
#define PI_HOME 103
#define PI_SET_PID 104
#define PI_MOVE_ABS 105
#define PI_STOP 106
#define PI_POS_QUARY 107

typedef struct PIFunctionData 
{
	int Axis;
	double data1;
	double data2;
	double data3;
} PI_Data;


int  Initialize_PI_Stages(void);      
int PI_threaded(PI_Data *Params, int cmdType) ;
int Open_PI_Port( ViSession resManeger );  
ViStatus PI_SendCMD(char* cmdString);
ViStatus PI_Quarry(char* quaryString, char* respondString);
int PI_MoveRelative(PI_Data *Params);  // Axis + step size
int PI_MoveAbsolute(PI_Data *Params);  // Axis + location
int PI_Speed(PI_Data *Params);		 // Axis + speed
int PI_Acceleration(PI_Data *Params);  // Axis + acc
int PI_MoveHOME(PI_Data *Params);		 // Axis
int PI_SetZero();
int PI_Stop(PI_Data *Params);			 // Axis
ViStatus Close_PI_InstrSession(void) ;
double PI_POS_Query(int Axis);
ViStatus PI_WaitUntilReady(int Axis);
static ViStatus SetTermCharAttributes(ViSession session, ViByte terminationCharacter);
void PI_Errors (void);  




#endif  //end Header Guard



