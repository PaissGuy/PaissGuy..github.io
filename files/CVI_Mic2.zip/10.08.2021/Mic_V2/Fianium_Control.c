#include "Fianium_Control.h"

#define ViErrChk(WrappedFunc) {ViErr = (WrappedFunc); if (ViErr < 0) {goto Error;}}
#define ViNullChk(WrappedFunc) {if (0 == (WrappedFunc)) {ViErr = VI_ERROR_ALLOC; goto Error;}}


static ViChar formatString[255];
ViSession FianiumSession; 

int OpenFianiumPort(ViSession resManeger )
{
	ViStatus ViErr = 0;

	// Open a session to the instrument
	ViErrChk(viOpen(resManeger, FIANIUM_COM_PORT, 4, VI_NULL, &FianiumSession));
	// Set the timeout
	ViErrChk(viSetAttribute (FianiumSession, VI_ATTR_TMO_VALUE, 3000));
	//Set the termination character attributes
	ViErrChk(SetTermCharAttributes(FianiumSession, 10));
	
	
	return 0;
Error:
	
return ViErr;	
 //   }
}

ViStatus CloseFianiumInstrSession(void)
{
	ViStatus ViErr = VI_SUCCESS;

	if (FianiumSession) {
		// Close the session
		ViErrChk(viClose(FianiumSession));
	}
Error:
	return ViErr;
}


int LaserPowerUpdate(char *Source, double NewOutput)   //This function is being called by the EndProgram_Sequance function in MIC_V2.c file in line 561 and also by, , its main goal is to update the laser SC and fundamental power,
{
	char cmd[MAX_COMMAND_LENGTH]="";
	char tmpSTR[MAX_COMMAND_LENGTH]="";
	int LaserOut;

	ViStatus ViErr = 0;
    ViString output = 0;
	
	//Create Fianium Power Out String//
	if (strcmp (SC_OUTPUT, Source)==0)	LaserOut=(int)((NewOutput/MAX_LASER_POWER)*MAX_LASER_OUT);
	else  LaserOut=(int)(715.5*pow(NewOutput,0.285));
	strcat(cmd,Source);
	strcat(cmd,"=");
	sprintf (tmpSTR, "%d", LaserOut);
	//////////////////////////////////////
	
	// Clear the buffer
	ViErrChk(viFlush(FianiumSession, VI_READ_BUF_DISCARD));

	strcat(cmd,tmpSTR);
	// Send the command to the instrument
	ViErrChk(viPrintf(FianiumSession, "%s\n", cmd));
	
							   
	return 0;
	
Error:
    CloseFianiumInstrSession();
	return ViErr;
}


static ViStatus SetTermCharAttributes(ViSession resourceName, ViByte terminationCharacter)
{
	ViStatus ViErr = VI_SUCCESS;
	ViUInt16 intfType = 0;

	// Set the termination character attributes if this is a serial resource
	ViErrChk(viGetAttribute(resourceName, VI_ATTR_INTF_TYPE, &intfType));
	if (intfType == VI_INTF_ASRL) {
		if (terminationCharacter > 0) {
			ViErrChk(viSetAttribute(resourceName, VI_ATTR_ASRL_END_IN, VI_ASRL_END_TERMCHAR));
		}
		else {
			ViErrChk(viSetAttribute(resourceName, VI_ATTR_ASRL_END_IN, VI_ASRL_END_NONE));
		}
	}
	ViErrChk(viSetAttribute(resourceName, VI_ATTR_TERMCHAR_EN, (terminationCharacter > 0)));
	ViErrChk(viSetAttribute(resourceName, VI_ATTR_TERMCHAR, terminationCharacter));

Error:
	return ViErr;
}

