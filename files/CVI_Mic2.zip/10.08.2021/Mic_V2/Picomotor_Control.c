#include <ansi_c.h>
#include "Picomotor_Control.h"

byte mode, min_speed=1, run_current=0, hld_current=0, ADLimit=255, em_acc, speed=2000, acc=255;
int num_moduls=0;
byte pico_addr = 0;
byte mod_type, mod_version;
long pos;


int  InitializePicomotor(void) 
{
	int addr;
	
	num_moduls = LdcnInit(PICOMOTOR_COM_PORT_NAME, PICOMOTOR_BUAD_RATE);
	if(!num_moduls) num_moduls=LdcnFullInit(PICOMOTOR_COM_PORT_NAME, PICOMOTOR_BUAD_RATE);    

	for (addr = 1; addr <= num_moduls; addr++) 
	{        // look for a pico motor 
       LdcnReadStatus(addr, SEND_ID);
       mod_type = LdcnGetModType(addr);
       mod_version = LdcnGetModVer(addr);
                                                        
       if ((mod_type == STEPMODTYPE) && (mod_version >= 50) && (mod_version < 60))
		  { 
			  pico_addr = addr; 
			  break; 
		  } 
	
	}	  
		  
   	if (pico_addr) 
	{
	// set parameters -----------------------------------------------
      mode = SPEED_8X;    // or mode = SPEED_2X or mode = SPEED_4X or SPEED_8X
      mode |= IGNORE_LIMITS;
      if (!StepSetParam(pico_addr, mode, min_speed, run_current, hld_current, ADLimit, em_acc))
	  { 
		  printf("Communication Error");  
		  LdcnShutdown(); 
		  return -1;
	  }

	// Send output value to the device   //motor type and channel
	  StepSetOutputs(pico_addr, TYPE_STD | SET_CH_A);  

	// Read device status
	  LdcnNoOp(pico_addr);    
      if ((LdcnGetStat(pico_addr) & POWER_ON) == 0)
		  printf("Invalid channel");		  
	
	
	// Enable Driver ---------------------------------------

	  StepStopMotor(pico_addr, STOP_SMOOTH | STP_ENABLE_AMP); 
	  return pico_addr; 
	}
}

void PicomotorSetAcceleration(int Acc)
{
	//Acc = 0 to 255 steps/sec^2
	acc =Acc;
}
void PicomotorSetSpeed(int Speed)
{
	//Speed = 1 to 2000 steps/sec
	speed=Speed;
	
}
void PicomotorMoveRelative(int Steps)
{
	LdcnReadStatus(pico_addr, SEND_POS); // read device status and current position 
    pos = StepGetPos(pico_addr);
	pos += 25*Steps;	//steps
	mode = START_NOW | LOAD_SPEED | LOAD_ACC | LOAD_POS;  
	StepLoadTraj(pico_addr, mode, pos, speed, acc, 0);		
}

void PicomotorMoveAbsolute(int Location)
{
	pos = 25*Location;	//steps
	mode = START_NOW | LOAD_SPEED | LOAD_ACC | LOAD_POS;
	StepLoadTraj(pico_addr, mode, pos, speed, acc, 0);
}
void PicomotorMoveCont(int Direction)
{
	if (Direction==PICOMOTOR_MOVE_UP)
		mode = START_NOW | LOAD_SPEED | LOAD_ACC| STEP_REV;	
	else
		mode = START_NOW | LOAD_SPEED | LOAD_ACC;
	
	StepLoadTraj(pico_addr, mode, pos, speed, acc, 0);
	
}
long PicomotorLocationQuarry(void)
{
	LdcnReadStatus(pico_addr, SEND_POS); // read device status and current position
	
	return StepGetPos(pico_addr)/25;
}

void PicomotorShutDown(void)
{
	StepStopMotor(pico_addr, STOP_SMOOTH );
	LdcnShutdown();
}

void PicomotorStop (void)
{
	 StepStopMotor(pico_addr, STOP_ABRUPT | STP_ENABLE_AMP);
 }

void PicomotorWaitTillReady(void)
{
// wait end of the motion
    do 
	{    
   		LdcnReadStatus(pico_addr, SEND_POS); // read device status and current position
	}while (LdcnGetStat(pico_addr) & MOTOR_MOVING);
}


	
		 
