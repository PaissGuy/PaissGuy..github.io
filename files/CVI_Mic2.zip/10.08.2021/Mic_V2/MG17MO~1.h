#ifndef _MG17MOTORLIB_H
#define _MG17MOTORLIB_H

#include <cviauto.h>

#ifdef __cplusplus
    extern "C" {
#endif
/* NICDBLD_BEGIN> Type Library Specific Types */

enum MG17MotorLibEnum_LLMOTREQIDS
{
	MG17MotorLibConst_DEV_PARAMS = 0,
	MG17MotorLibConst_DIGOUTPUTS = 1,
	MG17MotorLibConst_CHANENABLEDSTATE = 2,
	MG17MotorLibConst_VEL_PARAMS = 3,
	MG17MotorLibConst_JOG_PARAMS = 4,
	MG17MotorLibConst_LIMSWITCH_PARAMS = 5,
	MG17MotorLibConst_POWER_PARAMS = 6,
	MG17MotorLibConst_GENMOVE_PARAMS = 7,
	MG17MotorLibConst_HOME_PARAMS = 8,
	MG17MotorLibConst_MOVEREL_PARAMS = 9,
	MG17MotorLibConst_MOVEABS_PARAMS = 10,
	MG17MotorLibConst_MOVEVEL_PARAMS = 11,
	MG17MotorLibConst_TRIGBITS = 12,
	MG17MotorLibConst_HOSTDIGOUTPUTS = 13,
	MG17MotorLibConst_DCPID_PARAMS = 14,
	MG17MotorLibConst_DCADVANCED_PARAMS = 15,
	MG17MotorLibConst_POT_PARAMS = 16,
	MG17MotorLibConst_AV_MODES = 17,
	MG17MotorLibConst_BUTTON_PARAMS = 18,
	MG17MotorLibConst_PMD_ILOOP_PARAMS = 19,
	MG17MotorLibConst_PMD_PLOOP_PARAMS = 20,
	MG17MotorLibConst_PMD_MOUTPUT_PARAMS = 21,
	MG17MotorLibConst_PMD_TRACKSETTLE_PARAMS = 22,
	MG17MotorLibConst_PMD_PROFILE_PARAMS = 23,
	MG17MotorLibConst_PMD_JOYSTICK_PARAMS = 24,
	MG17MotorLibConst_PMD_STAGEAXIS_PARAMS = 25,
	MG17MotorLibConst_PMD_ILOOPSETTLED_PARAMS = 26,
	_MG17MotorLib_LLMOTREQIDSForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_HWCHANNEL
{
	MG17MotorLibConst_CHAN1_ID = 0,
	MG17MotorLibConst_CHAN2_ID = 1,
	MG17MotorLibConst_CHANBOTH_ID = 10,
	_MG17MotorLib_HWCHANNELForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_STAGETYPE
{
	MG17MotorLibConst_TYPE_UNKNOWN = 1,
	MG17MotorLibConst_TYPE_17APT600R = 2,
	MG17MotorLibConst_TYPE_17APT600L = 3,
	MG17MotorLibConst_TYPE_NANOMAX300 = 16,
	MG17MotorLibConst_TYPE_NST150 = 32,
	MG17MotorLibConst_TYPE_NST25 = 33,
	MG17MotorLibConst_TYPE_NST50 = 34,
	MG17MotorLibConst_TYPE_NST75 = 35,
	MG17MotorLibConst_TYPE_NST100 = 36,
	MG17MotorLibConst_TYPE_NANOMAX600_DRV001 = 48,
	MG17MotorLibConst_TYPE_DRV005 = 64,
	MG17MotorLibConst_TYPE_DRV006 = 65,
	MG17MotorLibConst_TYPE_DRV013 = 66,
	MG17MotorLibConst_TYPE_DRV014 = 67,
	MG17MotorLibConst_TYPE_DRV113 = 68,
	MG17MotorLibConst_TYPE_DRV114 = 69,
	MG17MotorLibConst_TYPE_AMR101 = 80,
	MG17MotorLibConst_TYPE_ZST6 = 96,
	MG17MotorLibConst_TYPE_ZST13 = 97,
	MG17MotorLibConst_TYPE_ZST25 = 98,
	MG17MotorLibConst_TYPE_Z606 = 99,
	MG17MotorLibConst_TYPE_Z612 = 100,
	MG17MotorLibConst_TYPE_Z625 = 101,
	MG17MotorLibConst_TYPE_07EAS503 = 112,
	MG17MotorLibConst_TYPE_07EAS504 = 113,
	_MG17MotorLib_STAGETYPEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_STAGEAXIS
{
	MG17MotorLibConst_AXIS_UNKNOWN = 1,
	MG17MotorLibConst_AXIS_SINGLE = 2,
	MG17MotorLibConst_AXIS_ROTARY = 3,
	MG17MotorLibConst_AXIS_X = 16,
	MG17MotorLibConst_AXIS_Y = 17,
	MG17MotorLibConst_AXIS_Z = 18,
	MG17MotorLibConst_AXIS_PITCH = 19,
	MG17MotorLibConst_AXIS_ROLL = 20,
	MG17MotorLibConst_AXIS_YAW = 21,
	_MG17MotorLib_STAGEAXISForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_STAGEUNITS
{
	MG17MotorLibConst_UNITS_MM = 1,
	MG17MotorLibConst_UNITS_DEG = 2,
	_MG17MotorLib_STAGEUNITSForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_STOPMODE
{
	MG17MotorLibConst_STOP_IMMEDIATE = 1,
	MG17MotorLibConst_STOP_PROFILED = 2,
	_MG17MotorLib_STOPMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_JOGMODE
{
	MG17MotorLibConst_JOG_CONTINUOUS = 1,
	MG17MotorLibConst_JOG_SINGLESTEP = 2,
	_MG17MotorLib_JOGMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_SWLIMITMODE
{
	MG17MotorLibConst_SWLIMIT_IGNORE = 1,
	MG17MotorLibConst_SWLIMIT_IMMEDIATESTOP = 2,
	MG17MotorLibConst_SWLIMIT_PROFILEDSTOP = 3,
	_MG17MotorLib_SWLIMITMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_HOMEDIR
{
	MG17MotorLibConst_HOME_FWD = 1,
	MG17MotorLibConst_HOME_REV = 2,
	_MG17MotorLib_HOMEDIRForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_HOMELIMSWITCH
{
	MG17MotorLibConst_HOMELIMSW_FWD_HW = 4,
	MG17MotorLibConst_HOMELIMSW_REV_HW = 1,
	_MG17MotorLib_HOMELIMSWITCHForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_HWLIMSWITCH
{
	MG17MotorLibConst_HWLIMSW_IGNORE = 1,
	MG17MotorLibConst_HWLIMSW_MAKES = 2,
	MG17MotorLibConst_HWLIMSW_BREAKS = 3,
	MG17MotorLibConst_HWLIMSW_MAKES_HOMEONLY = 4,
	MG17MotorLibConst_HWLIMSW_BREAKS_HOMEONLY = 5,
	_MG17MotorLib_HWLIMSWITCHForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_MOVEVELDIR
{
	MG17MotorLibConst_MOVE_FWD = 1,
	MG17MotorLibConst_MOVE_REV = 2,
	_MG17MotorLib_MOVEVELDIRForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_MOVEJOGDIR
{
	MG17MotorLibConst_JOG_FWD = 1,
	MG17MotorLibConst_JOG_REV = 2,
	_MG17MotorLib_MOVEJOGDIRForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_TRIGMODE
{
	MG17MotorLibConst_TRIGMODE_DISABLED = 1,
	MG17MotorLibConst_TRIGMODE_IN = 2,
	MG17MotorLibConst_TRIGMODE_INOUT = 3,
	MG17MotorLibConst_TRIGMODE_OUT = 4,
	_MG17MotorLib_TRIGMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_TRIGMOVE
{
	MG17MotorLibConst_TRIGMOVE_REL = 1,
	MG17MotorLibConst_TRIGMOVE_ABS = 2,
	MG17MotorLibConst_TRIGMOVE_HOME = 3,
	_MG17MotorLib_TRIGMOVEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_ENCQEPSENSE
{
	MG17MotorLibConst_ENC_QEP_POSITIVE = 1,
	MG17MotorLibConst_ENC_QEP_NEGATIVE = -1,
	_MG17MotorLib_ENCQEPSENSEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_ENCPOSSOURCEMODE
{
	MG17MotorLibConst_ENC_POSSRC_MICROSTEP = 1,
	MG17MotorLibConst_ENC_POSSRC_ENCODER = 2,
	_MG17MotorLib_ENCPOSSOURCEMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_ENCPOSCONTROLMODE
{
	MG17MotorLibConst_ENC_POSCTRL_DISABLED = 1,
	MG17MotorLibConst_ENC_POSCTRL_POSITION = 2,
	MG17MotorLibConst_ENC_POSCTRL_POSITIONSTOPSHORT = 3,
	_MG17MotorLib_ENCPOSCONTROLMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_DISPLAYMODE
{
	MG17MotorLibConst_DISPMODE_PANEL = 1,
	MG17MotorLibConst_DISPMODE_GRAPH = 2,
	MG17MotorLibConst_DISPMODE_POSITION = 3,
	_MG17MotorLib_DISPLAYMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_INDICATORLEDMODE
{
	MG17MotorLibConst_LED_IDENT = 1,
	MG17MotorLibConst_LED_LIMITSWITCH = 2,
	MG17MotorLibConst_LED_BUTTONMODECHANGE = 4,
	MG17MotorLibConst_LED_MOVING = 8,
	_MG17MotorLib_INDICATORLEDMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_BUTTONMODE
{
	MG17MotorLibConst_BUTTON_MODEJOG = 1,
	MG17MotorLibConst_BUTTON_MODEGOTO = 2,
	_MG17MotorLib_BUTTONMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_APT_PARENT_HWTYPES
{
	MG17MotorLibConst_USB_BMC103 = 40,
	MG17MotorLibConst_USB_BBD103 = 45,
	MG17MotorLibConst_ETHNET_MMR601 = 42,
	MG17MotorLibConst_USB_MMR601 = 43,
	_MG17MotorLib_APT_PARENT_HWTYPESForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_ROTMOVEMODE
{
	MG17MotorLibConst_ROT_MOVE_POS = 1,
	MG17MotorLibConst_ROT_MOVE_NEG = 2,
	MG17MotorLibConst_ROT_MOVE_SHORT = 3,
	_MG17MotorLib_ROTMOVEMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_ROTPOSDISPMODE
{
	MG17MotorLibConst_ROT_POSDISP_360 = 1,
	MG17MotorLibConst_ROT_POSDISP_TOTAL = 2,
	_MG17MotorLib_ROTPOSDISPMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_DCPROFILEMODE
{
	MG17MotorLibConst_PROFMODE_TRAPEZOIDAL = 1,
	MG17MotorLibConst_PROFMODE_SCURVE = 3,
	_MG17MotorLib_DCPROFILEMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_SOLOUTPUTSTATE
{
	MG17MotorLibConst_OUTPUTSTATE_ON = 1,
	MG17MotorLibConst_OUTPUTSTATE_OFF = 2,
	_MG17MotorLib_SOLOUTPUTSTATEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_SOLOPERATINGMODE
{
	MG17MotorLibConst_SOLENOID_MANUAL = 1,
	MG17MotorLibConst_SOLENOID_SINGLE = 2,
	MG17MotorLibConst_SOLENOID_AUTO = 3,
	MG17MotorLibConst_SOLENOID_TRIGGER = 4,
	_MG17MotorLib_SOLOPERATINGMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_BRAKE_STATE
{
	MG17MotorLibConst_BRAKE_ON = 1,
	MG17MotorLibConst_BRAKE_OFF = 2,
	_MG17MotorLib_BRAKE_STATEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_DCTRIGINMODE
{
	MG17MotorLibConst_DCTRIGIN_DISABLED = 1,
	MG17MotorLibConst_DCTRIGINRISE_RELMOVE = 2,
	MG17MotorLibConst_DCTRIGINFALL_RELMOVE = 3,
	MG17MotorLibConst_DCTRIGINRISE_ABSMOVE = 4,
	MG17MotorLibConst_DCTRIGINFALL_ABSMOVE = 5,
	MG17MotorLibConst_DCTRIGINRISE_HOMEMOVE = 6,
	MG17MotorLibConst_DCTRIGINFALL_HOMEMOVE = 7,
	_MG17MotorLib_DCTRIGINMODEForceSizeToFourBytes = 0xFFFFFFFF
};
enum MG17MotorLibEnum_DCTRIGOUTMODE
{
	MG17MotorLibConst_DCTRIGOUT_DISABLED = 1,
	MG17MotorLibConst_DCTRIGOUTHIGH_INMOTION = 2,
	MG17MotorLibConst_DCTRIGOUTLOW_INMOTION = 3,
	MG17MotorLibConst_DCTRIGOUTHIGH_MOTIONCOMPLETE = 4,
	MG17MotorLibConst_DCTRIGOUTLOW_MOTIONCOMPLETE = 5,
	MG17MotorLibConst_DCTRIGOUTHIGH_MAXVELOCITY = 6,
	MG17MotorLibConst_DCTRIGOUTLOW_MAXVELOCITY = 7,
	_MG17MotorLib_DCTRIGOUTMODEForceSizeToFourBytes = 0xFFFFFFFF
};
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnMoveComplete_CallbackType) (CAObjHandle caServerObjHandle,
                                                                                void *caCallbackData,
                                                                                long  lChanID);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnHomeComplete_CallbackType) (CAObjHandle caServerObjHandle,
                                                                                void *caCallbackData,
                                                                                long  lChanID);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnMoveStopped_CallbackType) (CAObjHandle caServerObjHandle,
                                                                               void *caCallbackData,
                                                                               long  lChanID);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnHWResponse_CallbackType) (CAObjHandle caServerObjHandle,
                                                                              void *caCallbackData,
                                                                              long  lHWCode,
                                                                              long  lMsgIdent);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnSettingsChanged_CallbackType) (CAObjHandle caServerObjHandle,
                                                                                   void *caCallbackData,
                                                                                   long  lFlags);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnEncCalibComplete_CallbackType) (CAObjHandle caServerObjHandle,
                                                                                    void *caCallbackData,
                                                                                    long  lChanID);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnPositionClick_CallbackType) (CAObjHandle caServerObjHandle,
                                                                                 void *caCallbackData,
                                                                                 float  fCurrentPosition);
typedef HRESULT (CVICALLBACK *_DMG17MotorEventsRegOnPositionDblClick_CallbackType) (CAObjHandle caServerObjHandle,
                                                                                    void *caCallbackData,
                                                                                    float  fCurrentPosition);
/* NICDBLD_END> Type Library Specific Types */

extern const IID MG17MotorLib_IID__DMG17Motor;
extern const IID MG17MotorLib_IID__DMG17MotorEvents;

HRESULT CVIFUNC MG17MotorLib_New_DMG17Motor (int panel, const char *label,
                                             int top, int left, int *controlID,
                                             int *UILError);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorAboutBox (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStartCtrl (CAObjHandle objectHandle,
                                                   ERRORINFO *errorInfo,
                                                   long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStopCtrl (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPosition (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lChanID,
                                                     float *pfPosition,
                                                     long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPosParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plPosControlMode,
                                                           long *plMicroStepDivider,
                                                           long *plPosStepRes,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetVelParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plMinVel,
                                                           long *plAccn,
                                                           long *plMaxVel,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetJogParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plJogMode,
                                                           long *plJogStepSize,
                                                           long *plMinVel,
                                                           long *plAccn,
                                                           long *plMaxVel,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetLimSwitchParams (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 VBOOL bSet,
                                                                 long lChanID,
                                                                 long *plCWHardLimit,
                                                                 long *plCCWHardLimit,
                                                                 long *plCWSoftLimit,
                                                                 long *plCCWSoftLimit,
                                                                 long *plSoftLimitMode,
                                                                 long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPowerParams (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             VBOOL bSet,
                                                             long lChanID,
                                                             long *plRestFactor,
                                                             long *plMoveFactor,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetHomeParams (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            VBOOL bSet,
                                                            long lChanID,
                                                            long *plDirection,
                                                            long *plLimSwitch,
                                                            long *plHomeVel,
                                                            long *plOffsetDist,
                                                            long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetMoveRelParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               VBOOL bSet,
                                                               long lChanID,
                                                               long *plRelDist,
                                                               long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetMoveAbsParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               VBOOL bSet,
                                                               long lChanID,
                                                               long *plAbsPos,
                                                               long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveVelocity (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long lDirection,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLMoveStop (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID, long lStopMode,
                                                    long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLReqHWParams (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long lParamID,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEnableHWChannel (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorDisableHWChannel (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetDevParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long *plDevParams,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveHome (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long lChanID, VBOOL bWait,
                                                  long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStopImmediate (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorStopProfiled (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveRelativeEx (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fRelDistCh1,
                                                        float fRelDistCh2,
                                                        VBOOL bWait,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsoluteEx (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fAbsPosCh1,
                                                        float fAbsPosCh2,
                                                        VBOOL bWait,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveRelative (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID, VBOOL bWait,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsolute (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID, VBOOL bWait,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetStatusBits (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *plStatusBits,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetGenMoveParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               VBOOL bSet,
                                                               long lChanID,
                                                               long *plBLashDist,
                                                               long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetVelParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float fMinVel, float fAccn,
                                                      float fMaxVel,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float *pfMinVel,
                                                      float *pfAccn,
                                                      float *pfMaxVel,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxis (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      char **pbstrStageAxisName,
                                                      long *plStageID,
                                                      long *plAxisID,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxisInfo (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          float *pfMinPos,
                                                          float *pfMaxPos,
                                                          long *plUnits,
                                                          float *pfPitch,
                                                          long *plDirSense,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParamLimits (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *pfMaxAccn,
                                                           float *pfMaxVel,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetJogMode (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID, long lMode,
                                                    long lStopMode,
                                                    long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogMode (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID, long *plMode,
                                                    long *plStopMode,
                                                    long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetJogStepSize (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fStepSize,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogStepSize (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float *pfStepSize,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetJogVelParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fMinVel,
                                                         float fAccn,
                                                         float fMaxVel,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogVelParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float *pfMinVel,
                                                         float *pfAccn,
                                                         float *pfMaxVel,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetRelMoveDist (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fRelDist,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetRelMoveDist (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float *pfRelDist,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetAbsMovePos (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       float fAbsPos,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetAbsMovePos (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       float *pfAbsPos,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetDigOPs (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bSet, long *plBits,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetDigIPs (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long *plBits,
                                                     long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetADCInputs (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long *plADCVal1,
                                                        long *plADCVal2,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetPosition (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plPosition,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetBLashDist (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float fBLashDist,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBLashDist (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      float *pfBLashDist,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorIdentify (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetSWPosLimits (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float fRevPosLimit,
                                                        float fFwdPosLimit,
                                                        long lLimitMode,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetSWPosLimits (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        float *pfRevPosLimit,
                                                        float *pfFwdPosLimit,
                                                        long *plLimitMode,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetStageAxisInfo (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          float fMinPos,
                                                          float fMaxPos,
                                                          long lUnits,
                                                          float fPitch,
                                                          long lDirSense,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSaveHWDefaults (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetHomeParams (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long lDirection,
                                                       long lLimSwitch,
                                                       float fHomeVel,
                                                       float fZeroOffset,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHomeParams (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plDirection,
                                                       long *plLimSwitch,
                                                       float *pfHomeVel,
                                                       float *pfZeroOffset,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetHWLimSwitches (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lRevLimSwitch,
                                                          long lFwdLimSwitch,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHWLimSwitches (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plRevLimSwitch,
                                                          long *plFwdLimSwitch,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetPhaseCurrents (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lRestVal,
                                                          long lMoveVal,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPhaseCurrents (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plRestVal,
                                                          long *plMoveVal,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPositionEx (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       float *pfCalibPosition,
                                                       float *pfUncalibPosition,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorDoEvents (CAObjHandle objectHandle,
                                                  ERRORINFO *errorInfo,
                                                  long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetEncoderCount (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long lEncCount,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetEncoderCount (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long *plEncCount,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetTrigBits (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          VBOOL bSet,
                                                          long lChanID,
                                                          long *plBits,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveJog (CAObjHandle objectHandle,
                                                 ERRORINFO *errorInfo,
                                                 long lChanID, long lJogDir,
                                                 long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetMotorParams (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        long lStepsPerRev,
                                                        long lGearBoxRatio,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetMotorParams (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long lChanID,
                                                        long *plStepsPerRev,
                                                        long *plGearBoxRatio,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetTriggerParams (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lTrigMode,
                                                          long lTrigMove,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetTriggerParams (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plTrigMode,
                                                          long *plTrigMove,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSaveParamSet (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      const char *bstrName,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLoadParamSet (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      const char *bstrName,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorDeleteParamSet (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        const char *btsrName,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetDSPProgState (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bProg,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSendDSPProgData (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lNumBytes,
                                                           unsigned char *lpbyData,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsoluteEnc (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fAbsPosCh1,
                                                         float fAbsPosCh2,
                                                         long lTimeInc,
                                                         VBOOL bWait,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveRelativeEnc (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fRelDistCh1,
                                                         float fRelDistCh2,
                                                         long lTimeInc,
                                                         VBOOL bWait,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorCalibrateEnc (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID, VBOOL bWait,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetEncCalibTableParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lEncCalib,
                                                                float fCalibStep,
                                                                long lCalibDwell,
                                                                long lQEPSense,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetEncCalibTableParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plEncCalib,
                                                                float *pfCalibStep,
                                                                long *plCalibDwell,
                                                                long *plQEPSense,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetEncPosCorrectParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lPosSetPtWnd,
                                                                long lSnguStepWnd,
                                                                long lStopShortDist,
                                                                long lCorrMoveStep,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetEncPosCorrectParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plPosSetPtWnd,
                                                                long *plSnguStepWnd,
                                                                long *plStopShortDist,
                                                                long *plCorrMoveStep,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetEncPosControlParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lPosSrcMode,
                                                                long lPosCorrMode,
                                                                VBOOL bUseCalib,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetEncPosControlParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plPosSrcMode,
                                                                long *plPosCorrMode,
                                                                VBOOL *pbUseCalib,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetHostDigOPs (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            VBOOL bSet,
                                                            long *plBits,
                                                            long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetHostStatusBits (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long *plStatusBits,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPIDParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plProp,
                                                           long *plInt,
                                                           long *plDeriv,
                                                           long *plIntLimit,
                                                           long *plFilterCtrl,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetAdvancedDCParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long lChanID,
                                                               long *plTargetPos,
                                                               long *plTargetVel,
                                                               long *plIntSum,
                                                               long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetPotParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           VBOOL bSet,
                                                           long lChanID,
                                                           long *plZeroWnd,
                                                           long *plVel1,
                                                           long *plWnd1,
                                                           long *plVel2,
                                                           long *plWnd2,
                                                           long *plVel3,
                                                           long *plWnd3,
                                                           long *plVel4,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetIndicatorLEDMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long lLEDMode,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetIndicatorLEDMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long *plLEDMode,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetAVMode (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bSet, long lChanID,
                                                        long *plModeBits,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGetButtonParams (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              VBOOL bSet,
                                                              long lChanID,
                                                              long *plMode,
                                                              long *plPos1,
                                                              long *plPos2,
                                                              long *plTimeout1,
                                                              long *plTimeout2,
                                                              long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetOptoDCVelParams (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              long *plMinVel,
                                                              long *plAccn,
                                                              long *plMaxVel,
                                                              long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetOptoDCJogParams (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              long *plJogMode,
                                                              long *plJogStepSize,
                                                              long *plMinVel,
                                                              long *plAccn,
                                                              long *plMaxVel,
                                                              long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetOptoDCHomeParams (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long lChanID,
                                                               long *plDirection,
                                                               long *plLimSwitch,
                                                               long *plHomeVel,
                                                               long *plOffsetDist,
                                                               long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetParentHWInfo (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long *plHWSerialNum,
                                                         long *plHWType,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetButtonParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long lButMode,
                                                         float fLeftButPos,
                                                         float fRightButPos,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetButtonParams (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *plButMode,
                                                         float *pfLeftButPos,
                                                         float *pfRightButPos,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetPotParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long lVel1PotVal,
                                                      float fVel1,
                                                      long lVel2PotVal,
                                                      float fVel2,
                                                      long lVel3PotVal,
                                                      float fVel3,
                                                      long lVel4PotVal,
                                                      float fVel4,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPotParams (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long lChanID,
                                                      long *plVel1PotVal,
                                                      float *pfVel1,
                                                      long *plVel2PotVal,
                                                      float *pfVel2,
                                                      long *plVel3PotVal,
                                                      float *pfVel3,
                                                      long *plVel4PotVal,
                                                      float *pfVel4,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetEEPROMParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long lMsgID,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorShowSettingsDlg (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetCtrlStarted (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL *pbStarted,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHWCommsOK (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      VBOOL *pbCommsOK,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetPositionOffset (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float fPosOffset,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetGUIEnable (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bEnable,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetContextMenuEnable (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                VBOOL bEnabled,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetPosDispClickEventEnable (CAObjHandle objectHandle,
                                                                      ERRORINFO *errorInfo,
                                                                      VBOOL bEnabled,
                                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetPosDispDblClickEventEnable (CAObjHandle objectHandle,
                                                                         ERRORINFO *errorInfo,
                                                                         VBOOL bEnabled,
                                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPositionOffset (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *pfPosOffset,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDispMode (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lDispMode,
                                                     long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDispMode (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long *plDispMode,
                                                     long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetChannelSwitch (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetChannelSwitch (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long *plChanID,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorMoveAbsoluteRot (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         float fAnglePosCh1,
                                                         float fAnglePosCh2,
                                                         long lMoveMode,
                                                         VBOOL bWait,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParams_Accn (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetVelParams_MaxVel (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxisInfo_MinPos (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStageAxisInfo_MaxPos (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetRelMoveDist_RelDist (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetAbsMovePos_AbsPos (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBLashDist_BLashDist (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPosition_Position (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPositionEx_UncalibPosition (CAObjHandle objectHandle,
                                                                       ERRORINFO *errorInfo,
                                                                       long lChanID,
                                                                       float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogMode_Mode (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         long lChanID,
                                                         long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogMode_StopMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogStepSize_StepSize (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetStatusBits_Bits (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogVelParams_Accn (CAObjHandle objectHandle,
                                                              ERRORINFO *errorInfo,
                                                              long lChanID,
                                                              float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetJogVelParams_MaxVel (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHomeParams_HomeVel (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long lChanID,
                                                               float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHomeParams_ZeroOffset (CAObjHandle objectHandle,
                                                                  ERRORINFO *errorInfo,
                                                                  long lChanID,
                                                                  float *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPIDParams_Prop (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPIDParams_Int (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetPIDParams_Deriv (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_SetOperatingMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long lMode,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_GetOperatingMode (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             long *plMode,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_SetCycleParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float fOnTime,
                                                           float fOffTime,
                                                           long lNumCycles,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_GetCycleParams (CAObjHandle objectHandle,
                                                           ERRORINFO *errorInfo,
                                                           long lChanID,
                                                           float *pfOnTime,
                                                           float *pfOffTime,
                                                           long *plNumCycles,
                                                           long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_Enable (CAObjHandle objectHandle,
                                                   ERRORINFO *errorInfo,
                                                   long lChanID,
                                                   long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_Disable (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    long lChanID,
                                                    long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSC_GetOPState (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plState,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetBrakeState (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID, long lState,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBrakeState (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lChanID,
                                                       long *plState,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSuspendEndOfMoveMsgs (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLResumeEndOfMoveMsgs (CAObjHandle objectHandle,
                                                               ERRORINFO *errorInfo,
                                                               long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEnableEventDlg (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        VBOOL bEnable,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorShowEventDlg (CAObjHandle objectHandle,
                                                      ERRORINFO *errorInfo,
                                                      long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetRotStageModes (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long lMoveMode,
                                                          long lPosReportMode,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetRotStageModes (CAObjHandle objectHandle,
                                                          ERRORINFO *errorInfo,
                                                          long lChanID,
                                                          long *plMoveMode,
                                                          long *plPosReportMode,
                                                          long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLSetPMDParam (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lCommandCode,
                                                       long lParamCode,
                                                       long lVal,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorLLGetPMDParam (CAObjHandle objectHandle,
                                                       ERRORINFO *errorInfo,
                                                       long lCommandCode,
                                                       long lParamCode,
                                                       long *plVal,
                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCCurrentLoopParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lProp,
                                                                long lInt,
                                                                long lIntLim,
                                                                long lIntDeadBand,
                                                                long lFFwd,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCCurrentLoopParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plProp,
                                                                long *plInt,
                                                                long *plIntLim,
                                                                long *plIntDeadBand,
                                                                long *plFFwd,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCPositionLoopParams (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 long lProp,
                                                                 long lInt,
                                                                 long lIntLim,
                                                                 long lDeriv,
                                                                 long lDerivTime,
                                                                 long lLoopGain,
                                                                 long lVelFFwd,
                                                                 long lAccFFwd,
                                                                 long lPosErrLim,
                                                                 long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCPositionLoopParams (CAObjHandle objectHandle,
                                                                 ERRORINFO *errorInfo,
                                                                 long lChanID,
                                                                 long *plProp,
                                                                 long *plInt,
                                                                 long *plIntLim,
                                                                 long *plDeriv,
                                                                 long *plDerivTime,
                                                                 long *plLoopGain,
                                                                 long *plVelFFwd,
                                                                 long *plAccFFwd,
                                                                 long *plPosErrLim,
                                                                 long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCMotorOutputParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float fContCurrLim,
                                                                float fEnergyLim,
                                                                float fMotorLim,
                                                                float fMotorBias,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCMotorOutputParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                float *pfContCurrLim,
                                                                float *pfEnergyLim,
                                                                float *pfMotorLim,
                                                                float *pfMotorBias,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCTrackSettleParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lSettleTime,
                                                                long lSettleWnd,
                                                                long lTrackWnd,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCTrackSettleParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plSettleTime,
                                                                long *plSettleWnd,
                                                                long *plTrackWnd,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCProfileModeParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long lProfMode,
                                                                float fJerk,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCProfileModeParams (CAObjHandle objectHandle,
                                                                ERRORINFO *errorInfo,
                                                                long lChanID,
                                                                long *plProfMode,
                                                                float *pfJerk,
                                                                long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCJoystickParams (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             float fMaxVelLO,
                                                             float fMaxVelHI,
                                                             float fAccnLO,
                                                             float fAccnHI,
                                                             long lDirSense,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCJoystickParams (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long lChanID,
                                                             float *pfMaxVelLO,
                                                             float *pfMaxVelHI,
                                                             float *pfAccnLO,
                                                             float *pfAccnHI,
                                                             long *plDirSense,
                                                             long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCSettledCurrentLoopParams (CAObjHandle objectHandle,
                                                                       ERRORINFO *errorInfo,
                                                                       long lChanID,
                                                                       long lSettledProp,
                                                                       long lSettledInt,
                                                                       long lSettledIntLim,
                                                                       long lSettledIntDeadBand,
                                                                       long lSettledFFwd,
                                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCSettledCurrentLoopParams (CAObjHandle objectHandle,
                                                                       ERRORINFO *errorInfo,
                                                                       long lChanID,
                                                                       long *plSettledProp,
                                                                       long *plSettledInt,
                                                                       long *plSettledIntLim,
                                                                       long *plSettledIntDeadBand,
                                                                       long *plSettledFFwd,
                                                                       long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetBowIndex (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lChanID,
                                                     long lBowIndex,
                                                     long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetBowIndex (CAObjHandle objectHandle,
                                                     ERRORINFO *errorInfo,
                                                     long lChanID,
                                                     long *plBowIndex,
                                                     long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDCTriggerParams (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long lTrigInMode,
                                                            long lTrigOutMode,
                                                            long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDCTriggerParams (CAObjHandle objectHandle,
                                                            ERRORINFO *errorInfo,
                                                            long lChanID,
                                                            long *plTrigInMode,
                                                            long *plTrigOutMode,
                                                            long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetHWSerialNum (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetHWSerialNum (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long newValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetByRefHWSerialNum (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long *newValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetAPTHelp (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    VBOOL *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetAPTHelp (CAObjHandle objectHandle,
                                                    ERRORINFO *errorInfo,
                                                    VBOOL newValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetByRefAPTHelp (CAObjHandle objectHandle,
                                                         ERRORINFO *errorInfo,
                                                         VBOOL *newValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorGetDISPLAYMODE (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long *returnValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetDISPLAYMODE (CAObjHandle objectHandle,
                                                        ERRORINFO *errorInfo,
                                                        long newValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorSetByRefDISPLAYMODE (CAObjHandle objectHandle,
                                                             ERRORINFO *errorInfo,
                                                             long *newValue);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnMoveComplete (CAObjHandle serverObject,
                                                                 _DMG17MotorEventsRegOnMoveComplete_CallbackType callbackFunction,
                                                                 void *callbackData,
                                                                 int enableCallbacks,
                                                                 int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnHomeComplete (CAObjHandle serverObject,
                                                                 _DMG17MotorEventsRegOnHomeComplete_CallbackType callbackFunction,
                                                                 void *callbackData,
                                                                 int enableCallbacks,
                                                                 int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnMoveStopped (CAObjHandle serverObject,
                                                                _DMG17MotorEventsRegOnMoveStopped_CallbackType callbackFunction,
                                                                void *callbackData,
                                                                int enableCallbacks,
                                                                int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnHWResponse (CAObjHandle serverObject,
                                                               _DMG17MotorEventsRegOnHWResponse_CallbackType callbackFunction,
                                                               void *callbackData,
                                                               int enableCallbacks,
                                                               int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnSettingsChanged (CAObjHandle serverObject,
                                                                    _DMG17MotorEventsRegOnSettingsChanged_CallbackType callbackFunction,
                                                                    void *callbackData,
                                                                    int enableCallbacks,
                                                                    int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnEncCalibComplete (CAObjHandle serverObject,
                                                                     _DMG17MotorEventsRegOnEncCalibComplete_CallbackType callbackFunction,
                                                                     void *callbackData,
                                                                     int enableCallbacks,
                                                                     int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnPositionClick (CAObjHandle serverObject,
                                                                  _DMG17MotorEventsRegOnPositionClick_CallbackType callbackFunction,
                                                                  void *callbackData,
                                                                  int enableCallbacks,
                                                                  int *callbackId);

HRESULT CVIFUNC MG17MotorLib__DMG17MotorEventsRegOnPositionDblClick (CAObjHandle serverObject,
                                                                     _DMG17MotorEventsRegOnPositionDblClick_CallbackType callbackFunction,
                                                                     void *callbackData,
                                                                     int enableCallbacks,
                                                                     int *callbackId);
#ifdef __cplusplus
    }
#endif
#endif /* _MG17MOTORLIB_H */
