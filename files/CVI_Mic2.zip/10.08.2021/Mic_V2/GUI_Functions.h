#ifndef GUI_FUNCTIONS_INCLUDE  
#define GUI_FUNCTIONS_INCLUDE       


#include "DAQ_Control.h"
#include "MIC_V2.h"   


#define PARULA 0
#define JET 1
#define MAX_FILE_NAME_LENGTH 512
#define AOTF_COMMAND_SET_STATE 1
#define AOTF_COMMAND_SET_WAVE 2 
#define AOTF_COMMAND_SET_POWER 3 
#define SCALE_BAR_HEIGHT 256
#define SCALE_BAR_WIDTH 100
#define GRAPH_SIZE 500 

void SetGUI_InitialState (int panel, int graphPanel, int SpectralPanel);
int ShowHidePanel(int actionPanel,int actionControl, int reactionPanel );			 
int HidePanelAndChangeToggleState(int panelToHide, int panelWithControl, int ControlToChange, int State); 
int GetAOTF_IDs(int panelHandle, int *vis_id, int *nir_id,int *nir2_id) ;
int GetMotorsAxisIDs(int panelHandle, int *X_ID, int *Y_ID,int *Z_ID); 
void f_folder_browse (char *directory_name); 
int SaveGraphToImage(char *path, int panel, int control) ;
void PlotScaleBar(int panel, int control) ;

void SetGUI_ForDelayScan(int panel, int PlotPanel, int SpecPanel,int StndaPanel);  
void SetGUI_ForSpectralScan(int panel, int PlotPanel, int SpecPanel);  
int GetAOTF_ID_FromControlHandle(int control) ;
int GetAOTF_Channel_FromControlHandle(int control)  ;
int GetAOTF_Command_FromControlHandle(int control);
int GetAOTF_StateControl_FromControlHandle(int aotf_id, int channel);
int GetAOTFUsefullControlNumber(int control); 
int GetAOTFControlFromUsfulNumber (int num);
int  GetNumberOfActiveChannelsInEachGroup(int PanelHandelDAQsettings,int *group1, int *group2, int SeqArr[MAX_DAQ_AI_CHAN]);
int GetLocationTypeandNum_FromControl(int control);
void SetGUI_ForXYScan(int panel,int PlotPanel, int PlotChan2);
void SetGUI_AfterScan(int panel); 
int LoadColormap( int type, double max, double min);
int LoadColormap2( int type, double max, double min);
int  GetColorForPoint(double val, int graphNum); 
void PlotScanPoint(int panel, int control, double val, int Xloc, int Yloc, int graphScaleFactor); 
DAQtaskData	GetDaqChannelData(int chan, int panel);
void UpdateGraph(int panel, int graph, double **arr,int X_Size, int Y_Size, int ScaleFactor);
int JET_Color_MAP (int value,int max, int min );
void AddPointToSpectralChart(int PanelHandelSpectrarlChart, int wavelength, double XY_ScanMax,double XY_ScanMin);
void UpdatePlotListControl( int activeSeq[MAX_DAQ_AI_CHAN], int panelMain, int panel2);
#endif  //end Header Guard

