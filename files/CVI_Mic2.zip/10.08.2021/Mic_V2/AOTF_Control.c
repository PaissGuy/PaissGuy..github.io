#include "AOTF_Control.h"
#include <ansi_c.h>

int AOTF_VIS_ID;
int AOTF_NIR_ID;
int AOTF_NIR2_ID;


int SetAOTF_IDs(int vis_id, int nir_id, int nir2_id)
{
	AOTF_VIS_ID  = vis_id;
	AOTF_NIR_ID  = nir_id;
	AOTF_NIR2_ID = nir2_id;
	
	return 0;
}


int AOTFInitLibrary(void)
{
	int status = -1;
	hinstLib = NULL;
	hinstLib = LoadLibrary("AotfLibrary.dll");
	if (hinstLib != NULL)
	{
		AOTF_Open =  (AOTFOPENCLOSE) GetProcAddress(hinstLib, "AotfOpen");
		AOTF_Close =  (AOTFOPENCLOSE) GetProcAddress(hinstLib, "AotfClose");
		AOTF_Send =  (AOTFSEND) GetProcAddress(hinstLib, "AotfWrite");
		status = 0;
	}
	return status;
}

int AOTFCloseLibrary(void) //This function is called by the EndProgram_Sequance function in MIC_V2.c file line 555. Its main goal is to free the aotf dll. 
{
	if (hinstLib != NULL)
	{
		 FreeLibrary(hinstLib);
		 AOTF_Open = NULL;
		 AOTF_Close = NULL;
		 AOTF_Send = NULL;
	}
	return 0;
}

int AOTFSendStringCmd(char *cmd, int DevID)
{
	int cmdLen = 0;

	hAOTF = AOTF_Open(DevID);
	if (hAOTF != 0)
	{
		cmdLen = strlen(cmd);
		AOTF_Send(hAOTF, cmdLen, cmd);
		AOTF_Close(hAOTF);
	}
	return 0;
}

int Set_AOTF_ALL_Zero(void)
{
	char cmd[256]="";
	int cmdLen;

	
	for (int i =0; i<AOTF_DEV_NUM; ++i)
	{
		hAOTF = AOTF_Open(i);
		if (hAOTF)
		{
			cmdLen = sprintf (cmd, "dds a * 0\r\n");
			AOTF_Send(hAOTF, cmdLen, cmd);
			AOTF_Close(hAOTF);		
		}
	}
	return 0;
}

int Set_AOTF_freq(int DevID, int chan ,double freq)
{
	char cmd[256]="";
	int cmdLen;

	hAOTF = AOTF_Open(DevID);
	if (hAOTF != 0)
	{
		cmdLen = sprintf (cmd, "dds f %d %f\r\n", chan,freq);
		AOTF_Send(hAOTF, cmdLen, cmd);
		AOTF_Close(hAOTF);
	}	
	
	return 0;
}
int Set_AOTF_gain(int DevID, int chan, int gain)
{
	char cmd[256]="";
	int cmdLen;

	hAOTF = AOTF_Open(DevID);
	if (hAOTF != 0)
	{
		cmdLen = sprintf (cmd, "dds a %d %d\r\n", chan, gain);
		AOTF_Send(hAOTF, cmdLen, cmd);
		AOTF_Close(hAOTF);
	}	
	
	return 0;
}
int Set_AOTF_freq_gain(int DevID, int chan ,double freq, int gain)
{
	int cmdLen = 0;
	char cmd[256]="";

	hAOTF = AOTF_Open(DevID);
	if (hAOTF != 0)
	{
		cmdLen = sprintf (cmd, "dds f %d %f\r\ndds a %d %d\r\n", chan,freq,chan,gain);
		AOTF_Send(hAOTF, cmdLen, cmd);
		AOTF_Close(hAOTF);
	}
	
	return 0;
}
double Find_Freq_From_Wavelength_Dev(int aotf,int wavelength)
{
	double freq=0.0;
	switch (aotf)
	{
		case VIS:
			//freq= (6.308)*pow(wavelength,4)/(pow(10,9))+ (-1.649)*pow(wavelength,3)/(pow(10,5)) + (0.01646)*pow(wavelength,2) + (-7.601)*wavelength + (1478);  
			freq= (3.309)*pow(wavelength,4)/(pow(10,9))+ (-9.3107)*pow(wavelength,3)/(pow(10,6)) + (0.010087)*pow(wavelength,2) + (-5.1145)*wavelength + (1118.9);   //re-calibration 1/12/15
			break;
		
		case NIR:
			freq= (2.9933)*pow(wavelength,4)/(pow(10,10)) + (-1.2248)*pow(wavelength,3)/(pow(10,6)) + (0.001943)*pow(wavelength,2) + (-1.4699)*wavelength + (507.69);	 
			break;
			
		case NIR2:
			freq= 50.0-(wavelength-1100)/1000.0*25.0;	   //TODO: Update formula with fit of measured data
	}
	return freq;
}
int GetAOTF_Power(int wavelength, int aotf_type, int MaxPower)
{
	switch(aotf_type)
	{
		case VIS:
			 //Need to check max values for Referance saturation prevention
		 	return MaxPower;

	
		
		case NIR:
			return MaxPower;
			
	
		
		case NIR2:
			return MaxPower;
			
		
	}

	return 0;		
}

