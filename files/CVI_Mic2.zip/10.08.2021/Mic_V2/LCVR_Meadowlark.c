#include <utility.h>
#include <visa.h>
#include <formatio.h>
#include <userint.h>
#include <ansi_c.h>
#include "LCVR_Meadowlark.h"

#define MAX_ARRAY_SIZE 4096

static ViStatus SetTermCharAttributes(ViSession resourceName, ViByte terminationCharacter);  

ViSession LCVR_Session;
int LCVR_Status =-1;
int LCRV_CalMethod;
int LCVR_TYPE=LCRV_THORLABS;  

void LCRV_SendCMD (char* send_data)
{
 	ViStatus ViErr = 0;
	
	// Send the command to the instrument
	ViErrChk(viPrintf(LCVR_Session, "%s\r", send_data));

	// Send the formatted buffer to the instrument
	ViErrChk(viFlush(LCVR_Session, VI_WRITE_BUF));

	return;
Error:
    Close_LCVR_port();
}


int LCRV_Read(char* send_data)
{
	ViString output = 0;
    ViString output2 = 0;
	ViStatus ViErr = 0;
	int result;
	char s1[30],s2[30];
	
	LCRV_SendCMD (send_data); 
	
	// Recive string
	ViNullChk(output = (ViString)calloc(MAX_ARRAY_SIZE, sizeof(char)));
	ViNullChk(output2 = (ViString)calloc(MAX_ARRAY_SIZE, sizeof(char)));  
	sprintf (output, "");     
	sprintf (output2, "");     
	ViErrChk(viScanf(LCVR_Session, "%s", output));
	SetBreakOnLibraryErrors (0);
	ViErrChk(viScanf(LCVR_Session, "%s", output2));
	SetBreakOnLibraryErrors (1);
	//Parse string
	 sscanf(output2, "%[^','],%s", s1, s2);
	 result=atoi(s2);

	return result;
Error:
		return -1;
}

int THORLABS_test_Seq(double Vlow, double Vhigh, int dewell_ms , double Vincrament)
{
		
	char cmd[50]=""; 
	
		sprintf (cmd, "dwell==%d",dewell_ms);
		LCRV_SendCMD(cmd);  
		Delay(1);
		sprintf (cmd, "increment=%lf",Vincrament);
		LCRV_SendCMD(cmd);  
		Delay(1);
		sprintf (cmd, "min=%lf",Vlow);
		LCRV_SendCMD(cmd);  
		Delay(1);
		sprintf (cmd, "max=%lf",Vhigh);
		LCRV_SendCMD(cmd);  
		Delay(1);
		sprintf (cmd, "test");
		LCRV_SendCMD(cmd);  
		Delay(1);
	
		
		return 0;
}


int LCVR_Set_Modulation_V (int chan, double Voltage)  //chan=1,2,3,4
{
	int Vint=0,Vchk=0;
	char cmd[50]="",cmd2[50]="";
	
	switch(LCVR_TYPE)
	{
		case  LCVR_MEADOWLARK:
	
			Vint= (int) (Voltage*6553.5);	
		    sprintf (cmd, "ld:%d,%i" ,chan,Vint);
			sprintf (cmd2, "ld:%d,?" ,chan); 
			LCRV_SendCMD(cmd); 
			Vchk=LCRV_Read(cmd2); 
	   	break;
		
		case  LCRV_THORLABS:
			sprintf (cmd, "volt1=%lf",Voltage); 
			sprintf (cmd2, "volt1?"); 
			LCRV_SendCMD(cmd); 
			return 0;
	   	break;   
	}
	
	  
	if(Vchk>-1)
		return  Vchk-Vint;
	else
		return -1;
}

void LCRV_Output_SYNC_Pulse (void)
{
	int Vint;
	char cmd[10]="";
	
	sprintf (cmd, "sout:" );
	LCRV_SendCMD(cmd);
	
}

double LCRV_Get_Retardation_Voltage(int wavelength, int retardation)
{
// ZERO_LAMBDA 0						  	
// QWP_LAMBDA 1	//LCP
// HWP_LAMBDA 2
// THREE_QWP_LAMBDA 3   //RCP
	
	double Vout =0.0;   
	int Col_index,line_index;
	int ValFound=0;
	
	switch( retardation)
		{
			case ZERO_LAMBDA:
				Col_index=4;
				break;
			case QWP_LAMBDA:
				Col_index=1;//+LCRV_CalMethod*4;
				break;
			case HWP_LAMBDA:
				Col_index=3;
				break;
			case THREE_QWP_LAMBDA:
				Col_index=2;//+LCRV_CalMethod*4;
				break;		
			
		}
	
	switch(LCVR_TYPE)
		{
		case  LCVR_MEADOWLARK:
	
		//Wavelength QWP		3QWP		HWP			WP			
			double CalibrationMatrix[][5]=	   
			{{	460	,	3.942	,	1.811	,	2.342	,	1.494	}	,
			{	465	,	3.884	,	1.791	,	2.32	,	1.476	}	,
			{	470	,	3.838	,	1.772	,	2.294	,	1.458	}	,
			{	475	,	3.772	,	1.752	,	2.27	,	1.441	}	,
			{	480	,	3.734	,	1.736	,	2.248	,	1.424	}	,
			{	485	,	3.682	,	1.718	,	2.225	,	1.406	}	,
			{	490	,	3.632	,	1.701	,	2.198	,	1.391	}	,
			{	495	,	3.592	,	1.685	,	2.182	,	1.375	}	,
			{	500	,	3.538	,	1.666	,	2.158	,	1.357	}	,
			{	505	,	3.502	,	1.651	,	2.136	,	1.341	}	,
			{	510	,	3.458	,	1.636	,	2.121	,	1.326	}	,
			{	515	,	3.42	,	1.621	,	2.099	,	1.311	}	,
			{	520	,	3.384	,	1.605	,	2.084	,	1.296	}	,
			{	525	,	3.346	,	1.591	,	2.067	,	1.282	}	,
			{	530	,	3.31	,	1.577	,	2.047	,	1.267	}	,
			{	535	,	3.28	,	1.562	,	2.03	,	1.253	}	,
			{	540	,	3.246	,	1.55	,	2.017	,	1.24	}	,
			{	545	,	3.218	,	1.536	,	1.998	,	1.225	}	,
			{	550	,	3.192	,	1.524	,	1.985	,	1.211	}	,
			{	555	,	3.16	,	1.51	,	1.971	,	1.199	}	,
			{	560	,	3.126	,	1.498	,	1.954	,	1.185	}	,
			{	565	,	3.102	,	1.485	,	1.939	,	1.17	}	,
			{	570	,	3.08	,	1.472	,	1.93	,	1.159	}	,
			{	575	,	3.06	,	1.462	,	1.916	,	1.146	}	,
			{	580	,	3.046	,	1.452	,	1.904	,	1.135	}	,
			{	585	,	3.014	,	1.439	,	1.891	,	1.12	}	,
			{	590	,	2.982	,	1.426	,	1.878	,	1.106	}	,
			{	595	,	2.956	,	1.415	,	1.861	,	1.093	}	,
			{	600	,	2.932	,	1.402	,	1.848	,	1.08	}	,
			{	605	,	2.908	,	1.391	,	1.837	,	1.066	}	,
			{	610	,	2.89	,	1.381	,	1.833	,	1.055	}	,
			{	615	,	2.87	,	1.371	,	1.814	,	1.041	}	,
			{	620	,	2.85	,	1.359	,	1.797	,	1.026	}	,
			{	625	,	2.812	,	1.345	,	1.789	,	1.011	}	,
			{	630	,	2.788	,	1.335	,	1.778	,	1	}	,
			{	635	,	2.774	,	1.326	,	1.763	,	0.986	}	,
			{	640	,	2.76	,	1.315	,	1.751	,	0.971	}	,
			{	645	,	2.728	,	1.3	,	1.742	,	0.956	}	,
			{	650	,	2.698	,	1.29	,	1.733	,	0.943	}	,
			{	655	,	2.686	,	1.284	,	1.721	,	0.93	}	,
			{	660	,	2.682	,	1.275	,	1.71	,	0.916	}	,
			{	665	,	2.67	,	1.26	,	1.698	,	0.901	}	,
			{	670	,	2.63	,	1.246	,	1.689	,	0.885	}	,
			{	675	,	2.6	,	1.237	,	1.68	,	0.868	}	,
			{	680	,	2.59	,	1.23	,	1.665	,	0.854	}	,
			{	685	,	2.594	,	1.224	,	1.655	,	0.84	}	,
			{	690	,	2.584	,	1.21	,	1.646	,	0.821	}	,
			{	695	,	2.55	,	1.196	,	1.642	,	0.801	}	,
			{	700	,	2.516	,	1.186	,	1.631	,	0.78	}	,
			{	705	,	2.5	,	1.18	,	1.62	,	0.759	}	,
			{	710	,	2.508	,	1.175	,	1.606	,	0.737	}	,
			{	715	,	2.514	,	1.165	,	1.595	,	0.711	}	,
			{	720	,	2.498	,	1.15	,	1.594	,	0.672	}};	


	   
				
			line_index=(wavelength-CalibrationMatrix[0][0])/5;
			if (line_index>=0 && line_index<54)
				{
					Vout=CalibrationMatrix[line_index][Col_index];
					ValFound=1;
				}	
	
			break;
	   
	   case  LCRV_THORLABS:
	
		//Wavelength QWP		3QWP		HWP			WP			
			double CalibrationMatrix2[][5]=
			{{	470	,	3.945	,	1.7925	,	2.3275	,	1.475	}	,
			{	475	,	3.88	,	1.775	,	2.3025	,	1.4575	}	,
			{	480	,	3.845	,	1.7575	,	2.2775	,	1.4425	}	,
			{	485	,	3.78	,	1.7375	,	2.2575	,	1.4225	}	,
			{	490	,	3.735	,	1.7225	,	2.23	,	1.4075	}	,
			{	495	,	3.695	,	1.705	,	2.2125	,	1.3925	}	,
			{	500	,	3.635	,	1.6875	,	2.1925	,	1.375	}	,
			{	505	,	3.605	,	1.6725	,	2.1675	,	1.36	}	,
			{	510	,	3.555	,	1.6575	,	2.155	,	1.345	}	,
			{	515	,	3.515	,	1.6425	,	2.13	,	1.3275	}	,
			{	520	,	3.475	,	1.625	,	2.1125	,	1.3125	}	,
			{	525	,	3.435	,	1.61	,	2.0975	,	1.2975	}	,
			{	530	,	3.395	,	1.5975	,	2.075	,	1.2825	}	,
			{	535	,	3.365	,	1.58	,	2.06	,	1.27	}	,
			{	540	,	3.325	,	1.5675	,	2.045	,	1.255	}	,
			{	545	,	3.295	,	1.555	,	2.025	,	1.24	}	,
			{	550	,	3.27	,	1.54	,	2.0125	,	1.2275	}	,
			{	555	,	3.23	,	1.5275	,	1.9975	,	1.2125	}	,
			{	560	,	3.20	,	1.515	,	1.9825	,	1.2	}	,
			{	565	,	3.175	,	1.5025	,	1.965	,	1.185	}	,
			{	570	,	3.15	,	1.49	,	1.9525	,	1.1725	}	,
			{	575	,	3.13	,	1.48	,	1.9425	,	1.16	}	,
			{	580	,	3.115	,	1.47	,	1.9275	,	1.15	}	,
			{	585	,	3.075	,	1.455	,	1.915	,	1.135	}	,
			{	590	,	3.04	,	1.4425	,	1.90	,	1.12	}	,
			{	595	,	3.015	,	1.43	,	1.885	,	1.1075	}	,
			{	600	,	2.99	,	1.4175	,	1.8675	,	1.0925	}	,
			{	605	,	2.96	,	1.405	,	1.86	,	1.08	}	,
			{	610	,	2.94	,	1.3975	,	1.85	,	1.0675	}	,
			{	615	,	2.92	,	1.385	,	1.835	,	1.055	}	,
			{	620	,	2.89	,	1.3725	,	1.82	,	1.04	}	,
			{	625	,	2.86	,	1.3575	,	1.8075	,	1.025	}	,
			{	630	,	2.83	,	1.35	,	1.7975	,	1.0125	}	,
			{	635	,	2.82	,	1.340	,	1.78	,	1.00	}	,
			{	640	,	2.80	,	1.3275	,	1.7675	,	0.985	}	,
			{	645	,	2.77	,	1.315	,	1.76	,	0.97	}	,
			{	650	,	2.74	,	1.305	,	1.75	,	0.9575	}};	

			
			line_index=(wavelength-CalibrationMatrix2[0][0])/5;
			if (line_index>=0 && line_index<54)
				{
					Vout=CalibrationMatrix2[line_index][Col_index];
					ValFound=1;
				}	
	   		break;

		}

	if (ValFound) return Vout;
		
	
	switch( retardation)
	{											 	 
		case ZERO_LAMBDA:
			  Vout=-2.8671/ pow (10, 8) * pow (wavelength, 3)+5.406/ pow (10, 5) * pow (wavelength, 2)-0.037092*wavelength+10.966;
			//Vout=4.2519/ pow (10, 10) * pow (wavelength, 4)-9.6586/ pow (10, 7)* pow (wavelength, 3)+0.00082537* pow (wavelength, 2)-0.318*wavelength+49.172; 
			break;
		case QWP_LAMBDA:
			  Vout=-5.7942/ pow (10, 8) * pow (wavelength, 3)+0.00012906 * pow (wavelength, 2)-0.099033*wavelength+30.019;
			//Vout= 3.0959/ pow (10, 10) * pow (wavelength, 4)-8.055/ pow (10,7)* pow (wavelength, 3)+0.0008027* pow (wavelength, 2)-0.36845*wavelength+70.554; 
			break;
		case HWP_LAMBDA:
			  Vout= 3.2773/ pow (10, 10) * pow (wavelength, 4)-7.6127/ pow (10, 7)* pow (wavelength, 3)+0.00067433* pow (wavelength, 2)-0.27385*wavelength+46.5;
			//Vout= 1.5043/ pow (10, 10) * pow (wavelength, 4)-3.9032/ pow (10, 7)* pow (wavelength, 3)+0.00038675* pow (wavelength, 2)-0.17617*wavelength+34.273;  
			break;
		case THREE_QWP_LAMBDA:
			 // Vout=-2.307/ pow (10, 8) * pow (wavelength, 3)+4.7624/pow (10, 5) * pow (wavelength, 2)-0.035288*wavelength+11.398; 
			Vout=  3.8804/ pow (10, 10) * pow (wavelength, 4)-8.9012/ pow (10, 7)* pow (wavelength, 3)+0.00077202* pow (wavelength, 2)-0.30347*wavelength+48.509;  
			break;
			
	}
return Vout;	
	
}
void LCRV_Set_Retardation (int wavelength, int retardation, int chan)
{
	
//Retardation curve function:
	double Vout =0.0;

// ZERO_LAMBDA 0						  	
// QWP_LAMBDA 1	//LCP
// HWP_LAMBDA 2
// THREE_QWP_LAMBDA 3   //RCP

	Vout= LCRV_Get_Retardation_Voltage( wavelength,  retardation); 
	LCVR_Set_Modulation_V(chan, Vout);
	
}
void Close_LCVR_port(void)
{

 	viClose (LCVR_Session);  
}


int OPEN_LCVR_port(ViSession resManeger )
{

	ViStatus ViErr = 0;
    ViString output = 0;

	switch(LCVR_TYPE)
	{
	case  LCVR_MEADOWLARK:
		// Open a session to the instrument
		ViErrChk(viOpen (resManeger, LCVR_DEVICE_NAME, 4, VI_NULL, &LCVR_Session));  
		ViErrChk(viSetAttribute (LCVR_Session, VI_ATTR_ASRL_BAUD, LCVR_BUAD_RATE));
		break;
	
	case  LCRV_THORLABS:
		// Open a session to the instrument
		ViErrChk(viOpen (resManeger, THORLABS_LCVR_DEVICE_NAME, 4, VI_NULL, &LCVR_Session));  
		ViErrChk(viSetAttribute (LCVR_Session, VI_ATTR_ASRL_BAUD, THORLABS_LCVR_BUAD_RATE));
		break;	
	}
	// Set the timeout
	ViErrChk(viSetAttribute (LCVR_Session, VI_ATTR_ASRL_DATA_BITS, 8));
	ViErrChk(viSetAttribute (LCVR_Session, VI_ATTR_TMO_VALUE, 3000));
	
	ViErrChk(viSetAttribute (LCVR_Session, VI_ATTR_TERMCHAR_EN, VI_TRUE));
	ViErrChk(SetTermCharAttributes(LCVR_Session, 13)); 
	//Set the termination character attributes

	LCVR_Status = 1;
	
	return LCVR_Status;
Error:
	LCVR_Status =-1;
return LCVR_Status;	

}

static ViStatus SetTermCharAttributes(ViSession resourceName, ViByte terminationCharacter)
{
	ViStatus ViErr = VI_SUCCESS;
	ViUInt16 intfType = 0;

	// Set the termination character attributes if this is a serial resource
	ViErrChk(viGetAttribute(resourceName, VI_ATTR_INTF_TYPE, &intfType));
	if (intfType == VI_INTF_ASRL) {
		if (terminationCharacter > 0) {
			ViErrChk(viSetAttribute(resourceName, VI_ATTR_ASRL_END_IN, VI_ASRL_END_TERMCHAR));
		}
		else {
			ViErrChk(viSetAttribute(resourceName, VI_ATTR_ASRL_END_IN, VI_ASRL_END_NONE));
		}
	}
	ViErrChk(viSetAttribute(resourceName, VI_ATTR_TERMCHAR_EN, (terminationCharacter > 0)));
	ViErrChk(viSetAttribute(resourceName, VI_ATTR_TERMCHAR, terminationCharacter));

Error:
	return ViErr;
}
void Start_THORLABS_LCRV_Sequance(void)
{
	LCRV_SendCMD ("remote=1"); 
	Delay(0.20);  
	LCRV_SendCMD ("mode=1"); 
	Delay(0.20);  
	LCRV_SendCMD ("enable=1");
	Delay(0.2);
	LCVR_Set_Modulation_V(2,0.0);
	
}
