#include <formatio.h>
#include <userint.h>
#include <utility.h>
#include <ansi_c.h>
#include "LCVR_Meadowlark.h"

int port_open;		//Com Port Status      

void LVCR_DisplayRS232Error (int RS232Error)
{
    char ErrorMessage[200];
    switch (RS232Error)
        {
        default :
            if (RS232Error < 0)
                {  
                Fmt (ErrorMessage, "%s<RS232 error number %i", RS232Error);
                MessagePopup ("RS232 Message", ErrorMessage);
                }
            break;
        case 0  :
            MessagePopup ("RS232 Message", "No errors.");
            break;
        case -2 :
            Fmt (ErrorMessage, "%s", "Invalid port number (must be in the "
                                     "range 1 to 8).");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        case -3 :
            Fmt (ErrorMessage, "%s", "No port is open.\n"
                 "Check COM Port setting in Configure.");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        case -99 :
            Fmt (ErrorMessage, "%s", "Timeout error.\n\n"
                 "Either increase timeout value,\n"
                 "       check COM Port setting, or\n"
                 "       check device.");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        }
}

int  LVCR_FlushOutQCallBack (int comport)
{
 
 	FlushOutQ (comport);
    return 0;
Error:
	return -1;
}
void LCRV_SendCMD (char* send_data)
{
    int stringsize,bytes_sent;
	
	stringsize = StringLength (send_data);
    bytes_sent = ComWrt (LCVR_COM_PORT, send_data, stringsize);
}


int LCRV_Read_Status(char* send_data)
{
	char data[50]="",data2[10]=""; 
	int kk,ind=0,Vout;
	
	LCRV_SendCMD(send_data);
	Delay(0.01);
	ComRd (LCVR_COM_PORT, data, 48);
	if (strlen(data)<7) return -1;
	strncpy(data2, data + 6, strlen(data) - 6);
	Vout=atoi(data2);
	return Vout;
			   
}

int LCVR_Set_Modulation_V (int chan, double Voltage)  //chan=1,2,3,4
{
	int Vint=0,Vchk=0;
	char cmd[50]="",cmd2[50]="";
	
	Vint= (int) Voltage*6553.5;	
    sprintf (cmd, "ld:%d,%i\r" ,chan,Vint);
	sprintf (cmd2, "ld:%d,?\r" ,chan); 
	
	LCRV_SendCMD(cmd);
	Delay(0.02); 
	Vchk=LCRV_Read_Status(cmd2);   
	
	return  Vchk-Vint;
}

void LCRV_Output_SYNC_Pulse (void)
{
	int Vint;
	char cmd[10]="";
	
	sprintf (cmd, "sout:\r\n" );
	LCRV_SendCMD(cmd);
	
}

void LCRV_Set_Retardation (int wavelength, int retardation, int chan)
{
	
//Retardation curve function:
	double Vout =0.0;

	Vout= wavelength*retardation;//*V(ret,wavelength);	
	
	LCVR_Set_Modulation_V(chan, Vout);
	
}

void OPEN_LCVR_port_RS232(void)
{
	int RS232Error=0;
	
	DisableBreakOnLibraryErrors (); 
	RS232Error=OpenComConfig (LCVR_COM_PORT, LCVR_DEVICE_NAME, LCVR_BUAD_RATE, 0, 8, 1, 512, 512);
	EnableBreakOnLibraryErrors ();      
	
	if (RS232Error) LVCR_DisplayRS232Error (RS232Error);
    if (RS232Error == 0)
    {
          port_open = 1;
          SetXMode (LCVR_COM_PORT, 0);
          SetCTSMode (LCVR_COM_PORT, 0);
   	      SetComTime (LCVR_COM_PORT, 5);
	}
}	

void Close_LCVR_port_RS232(void)
{
	int  RS232Error=0, outqlen;
	
	if (port_open)
                {
                
                do
                {
					outqlen = GetOutQLen (LCVR_COM_PORT);
					Delay(0.01); 
				}while (outqlen > 0); 
				
                RS232Error = CloseCom (LCVR_COM_PORT);
                if (RS232Error)
                    LVCR_DisplayRS232Error (RS232Error);
                }
				port_open=0;

}
