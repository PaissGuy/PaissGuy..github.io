#ifndef MICRONIX_CONTROL_INCLUDE  

#define MICRONIX_CONTROL_INCLUDE  

#include <visa.h> 


#define Micronix_COM_PORT    "COM8" 

#define ViErrChk(WrappedFunc) {ViErr = (WrappedFunc); if (ViErr < 0) {goto Error;}}
#define ViNullChk(WrappedFunc) {if (0 == (WrappedFunc)) {ViErr = VI_ERROR_ALLOC; goto Error;}}
#define MAX_ARRAY_SIZE 4096
#define MAX_MICRONIX_CMD_LEN 128


// Micronix commands for use swich case, for multithreading
#define MOTOR_MOVE_REL 100  
#define MOTOR_SET_SPEED 101
#define MOTOR_SET_ACCELERATION 102
#define MOTOR_HOME 103
#define MOTOR_SET_PID 104
#define MOTOR_MOVE_ABS 105
#define MOTOR_STOP 106
#define MOTOR_POS_QUARY 107
#define MAX_MICRONIX_CMD_LEN 256
#define MICRONIX_ALL_AXES 0
typedef struct MicronixFunctionData 
{
	int Axis;
	double data1;
	double data2;
	double data3;
} MicronixData;


int OpenMicronixPort( ViSession resManeger );  
int SetMotorsAxisIDs(int X_ID, int Y_ID, int Z_ID);
int  InitializeMicronixStages(void);
ViStatus MicronixSendCMD(char* cmdString);
ViStatus MicronixQuarry(char* quaryString, char* respondString);
int MicronixMoveRelative(MicronixData *Params);  // Axis + step size
int MicronixMoveAbsolute(MicronixData *Params);  // Axis + location
int MicronixSpeed(MicronixData *Params);		 // Axis + speed
int MicronixAcceleration(MicronixData *Params);  // Axis + acc
int MicronixPIDparameters(MicronixData *Params); // Axis + p + I  + D
int MicronixMoveHOME(MicronixData *Params);		 // Axis
int MicronixSetZero();
int MicronixStop(MicronixData *Params);			 // Axis
ViStatus CloseMicronixInstrSession(void) ;
double MicronixPOS_Query(int Axis);
ViStatus MicronixWaitUntilReady(int Axis);
static ViStatus SetTermCharAttributes(ViSession session, ViByte terminationCharacter);
int Micronixthreaded(MicronixData *Params, int cmdType);
void MotorErrors (void);




#endif  //end Header Guard





 



