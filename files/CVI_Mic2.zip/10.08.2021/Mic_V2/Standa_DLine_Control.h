#include <ansi_c.h>
//#include <ctype.h>
#include <USMCDLL.h>
#include <userint.h>
#include <stdio.h>
#include <stdbool.h>
#include <utility.h> 

#define Standa_Delay_Time 0.0005

//Global Variables

USMC_Devices DVS;
DWORD Dev;
USMC_State State;
USMC_Mode Mode;
USMC_Parameters MotorParams;
USMC_StartParameters Start_Motor_Param;

int dest_point;
float speed;


//Prototype:
void Step(int microns);
void Step2(int *steps); 
void Move();
void SetMovingData();
void My_Init_Motor(); 
void Motor_Go();
void Set_Position(int position);
int CloseController();
bool F1_Get_Device_State(void);
void Set_My_Mode();
void Set_Start_Param();
void PopError(void);
void MyCloseStanda();


