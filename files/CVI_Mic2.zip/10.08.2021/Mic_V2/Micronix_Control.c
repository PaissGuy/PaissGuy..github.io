#include <ansi_c.h>
#include <utility.h>
#include <userint.h>
#include "MIC_V2.h"
#include "Micronix_Control.h"

/*The following pragma tells the 
compiler to turn off warnings for unreferenced identifiers.*/
#pragma DisableUnreferencedIdentifiers	  

// Module Global Varibles//
int MicronixLock; 
int MicronixThreadID;
ViSession MicronixSession;
int MicronixStatus =-1;
char MicronixErrorString[2048];

static ViChar formatString[255];
static ViStatus SetTermCharAttributes(ViSession MicronixSession, ViByte terminationCharacter);

int X_AXIS;
int Y_AXIS;
int Z_AXIS;



int Micronixthreaded(MicronixData *Params, int cmdType)
{
	if(MicronixStatus<0) return -1;
	switch (cmdType)
	{
		case MOTOR_MOVE_ABS:								  //(DEFAULT_THREAD_POOL_HANDLE, MicronixMoveAbsolute, Params, &MicronixThreadID);
			MicronixStatus = CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, MicronixMoveAbsolute, Params, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL,  RUN_IN_SCHEDULED_THREAD, &MicronixThreadID);
		break;
														   
		case MOTOR_MOVE_REL:								 //(DEFAULT_THREAD_POOL_HANDLE, MicronixMoveRelative, Params, &MicronixThreadID);
			MicronixStatus = CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, MicronixMoveRelative, Params, THREAD_PRIORITY_HIGHEST, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, RUN_IN_SCHEDULED_THREAD,&MicronixThreadID);
		break;

		case MOTOR_STOP:
			 MicronixStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, MicronixStop, Params, &MicronixThreadID);
		break;
		
		case MOTOR_SET_PID:
			 MicronixStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, MicronixPIDparameters, Params, &MicronixThreadID);
		break;
		
		case MOTOR_SET_SPEED:
			 MicronixStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, MicronixSpeed, Params, &MicronixThreadID);
		break;
		
		case MOTOR_SET_ACCELERATION:
			 MicronixStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, MicronixAcceleration, Params, &MicronixThreadID);
		break;
		
		case MOTOR_HOME:
			 MicronixStatus = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, MicronixMoveHOME, Params, &MicronixThreadID);
		break;
	
	}
	CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, MicronixThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	return MicronixStatus;
}
	
//  Begin Module functions  //
int OpenMicronixPort(ViSession resManeger )
{
	ViStatus ViErr = 0;
    ViString output = 0;
	
	// Open a session to the instrument
	ViErrChk(viOpen(resManeger, Micronix_COM_PORT, 4, VI_NULL, &MicronixSession));
	// Set the timeout
	ViErrChk(viSetAttribute (MicronixSession, VI_ATTR_TMO_VALUE, 3000));
	//Set the termination character attributes
	ViErrChk(SetTermCharAttributes(MicronixSession, 13));
	
	CmtNewLock (NULL, 0, &MicronixLock);  //create thread lock
	MicronixStatus = 1;
	
	return MicronixStatus;
Error:
	MicronixStatus =-1;
return MicronixStatus;	

}


int SetMotorsAxisIDs(int X_ID, int Y_ID, int Z_ID)
{
	X_AXIS=X_ID;
	Y_AXIS=Y_ID;
	Z_AXIS=Z_ID;
	
	return 1;
}

ViStatus MicronixSendCMD(char* cmdString)
{
	ViStatus ViErr = 0;	
	
	ViErrChk(viFlush(MicronixSession, VI_READ_BUF_DISCARD));
	
	ViErrChk(viPrintf(MicronixSession, "%s\n\r", cmdString));	 
	ViErrChk(viFlush(MicronixSession, VI_WRITE_BUF)); 	
	return 1;
	
Error:
	MotorErrors();
	return ViErr;
}
ViStatus MicronixQuarry(char* quaryString, char* respondString)
{
	ViStatus ViErr = 0;	
	

	ViErrChk(viFlush(MicronixSession, VI_READ_BUF_DISCARD));
	//ViErrChk(viPrintf(MicronixSession, "%s\n\r", quaryString));	 
	ViErrChk(viWrite (MicronixSession, quaryString,strlen(quaryString) , VI_NULL));
	ViErrChk(viFlush(MicronixSession, VI_WRITE_BUF)); 	
//	ViErrChk(viScanf(MicronixSession, respondString)); 
	ViErrChk(viRead(MicronixSession, respondString, 1024, VI_NULL));
	
	Delay(0.05);		//comunication delay    
	
	return 1;
	
Error: 
	return ViErr;
} 
 
int InitializeMicronixStages(void)  // This function main goal is 
{
	
	ViStatus ViErr = 0;
	char  response[MAX_MICRONIX_CMD_LEN] ="";
	
	   
	
	MicronixSendCMD("1ANR1;2ANR2;3ANR3");  	//Set device numbers
	Delay(0.05);							//comunication delay
 	MicronixSendCMD("0CER");			  	//Clear errors 
	Delay(0.05);							//comunication delay 
	MicronixSendCMD("0MOT1");			  	//Turn on motors power 
	Delay(0.05);							//comunication delay
																 
	//Encoder settings
	MicronixSendCMD("0EAD0");				//Encoder set to digital 						 
	Delay(0.05);							//comunication delay 
	MicronixSendCMD("0DBD1,0");				//Set deadband to 1 encoder count
	Delay(0.05);							//comunication delay 
	
	//move settings
	MicronixSendCMD("1FBK3");				//feadback mode 
	Delay(0.05);							//comunication delay 	
	MicronixSendCMD("2FBK3");				//feadback mode 
	Delay(0.05);							//comunication delay
	MicronixSendCMD("3FBK3");				//feadback mode 
	Delay(0.05);							//comunication delay 
	MicronixSendCMD("0VEL0.15");				//Set Move Speed
	Delay(0.05);							//comunication delay 
	MicronixSendCMD("0ACC0.2");			//Set Acceleration Speed          
	Delay(0.05);							//comunication delay 

	
	return 1;
Error:
	CloseMicronixInstrSession(); 
	MessagePopup ("ERROR ON STARTUP", "Errror on startup commands");
	return -1;
}

int MicronixMoveRelative(MicronixData *Params)  //Moves Axis#  relative to current position in RelMove [mm]
{

	char cmd[MAX_MICRONIX_CMD_LEN];
	
	CmtGetLock (MicronixLock);  
	sprintf(cmd,"%d%s%3.6lf\n\r", Params->Axis,"MVR", Params->data1);
	MicronixSendCMD(cmd);
	MicronixWaitUntilReady(Params->Axis);
	CmtReleaseLock (MicronixLock);
	return 1;
}
int MicronixMoveAbsolute(MicronixData *Params)  //Moves Axis# to position [mm]
{

	char cmd[MAX_MICRONIX_CMD_LEN];
	CmtGetLock (MicronixLock);  
	
	sprintf(cmd,"%d%s%3.6lf\n\r", Params->Axis,"MVA",Params->data1);
	MicronixSendCMD(cmd);
	MicronixWaitUntilReady(Params->Axis);
	CmtReleaseLock (MicronixLock);
	return 1;

}
int MicronixSpeed(MicronixData *Params)  //Set Axis#  Speed      
{
	char cmd[MAX_MICRONIX_CMD_LEN];
	CmtGetLock (MicronixLock);
	sprintf(cmd,"%d%s%1.3lf\n\r", Params->Axis,"VEL",Params->data1);
	MicronixSendCMD(cmd);
	CmtReleaseLock (MicronixLock);
	return 1;
}
int MicronixAcceleration(MicronixData *Params)  //Set Axis#  Acceleration
{


	char cmd[MAX_MICRONIX_CMD_LEN];
	CmtGetLock (MicronixLock); 
	sprintf(cmd,"%d%s%1.3lf\n\r", Params->Axis,"ACC",Params->data1);
	MicronixSendCMD(cmd);
	CmtReleaseLock (MicronixLock);
	return 1;
}
int MicronixPIDparameters(MicronixData *Params)  //Set Axis#  PID parameters
{

	char cmd[MAX_MICRONIX_CMD_LEN];
	CmtGetLock (MicronixLock);  
	sprintf(cmd,"%d%s%1.3lf,%1.3lf,%1.3lf\n\r", Params->Axis,"PID",Params->data1,Params->data2,Params->data3);
	MicronixSendCMD(cmd);
	CmtReleaseLock (MicronixLock);
	return 1;
}
int MicronixShutDown(void)
{
	MicronixSendCMD("0MOT0");
	return 1;
}

int MicronixMoveHOME(MicronixData *Params)  //Moves Axis#  back to HOME possition
{

	char cmd[MAX_MICRONIX_CMD_LEN];
	CmtGetLock (MicronixLock);  
	sprintf(cmd, "%d%s\n\r", Params->Axis,"HOM");
	MicronixSendCMD(cmd);	
	CmtReleaseLock (MicronixLock);
	return 1;
}

int MicronixSetZero()  //Set Current X,Y Axis posotion to be the new Zero location
{
    char cmd[MAX_MICRONIX_CMD_LEN];
	CmtGetLock (MicronixLock);  
	sprintf(cmd, "%s\n\r", "1ZRO;2ZRO");
	MicronixSendCMD(cmd);
	CmtReleaseLock (MicronixLock);	
	return 1;
}

int MicronixStop(MicronixData *Params)  //Stop Motion of Axis #
{
	char cmd[MAX_MICRONIX_CMD_LEN];
	
	CmtGetLock (MicronixLock);  
	sprintf(cmd, "%d%s\n\r", Params->Axis,"STP");
	MicronixSendCMD(cmd);	
	CmtReleaseLock (MicronixLock);
	return 1;

}

void MicronixClearErrors(void)
{

	CmtGetLock (MicronixLock);  
	MicronixSendCMD("0CER");
	CmtReleaseLock (MicronixLock);	
}
ViStatus CloseMicronixInstrSession(void)
{
	ViStatus ViErr = VI_SUCCESS;

	if (MicronixSession) {
		// Close the session
		ViErrChk(viClose(MicronixSession));
	}

	CmtDiscardLock (MicronixLock);
	
Error:
	MicronixStop(0);
	return ViErr;
}
double MicronixPOS_Query(int Axis)  //Ask Axis#  for possition
{
	ViStatus ViErr = 0;
    ViReal64 output = 0;

	//Reads actual position from motor encoder.
	CmtGetLock (MicronixLock);
	ViErrChk(viFlush(MicronixSession, VI_READ_BUF_DISCARD));
	ViErrChk(viPrintf(MicronixSession, "%d%s\n\r", Axis ,"POS?"));
	ViErrChk(viFlush(MicronixSession, VI_WRITE_BUF));
	ViErrChk(viScanf(MicronixSession, "%*[^,;\r\n\t]%*[,;\r\n\t]"));             
	ViErrChk(viScanf(MicronixSession, "%lf%*[,;\r\n\t]", &output));
	CmtReleaseLock(MicronixLock);

	return (double)output;
	
	Error:
    if (ViErr < 0) {
		MotorErrors();
		return -10000000;
    }
	
}

ViStatus MicronixWaitUntilReady(int Axis)
{
	ViStatus ViErr = 0;
	char StrCom[128]="";
    ViReal64 output2 = 0;
	int numRead;
	ViChar strOutput2[MAX_ARRAY_SIZE];
	int status_byte=0;
			  //(int)output2 & 128
	while((status_byte!=8) && (status_byte!=136))			 // 8 stage is ready, 136 stage is ready but there was an error 
	{
		//Reads the status byte.
		Delay (0.008);
		ViErrChk(viFlush(MicronixSession, VI_READ_BUF_DISCARD));
		ViErrChk(viPrintf(MicronixSession, "%d%s\n\r", Axis,"STA?"));
		ViErrChk(viFlush(MicronixSession, VI_WRITE_BUF));
		viRead (MicronixSession, strOutput2, 1, &numRead);
		//ViErrChk(viScanf(MicronixSession, "%*1c"));             
	//	ViErrChk(viScanf(MicronixSession, "%3c", strOutput2));
		viRead (MicronixSession, strOutput2, 3, &numRead);  
		sscanf(strOutput2, "%lf", &output2);
		status_byte = output2;
	}
	return status_byte;
	Error:
	MicronixStop(0);
	return ViErr;
}
static ViStatus SetTermCharAttributes(ViSession session, ViByte terminationCharacter)
{
	ViStatus ViErr = VI_SUCCESS;
	ViUInt16 intfType = 0;

	// Set the termination character attributes if this is a serial resource
	ViErrChk(viGetAttribute(session, VI_ATTR_INTF_TYPE, &intfType));
	if (intfType == VI_INTF_ASRL) {
		if (terminationCharacter > 0) {
			ViErrChk(viSetAttribute(session, VI_ATTR_ASRL_END_IN, VI_ASRL_END_TERMCHAR));
		}
		else {
			ViErrChk(viSetAttribute(session, VI_ATTR_ASRL_END_IN, VI_ASRL_END_NONE));
		}
	}
	ViErrChk(viSetAttribute(session, VI_ATTR_TERMCHAR_EN, (terminationCharacter > 0)));
	ViErrChk(viSetAttribute(session, VI_ATTR_TERMCHAR, terminationCharacter));

Error:
    if (ViErr < 0) {
		CloseMicronixInstrSession(); 
    }
	return ViErr;
	
}

void MotorErrors (void)
{
	ViStatus ViErr = 0;

	
	MicronixQuarry("0ERR?",MicronixErrorString);
	MicronixClearErrors();
	CmtReleaseLock (MicronixLock);
	
//	SetCtrlVal(PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_ERR_MSG,errString);

//	CloseMicronixInstrSession();
	MessagePopup ("Micronix Error", "An error has occured. Communication to the motors was stopped.");
}




