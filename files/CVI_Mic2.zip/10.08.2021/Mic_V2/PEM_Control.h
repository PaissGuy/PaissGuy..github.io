#ifndef PEM_INCLUDE  
#define PEM_INCLUDE       


#pragma DisableUnreferencedIdentifiers  
#define PEM_COM_PORT    6
#define PEM_DEVICE_NAME    "COM6"
#define BUAD_RATE 9600
#define DATA_BITS 8
#define STOP_BIT 1
#define PARITY 0
#define Q_SIZE 512
#define MAX_COMMAND_LENGTH	50
						  	



#include <rs232.h> 

#ifdef __cplusplus
	extern "C" {
#endif

		
/*******************************************************************************/
//Prototypes //
void OPEN_PEM_port_RS232(void);
void Close_PEM_port_RS232(void);
int PEM__Inhibit(int inh) ;
int PEM_change_R(int retardance);
int PEM_change_Wavelength(int wavelength, int retardance);
int PEM_change_Echo(int echo);




#endif  //end Header Guard
