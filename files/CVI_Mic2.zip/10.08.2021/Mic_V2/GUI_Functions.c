#include <utility.h>
#include "MIC_V2.h"
#include <ansi_c.h>
#include <userint.h>
#include "GUI_Functions.h"
#include "Colormaps.h"


#define CB_DISABLE 1
#define CB_ENABLE 0 
#define MAIN_PANEL_GRAPH 1
#define SECONDARY_GRAPH 2


extern double Parula_Colormap_Matrics[256][3];
ColorMapEntry  colors[256],colors2[256]; //ColorMapEntry is a class defined by CVI and it Represents the value and color pairs on an intensity graph.
//int PlotHandle;

void SetGUI_InitialState (int panel, int graphPanel, int SpectralPanel)	   // This function is called from the main func  of MIC_VS.c and its  goal is to draw and define the scale bars and the color maps. 
{
	// panel - Specifier for a particular panel that is currently in memory. You can obtain this handle from functions such as LoadPanel and NewPanel.
	// graphPanel - 
	// SpectralPanel - 
	double max,min; //Function scope variables which are used  in the 3 following function calls.
	
	GetCtrlVal(panel,MAIN_PANEL_MAX_SCALE,&max); 
	GetCtrlVal(panel,MAIN_PANEL_MIN_SCALE,&min);
	/*
	 GetCtrlVal returns the value of the currently selected list item.
	To obtain the index of the selected list item, use GetCtrlIndex.
	panel-	int	Specifier for a particular panel that is currently in memory. You can obtain this handle from functions such as LoadPanel and NewPanel.
	controlID	int	The defined constant, located in the .uir header file, that you assigned to the control in the User Interface Editor, or the ID returned by functions such as NewCtrl and DuplicateCtrl.
	value	void *	The current value of the control. The data type of value must match the data type of the control.
	*/
	LoadColormap(PARULA,  max,  min); // This function main goal is to assign each different color a matching double value
	PlotScaleBar(panel, MAIN_PANEL_XY_SCAN_PLOT_SCALE_1); // This function goal is to draw the the scale bar to the right of the color map.
	PlotScaleBar(graphPanel, PLOT_PANEL_XY_SCAN_PLOT_SCALE_2); 	// This function goal is to draw the scale bar under the color map.


}

ShowHidePanel(actionPanel,actionControl, reactionPanel )
{				
	int state;		
	GetCtrlVal (actionPanel, actionControl, &state);
	if(state) DisplayPanel (reactionPanel);  
	else HidePanel(reactionPanel);
	return 0;
}

int HidePanelAndChangeToggleState(int panelToHide, int panelWithControl, int ControlToChange, int State)
{
	SetCtrlVal (panelWithControl, ControlToChange, State);
	HidePanel(panelToHide);
	
	
	return 0;
}


int GetMotorsAxisIDs(int panelHandle, int *X_ID, int *Y_ID,int *Z_ID)
{
	GetCtrlVal(panelHandle, MICRONIX_S_X_AXIS_ID, X_ID);
	GetCtrlVal(panelHandle, MICRONIX_S_Y_AXIS_ID, Y_ID);
	GetCtrlVal(panelHandle, MICRONIX_S_Z_AXIS_ID, Z_ID);
	
	return 0;
}  

int GetAOTF_IDs(int panelHandle, int *vis_id, int *nir_id,int *nir2_id)
{
	GetCtrlVal(panelHandle, AOTF_SETTI_VIS_AOTF_ID, vis_id);
	GetCtrlVal(panelHandle, AOTF_SETTI_NIR_AOTF_ID, nir_id);
	GetCtrlVal(panelHandle, AOTF_SETTI_NIR2_AOTF_ID, nir2_id);
	
	return 0;
} 

void f_folder_browse (char *directory_name)	//This function responsible for creating the path name of the folder you want to save your results.
{
	DirSelectPopup ("c:\\Users\\Eitam\\Dropbox\\Ori Cheshnovski Lab\\Lab NoteBook\\Experiments\\Extinction", "Select Directory", 0, 1, directory_name);
}
int SaveGraphToImage(char *path, int panel, int control)
{
	int     bitmap = 0;
	strcat(path,".png");
	GetCtrlDisplayBitmap (panel, control, 0, &bitmap);
    SaveBitmapToPNGFile (bitmap, path);
    DiscardBitmap (bitmap);
	return 0;
}
int GetAOTF_ID_FromControlHandle(int control)
{
///Number convention	1nXX0  n:	1  - VIS ,2 - NIR ,3-NIR2
	int tmp= (control/1000)%10;
	return tmp;
}
int GetAOTF_Channel_FromControlHandle(int control)
{
//1XnX0  n: 	channel  number 0 to 7
	int tmp= (control/100)%10;
	return tmp;
}
int GetAOTF_Command_FromControlHandle(int control)
{
//1XXn0  n:	1 change state, 2 set wavelength, 3 set RF power
	int tmp= (control/10)%10;
	return tmp;
}						
//						 
int GetAOTF_StateControl_FromControlHandle(int aotf_type, int channel)
{
	int tmp=10000+1000*aotf_type+100*channel+10;
	return tmp;	
	
}
int GetAOTFUsefullControlNumber(int control)
{
	switch(control)
	{
		
		case MAIN_PANEL_VIS_STATE_CHAN0: 	return 11010;
		case MAIN_PANEL_VIS_AOTF_Wave_CH0: 	return 11020;
		case MAIN_PANEL_VIS_AOTF_POWER_CH0: return 11030;
		case MAIN_PANEL_VIS_STATE_CHAN1: 	return 11110;
		case MAIN_PANEL_VIS_AOTF_Wave_CH1: 	return 11120;
		case MAIN_PANEL_VIS_AOTF_POWER_CH1: return 11130;
		
		case MAIN_PANEL_NIR_STATE_CHAN0: 	return 12010;
		case MAIN_PANEL_NIR_AOTF_Wave_CH0: 	return 12020;
		case MAIN_PANEL_NIR_AOTF_POWER_CH0: return 12030;
		case MAIN_PANEL_NIR_STATE_CHAN1: 	return 12110;
		case MAIN_PANEL_NIR_AOTF_Wave_CH1: 	return 12120;
		case MAIN_PANEL_NIR_AOTF_POWER_CH1: return 12130;
		
		case MAIN_PANEL_NIR2_STATE_CHAN0: 	return 13010;
		case MAIN_PANEL_NIR2_AOTF_Wave_CH0: return 13020;
		case MAIN_PANEL_NIR2_AOTF_POWER_CH0:return 13030;
		
		case AOTF_SETTI_VIS_STATE_CHAN2: 	return 11210;
		case AOTF_SETTI_VIS_AOTF_Wave_CH2: 	return 11220;
		case AOTF_SETTI_VIS_AOTF_POWER_CH2: return 11230;
		case AOTF_SETTI_VIS_STATE_CHAN3: 	return 11310;
		case AOTF_SETTI_VIS_AOTF_Wave_CH3: 	return 11320;
		case AOTF_SETTI_VIS_AOTF_POWER_CH3: return 11330;
		case AOTF_SETTI_VIS_STATE_CHAN4: 	return 11410;
		case AOTF_SETTI_VIS_AOTF_Wave_CH4: 	return 11420;
		case AOTF_SETTI_VIS_AOTF_POWER_CH4: return 11430;
		case AOTF_SETTI_VIS_STATE_CHAN5: 	return 11510;
		case AOTF_SETTI_VIS_AOTF_Wave_CH5: 	return 11520;
		case AOTF_SETTI_VIS_AOTF_POWER_CH5: return 11530;
		
				case AOTF_SETTI_VIS_STATE_CHAN6: 	return 11610;
		case AOTF_SETTI_VIS_AOTF_Wave_CH6: 	return 11620;
		case AOTF_SETTI_VIS_AOTF_POWER_CH6: return 11630;
				case AOTF_SETTI_VIS_STATE_CHAN7: 	return 11710;
		case AOTF_SETTI_VIS_AOTF_Wave_CH7: 	return 11720;
		case AOTF_SETTI_VIS_AOTF_POWER_CH7: return 11730;
	
		case AOTF_SETTI_NIR_STATE_CHAN2: 	return 12210;
		case AOTF_SETTI_NIR_AOTF_Wave_CH2: 	return 12220;
		case AOTF_SETTI_NIR_AOTF_POWER_CH2: return 12230;
		case AOTF_SETTI_NIR_STATE_CHAN3: 	return 12310;
		case AOTF_SETTI_NIR_AOTF_Wave_CH3: 	return 12320;
		case AOTF_SETTI_NIR_AOTF_POWER_CH3: return 12330;
		case AOTF_SETTI_NIR_STATE_CHAN4: 	return 12410;
		case AOTF_SETTI_NIR_AOTF_Wave_CH4: 	return 12420;
		case AOTF_SETTI_NIR_AOTF_POWER_CH4: return 12430;
		case AOTF_SETTI_NIR_STATE_CHAN5: 	return 12510;
		case AOTF_SETTI_NIR_AOTF_Wave_CH5: 	return 12520;
		case AOTF_SETTI_NIR_AOTF_POWER_CH5: return 12530;
			
	}
	return -1;
}


int GetAOTFControlFromUsfulNumber (int num)
{
	switch(num)
	{
		
		case 11010: return MAIN_PANEL_VIS_STATE_CHAN0;
		case 11020: return MAIN_PANEL_VIS_AOTF_Wave_CH0;
		case 11030: return MAIN_PANEL_VIS_AOTF_POWER_CH0;
		case 11110: return MAIN_PANEL_VIS_STATE_CHAN1;
		case 11120: return MAIN_PANEL_VIS_AOTF_Wave_CH1;
		case 11130: return MAIN_PANEL_VIS_AOTF_POWER_CH1;
		case 12010: return MAIN_PANEL_NIR_STATE_CHAN0;
		case 12020: return MAIN_PANEL_NIR_AOTF_Wave_CH0;
		case 12030: return MAIN_PANEL_NIR_AOTF_POWER_CH0;
		case 12110: return MAIN_PANEL_NIR_STATE_CHAN1;
		case 12120: return MAIN_PANEL_NIR_AOTF_Wave_CH1;
		case 12130: return MAIN_PANEL_NIR_AOTF_POWER_CH1;
		case 13010: return MAIN_PANEL_NIR2_STATE_CHAN0;
		case 13020: return MAIN_PANEL_NIR2_AOTF_Wave_CH0;
		case 13030: return MAIN_PANEL_NIR2_AOTF_POWER_CH0;
		case 11210: return AOTF_SETTI_VIS_STATE_CHAN2;
		case 11220: return AOTF_SETTI_VIS_AOTF_Wave_CH2;
		case 11230: return AOTF_SETTI_VIS_AOTF_POWER_CH2;
		case 11310: return AOTF_SETTI_VIS_STATE_CHAN3;
		case 11320: return AOTF_SETTI_VIS_AOTF_Wave_CH3;
		case 11330: return AOTF_SETTI_VIS_AOTF_POWER_CH3;
		case 11410: return AOTF_SETTI_VIS_STATE_CHAN4;
		case 11420: return AOTF_SETTI_VIS_AOTF_Wave_CH4;
		case 11430: return AOTF_SETTI_VIS_AOTF_POWER_CH4;
		case 11510: return AOTF_SETTI_VIS_STATE_CHAN5;
		case 11520: return AOTF_SETTI_VIS_AOTF_Wave_CH5;
		case 11530: return AOTF_SETTI_VIS_AOTF_POWER_CH5;
		
		case 11610: return AOTF_SETTI_VIS_STATE_CHAN6;
		case 11620: return AOTF_SETTI_VIS_AOTF_Wave_CH6;
		case 11630: return AOTF_SETTI_VIS_AOTF_POWER_CH6;
		case 11710: return AOTF_SETTI_VIS_STATE_CHAN7;
		case 11720: return AOTF_SETTI_VIS_AOTF_Wave_CH7;
		case 11730: return AOTF_SETTI_VIS_AOTF_POWER_CH7;
		
		
		
		case 12210: return AOTF_SETTI_NIR_STATE_CHAN2;
		case 12220: return AOTF_SETTI_NIR_AOTF_Wave_CH2;
		case 12230: return AOTF_SETTI_NIR_AOTF_POWER_CH2;
		case 12310: return AOTF_SETTI_NIR_STATE_CHAN3;
		case 12320: return AOTF_SETTI_NIR_AOTF_Wave_CH3;
		case 12330: return AOTF_SETTI_NIR_AOTF_POWER_CH3;
		case 12410: return AOTF_SETTI_NIR_STATE_CHAN4;
		case 12420: return AOTF_SETTI_NIR_AOTF_Wave_CH4;
		case 12430: return AOTF_SETTI_NIR_AOTF_POWER_CH4;
		case 12510: return AOTF_SETTI_NIR_STATE_CHAN5;
		case 12520: return AOTF_SETTI_NIR_AOTF_Wave_CH5;
		case 12530: return AOTF_SETTI_NIR_AOTF_POWER_CH5;

	}
	return -1;
}
void GetChannelControlIDs(int panel, int chan,int *StateControl,int  *DevIDControl, int  *RangeControl, int  *GroupControl)  //This function is being called by the GetDaqChannelData function below this function, and it only gives back the values of the control constants for each channel.
{
	switch (chan)
	{
		case 0:
			*StateControl = DAQ_SETTI_AI_CHAN_ACTIVE_0;
			*DevIDControl = DAQ_SETTI_AI_CHAN_0;
			*RangeControl = DAQ_SETTI_AI_CHAN_RANGE_0;
			*GroupControl = DAQ_SETTI_DAQ_GROUP_CH0;
		break;
			
		case 1:
			*StateControl = DAQ_SETTI_AI_CHAN_ACTIVE_1;
			*DevIDControl = DAQ_SETTI_AI_CHAN_1;
			*RangeControl = DAQ_SETTI_AI_CHAN_RANGE_1;
			*GroupControl = DAQ_SETTI_DAQ_GROUP_CH1;
		break;
			
		case 2:
			*StateControl = DAQ_SETTI_AI_CHAN_ACTIVE_2;
			*DevIDControl = DAQ_SETTI_AI_CHAN_2;
			*RangeControl = DAQ_SETTI_AI_CHAN_RANGE_2;
			*GroupControl = DAQ_SETTI_DAQ_GROUP_CH2;
		break;
			
		case 3:
			*StateControl = DAQ_SETTI_AI_CHAN_ACTIVE_3;
			*DevIDControl = DAQ_SETTI_AI_CHAN_3;
			*RangeControl = DAQ_SETTI_AI_CHAN_RANGE_3;
			*GroupControl = DAQ_SETTI_DAQ_GROUP_CH3;
		break;
			
		case 4:			   
			*StateControl = DAQ_SETTI_AI_CHAN_ACTIVE_4;
			*DevIDControl = DAQ_SETTI_AI_CHAN_4;
			*RangeControl = DAQ_SETTI_AI_CHAN_RANGE_4;
			*GroupControl = DAQ_SETTI_DAQ_GROUP_CH4;
		break;
			
		case 5:
			*StateControl = DAQ_SETTI_AI_CHAN_ACTIVE_5;
			*DevIDControl = DAQ_SETTI_AI_CHAN_5;
			*RangeControl = DAQ_SETTI_AI_CHAN_RANGE_5;
			*GroupControl = DAQ_SETTI_DAQ_GROUP_CH5;
		break;
	}
}
DAQtaskData	GetDaqChannelData(int chan, int panel) //This function is being called by the GetTaskGroupData function in MIC_V2.c and it gets the number of a specific channel, and the panel handler of the daq UI.
{

	int StateControl, DevIDControl, RangeControl, GroupControl;
	DAQtaskData data;
	
	
	GetChannelControlIDs(panel, chan, &StateControl, &DevIDControl, &RangeControl, &GroupControl);

	GetCtrlVal(panel, StateControl, &data.Dev_Status);
	GetCtrlVal(panel, DevIDControl, data.DevID);
	GetCtrlVal(panel, RangeControl, &data.maxIn); 
	GetCtrlVal(panel, GroupControl, &data.Group);
	strcpy(data.Dev_Name,"");
	return data;
	
}
int GetNumberOfActiveChannelsInEachGroup(int PanelHandelDAQsettings,int *group1, int *group2,int SeqArr[MAX_DAQ_AI_CHAN])
{
	int ch0,ch1,ch2,ch3,ch4,ch5,tmp;

	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_ACTIVE_0 ,&ch0);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_ACTIVE_1 ,&ch1);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_ACTIVE_2 ,&ch2);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_ACTIVE_3 ,&ch3);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_ACTIVE_4 ,&ch4);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_ACTIVE_5 ,&ch5); 
	
	if(ch0) 
		{
			if(SeqArr!=NULL) SeqArr[0]=1;
			GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_GROUP_CH0 ,&tmp);  
			if(tmp ==1) *group1=*group1+1;
			else *group2=*group2+1;
		}
	if(ch1) 
		{
			if(SeqArr!=NULL) SeqArr[1]=1; 
			GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_GROUP_CH1 ,&tmp);  
			if(tmp ==1) *group1=*group1+1;
			else *group2=*group2+1;
		}
	if(ch2) 
		{
			if(SeqArr!=NULL) SeqArr[2]=1; 
			GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_GROUP_CH2 ,&tmp);  
			if(tmp ==1) *group1=*group1+1;
			else *group2=*group2+1;
		}
	if(ch3) 
		{
			if(SeqArr!=NULL) SeqArr[3]=1; 
			GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_GROUP_CH3 ,&tmp);  
			if(tmp ==1) *group1=*group1+1;
			else *group2=*group2+1;
		}
	if(ch4) 
		{
			if(SeqArr!=NULL) SeqArr[4]=1; 
			GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_GROUP_CH4 ,&tmp);  
			if(tmp ==1) *group1=*group1+1;
			else *group2=*group2+1;
		}	
	if(ch5) 
		{
			if(SeqArr!=NULL) SeqArr[5]=1; 
			GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_GROUP_CH5 ,&tmp);  
			if(tmp ==1) *group1=*group1+1;
			else *group2=*group2+1;
		}
		return *group1+*group2;
}

int GetLocationTypeandNum_FromControl(int control) //This function is being called when pressing 1-5 or bg1-bg5 to move or save location. its only return a value per button clicked.
{
	switch(control)
	{

		
		case MAIN_PANEL_STORED_LOC_1:  return 10; 
		case MAIN_PANEL_STORED_LOC_2:  return 20;
		case MAIN_PANEL_STORED_LOC_3:  return 30;
		case MAIN_PANEL_STORED_LOC_4:  return 40;
		case MAIN_PANEL_STORED_LOC_5:  return 50;
		
		case MAIN_PANEL_STORED_LOC_BG1:  return 11;
		case MAIN_PANEL_STORED_LOC_BG2:  return 21; 
		case MAIN_PANEL_STORED_LOC_BG3:  return 31; 
		case MAIN_PANEL_STORED_LOC_BG4:  return 41; 
		case MAIN_PANEL_STORED_LOC_BG5:  return 51; 
		
		case MAIN_PANEL_STORED_LOC_CLEAR:  return -10;  
	}
	return -1;
}
void PlotLastScanToGraph_2(int MainPanel,int PlotPanel)
{
	int bitmap;
	GetCtrlDisplayBitmap (MainPanel, MAIN_PANEL_XY_SCAN_PLOT_1, 0, &bitmap);
	CanvasDrawBitmap (PlotPanel, PLOT_PANEL_XY_SCAN_PLOT_2, bitmap, VAL_ENTIRE_OBJECT, VAL_ENTIRE_OBJECT);
 
}
void SetGUI_ForXYScan(int MainPanel,int PlotPanel, int PlotChan2) //This function is being called by the start scan callback function called f_start_scan
{
	SetCtrlAttribute (MainPanel, MAIN_PANEL_STOP_SCAN, ATTR_DIMMED,CB_ENABLE);//Make the STOP button enabled and not dimmed. Change the value to 0.CB_ENABLE=0
	SetCtrlAttribute (MainPanel, MAIN_PANEL_START_SPECTRAL_SCAN, ATTR_DIMMED, CB_DISABLE); // Make the start button to dimmed. CB_DISABLE=1.

	CanvasClear (PlotPanel, PLOT_PANEL_XY_SCAN_PLOT_2, VAL_ENTIRE_OBJECT);   // This function clears the canvas in the extra plot panel!
	
	if(PlotChan2==-1) 
	{
		PlotLastScanToGraph_2(MainPanel,PlotPanel);	
	}
	
	CanvasClear (MainPanel, MAIN_PANEL_XY_SCAN_PLOT_1, VAL_ENTIRE_OBJECT);
	ClearStripChart (MainPanel, MAIN_PANEL_LINECHART);	//This function is a cvi function and it is used to clear the stripchart under the canvas. 
}
void SetGUI_ForSpectralScan(int panel, int PlotPanel, int SpecPanel)//This function is being called the scan_spectral and its just deleting previous data, dim buttons and displaying the specpanel
{
	SetCtrlAttribute (panel, MAIN_PANEL_STOP_SCAN, ATTR_DIMMED,CB_ENABLE);
	SetCtrlAttribute (panel, MAIN_PANEL_START_SCAN, ATTR_DIMMED, CB_DISABLE);

	
	CanvasClear (panel, MAIN_PANEL_XY_SCAN_PLOT_1, VAL_ENTIRE_OBJECT);
	CanvasClear (PlotPanel, PLOT_PANEL_XY_SCAN_PLOT_2, VAL_ENTIRE_OBJECT);
	DeleteGraphPlot (SpecPanel, SPEC_PANEL_SPECTRAL_CHART, -1, VAL_IMMEDIATE_DRAW);      
	
	DisplayPanel (SpecPanel);
	
}

void SetGUI_ForDelayScan(int panel, int PlotPanel, int SpecPanel,int StndaPanel)
{
	SetCtrlAttribute (panel, MAIN_PANEL_STOP_SCAN, ATTR_DIMMED,CB_ENABLE);
	SetCtrlAttribute (panel, MAIN_PANEL_START_SCAN, ATTR_DIMMED, CB_DISABLE);

	
	CanvasClear (panel, MAIN_PANEL_XY_SCAN_PLOT_1, VAL_ENTIRE_OBJECT);
	CanvasClear (PlotPanel, PLOT_PANEL_XY_SCAN_PLOT_2, VAL_ENTIRE_OBJECT);
	DeleteGraphPlot (SpecPanel, SPEC_PANEL_SPECTRAL_CHART, -1, VAL_IMMEDIATE_DRAW);
	
	DisplayPanel(StndaPanel);
}

void SetGUI_AfterScan(int panel)
{
	SetCtrlAttribute (panel, MAIN_PANEL_STOP_SCAN, ATTR_DIMMED, CB_DISABLE);
	SetCtrlAttribute (panel, MAIN_PANEL_START_SPECTRAL_SCAN, ATTR_DIMMED,CB_ENABLE); 
	SetCtrlAttribute (panel, MAIN_PANEL_START_SCAN, ATTR_DIMMED,CB_ENABLE); 
	SetCtrlVal(panel, MAIN_PANEL_START_SCAN,0);
	SetCtrlVal(panel, MAIN_PANEL_START_SPECTRAL_SCAN,0);
}

int  GetColorForPoint( double val, int graphNum)
{
	//can be further improved to reduce run-time!!!!
	int i;
	
	for(i=0;i<COLORMAP_SIZE; i++)
		if (graphNum==MAIN_PANEL_GRAPH)
		{
			if (val<colors[i].dataValue.valDouble) break;
		}
		else
		{
			if (val<colors2[i].dataValue.valDouble) break; 	
		}
	if (i==COLORMAP_SIZE) return VAL_WHITE;
	
	if (graphNum==MAIN_PANEL_GRAPH)
		{
			return colors[i].color; 
		}
		else
		{
			return colors2[i].color;	
		}
	
}

void UpdateGraph(int panel, int graph, double **arr,int X_Size, int Y_Size, int ScaleFactor)
{
	 
	int x,y;

	if(arr ==NULL) return;
	CanvasClear (panel, graph, VAL_ENTIRE_OBJECT);
	CanvasStartBatchDraw(panel,graph);

	for(y=0;y<Y_Size;y++)
		for(x=0;x<X_Size;x++)
			PlotScanPoint( panel, graph, arr[y][x],x, y, ScaleFactor); 
	
	 CanvasEndBatchDraw(panel,graph);
	

}
int LoadColormap( int type, double max, double min)		// This function is being called in the SetGUI_InitialState function at line 20, The goal of this function is to assign each color in the colormap a correlated double value. 
{
	/*
	 type - indicates the type of colormap we are using in the gui, Parula or Jet.
	 max - this is the value in the max scale field in the main panel.
	min - This is the value in the min scale field in the main panel.
	*/
	int k;

	 
	switch(type)
	{
		
		case PARULA:
		for (k=0;k<COLORMAP_SIZE;k++)   // We run using k through each and every color in the color map. The number of colors is the color map size.
		{
			colors[k].color = Parula_Colormap[k];	  // Assign in the colors array the right color value in hexa using the default values built by NI.
			colors[k].dataValue.valDouble = (min + k/(COLORMAP_SIZE-1.0) * (max-min));//Give each color a double vcalue. 
		}
		break;
		
		case JET:					  // Do the same as you did to Parula.
		for (k=0;k<COLORMAP_SIZE;k++)
		{
			colors[k].color =  Jet_Colormap[k];
			colors[k].dataValue.valDouble = (min + k/(COLORMAP_SIZE-1.0) * (max-min));
		}	
		break;
	}
	
	return 0;
	
}
int LoadColormap2( int type, double max, double min)
{
	int k;

	 
	switch(type)
	{
		
		case PARULA:
		for (k=0;k<COLORMAP_SIZE;k++)
		{
			colors2[k].color = Parula_Colormap[k];
			colors2[k].dataValue.valDouble = (min + k/(COLORMAP_SIZE-1.0) * (max-min));
		}
		break;
		
		case JET:
		for (k=0;k<COLORMAP_SIZE;k++)
		{
			colors2[k].color =  Jet_Colormap[k];
			colors2[k].dataValue.valDouble = (min + k/(COLORMAP_SIZE-1.0) * (max-min));
		}	
		break;
	}
	
	return 0;
	
}
void PlotScaleBar(int panel, int control)
{
		
	int i,j;
	
	
	CanvasStartBatchDraw (panel, control);
	CanvasClear (panel, control, VAL_ENTIRE_OBJECT);  
	
	for(i=0;i<COLORMAP_SIZE;i++)
		for(j=0;j<SCALE_BAR_WIDTH;j++)  
		{
			if (control==PLOT_PANEL_XY_SCAN_PLOT_SCALE_2)  SetCtrlAttribute (panel, control, ATTR_PEN_COLOR, colors2[i].color); 
			else SetCtrlAttribute (panel, control, ATTR_PEN_COLOR, colors[i].color); 
			CanvasDrawPoint (panel, control, MakePoint(j,COLORMAP_SIZE-1-i));
		}
					
	CanvasEndBatchDraw (panel, control);
	if (control==MAIN_PANEL_XY_SCAN_PLOT_SCALE_1)
	{
		SetCtrlVal(panel,MAIN_PANEL_MIN_SCALE ,colors[0].dataValue.valDouble	);
		SetCtrlVal(panel,MAIN_PANEL_MAX_SCALE ,colors[COLORMAP_SIZE-1].dataValue.valDouble	);
	}
}


void PlotScanPoint(int panel, int control, double val, int Xloc, int Yloc, int graphScaleFactor)
{
	int RGBcolor;
	int graphNum;
	
	if(control==MAIN_PANEL_XY_SCAN_PLOT_1) graphNum=MAIN_PANEL_GRAPH;
	else graphNum=SECONDARY_GRAPH;
	RGBcolor= GetColorForPoint(val,graphNum);  
	SetCtrlAttribute (panel, control, ATTR_PEN_FILL_COLOR, RGBcolor);  
	SetCtrlAttribute (panel, control, ATTR_PEN_COLOR, RGBcolor);
	  
	
	if(!graphScaleFactor) CanvasDrawPoint  (panel, control, MakePoint(Xloc,Yloc));     
	else  CanvasDrawRect (panel, control, MakeRect (graphScaleFactor*Yloc, graphScaleFactor*Xloc, graphScaleFactor, graphScaleFactor), VAL_DRAW_INTERIOR);

}

void AddPointToSpectralChart(int PanelHandelSpectrarlChart,int wavelength, double XY_ScanMax,double XY_ScanMin)
{
	
	PlotPoint (PanelHandelSpectrarlChart, SPEC_PANEL_SPECTRAL_CHART, wavelength, XY_ScanMax, VAL_SOLID_CIRCLE, VAL_RED);
	PlotPoint (PanelHandelSpectrarlChart, SPEC_PANEL_SPECTRAL_CHART, wavelength, XY_ScanMin, VAL_SOLID_CIRCLE, VAL_BLUE); 
	PlotPoint (PanelHandelSpectrarlChart, SPEC_PANEL_SPECTRAL_CHART, wavelength, XY_ScanMax-XY_ScanMin, VAL_SOLID_CIRCLE, VAL_GREEN);
	
}

void UpdatePlotListControl(int activeSeq[MAX_DAQ_AI_CHAN], int panelMain, int panel2)
{
	int i,indCount=0;
	char str[20]="Ch",tmpStr[10]="";
	

	ClearListCtrl(panelMain,MAIN_PANEL_CHANNEL_PLOT_SELECT_1);
	for	(i=0;i<MAX_DAQ_AI_CHAN;i++)
		if(activeSeq[i])
		{
		sprintf(tmpStr,"%d",i);
		strcat(str,tmpStr);
		InsertListItem (panelMain, MAIN_PANEL_CHANNEL_PLOT_SELECT_1, indCount, str, i);
		indCount++;
		strcpy(str,"Ch");
		}
	
	ClearListCtrl(panel2,PLOT_PANEL_CHANNEL_PLOT_SELECT_2);
	InsertListItem (panel2, PLOT_PANEL_CHANNEL_PLOT_SELECT_2, 0, "Last", -1); 
	indCount=1;
	for	(i=0;i<MAX_DAQ_AI_CHAN;i++)
		if(activeSeq[i])
		{
		sprintf(tmpStr,"%d",i);
		strcat(str,tmpStr);
		InsertListItem (panel2, PLOT_PANEL_CHANNEL_PLOT_SELECT_2, indCount, str, i);
		indCount++;
		strcpy(str,"Ch");
		}
}
/*void PlotScanPoint(int panel, int control, double val, int Xloc, int Yloc, int graphScaleFactor, int BatchEnable)
{
	int gX,gY,RGBcolor;
		
	RGBcolor= GetColorForPoint(val);  
	SetCtrlAttribute (panel, control, ATTR_PEN_COLOR, RGBcolor);
	if (BatchEnable)	CanvasStartBatchDraw (panel, control);   
	
	if(!graphScaleFactor)  
	
	CanvasDrawRect (SCAN_TabHandle, SCAN_PAN_CANVAS,
						MakeRect ((CANVAS_SIZE/Yres)*YAxis, (CANVAS_SIZE/Xres)*XAxis, CANVAS_SIZE/Yres, CANVAS_SIZE/Xres), VAL_DRAW_INTERIOR);
	
	
	for(gY=0;gY<graphScaleFactor;gY++)
		for(gX=0;gX<graphScaleFactor;gX++)
				CanvasDrawPoint  (panel, control, MakePoint(Xloc*gX+gX,Yloc*gY+gY));
	
	if (BatchEnable)	CanvasEndBatchDraw(panel,control);	
	
}	  */



