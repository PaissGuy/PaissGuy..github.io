#include <utility.h>
#include <userint.h>
#include "MIC_V2.h"
#include "LockIn_Control.h"
#include "ansi_c.h"

//Globals

int LIA_address;
int LIA_device;



void setup_LIA (int ParametersPanel)
{
	GetCtrlVal (ParametersPanel, MOD_SETTIN_LIA_GPIB_ADDRESS, &LIA_address);
	LIA_device = ibdev (0, LIA_address, NO_SAD, T1s, 1, 0);
	
}


int LIA_SendGPIB_cmd(char *cmd)
{

	ibwrt (LIA_device, cmd, strlen(cmd)); 
	if (ibsta & 0x8000) 
	{	
		return -1;
	}
	
	return 0;
}

int ReadGPIB(char *readbuff)
{
	ibrd (LIA_device, readbuff, 50);
	if (ibsta & 0x8000)
	{	
		return -1;
	}
	
	return 0;
	
}

int LIA_OverloadCheck(void)
{
	char readbuff[51];
	int Overload_Status;
	char cmd[50]="ST";

	LIA_SendGPIB_cmd(cmd);		
	ibrd (LIA_device, readbuff, 50); 
	sscanf(readbuff,"%d",&Overload_Status);
	
	if(Overload_Status== EGNG_OVERLOAD )
	{
		return 1;
	}
	return 0;
}
//Instrument Commands//
int LIA_ChangeChanSource(int chan, int outputType)
{
	char cmd[50]="";
	
	if(chan==1)
	{
		sprintf(cmd,"CH 1 %d",outputType);	
	}
	else if(chan==2)
	{
		sprintf(cmd,"CH 2 %d",outputType);	
		
	}
	else return -1;	

	LIA_SendGPIB_cmd(cmd);
	return 0;
	
}

void LIA_AutoPhase(void)
{
	char cmd[50]="AQN";
	LIA_SendGPIB_cmd(cmd);	
}
void LIA_AutoOffset(void)
{
	char cmd[50]="AXO";
	LIA_SendGPIB_cmd(cmd);
}
void LIA_AutoSensitivity(void)
{
	char cmd[50]="AS";
	LIA_SendGPIB_cmd(cmd);
}
void LIA_Set_Sensitivity(int NewSetting)
{
	char cmd[50]="";
	sprintf(cmd,"SEN%d",NewSetting);
	LIA_SendGPIB_cmd(cmd);	
	
}
int LIA_Read_V_Sensitivity_Setting(void)
{
	char cmd[50]="SEN";
	char readbuff[51];
	int senSetting;

	LIA_SendGPIB_cmd(cmd);		
	ibrd (LIA_device, readbuff, 50);
	sscanf(readbuff,"%d",&senSetting);
	
	return senSetting;
}

	
double EGNG_Read_Sensitivity_Double(void)
{
	char cmd[50]="SEN.";
	char readbuff[51]="";
	int err=0;
	int count=0;
	double Sen;
	
	
	LIA_SendGPIB_cmd(cmd);		
	err=ibrd (LIA_device, readbuff, 50);
	sscanf(readbuff,"%lf",&Sen);
	while(strlen(readbuff)<1 && count<20)
	{
		
		Delay(0.1);
		LIA_SendGPIB_cmd(cmd);		
		err=ibrd (LIA_device, readbuff, 50);
		sscanf(readbuff,"%lf",&Sen);
		count++;
	}
		
	
	return Sen;
}
void EGNG_Change_SensitivityBy(int SettingNumChange)
{
	int curSetting;
	
	curSetting=LIA_Read_V_Sensitivity_Setting();
	while(abs(SettingNumChange)>=1)
	{
		if((curSetting+SettingNumChange>=1) && (curSetting+SettingNumChange<=27))
		{
			LIA_Set_Sensitivity(curSetting+SettingNumChange);
			break;
		}
		else
		{
			if(SettingNumChange>0) SettingNumChange--;	
			else				   SettingNumChange++;
			
		}
	}
}

int LIA_Get_Mag(void)
{
	char cmd[50]="MAG";
	char readbuff[51];
	int amp;
	LIA_SendGPIB_cmd(cmd);
	if (ibsta & 0x8000)
	{	
		return -1;
	}
	ibrd(LIA_device,readbuff,50);
	sscanf(readbuff,"%d",&amp);
	return amp;
}

int LIA_Get_Phase(void)
{
	char cmd[50]="PHA";
	char readbuff[51];
	int pha;
	LIA_SendGPIB_cmd(cmd);
	if (ibsta & 0x8000)
	{	
		return -1;
	}
	ibrd(LIA_device,readbuff,50);
	sscanf(readbuff,"%d",&pha);
	return pha;
}
