
#include  "Standa_DLine_Control.h"




void PopError(void)
{
	char Err[101];
	USMC_GetLastErr(Err,100);
	//Beep;
	MessagePopup ("Motor Error",Err);

}

void PrintDevices(USMC_Devices DVS)
{
	for(DWORD i = 0; i < DVS.NOD; i++)
	{
		printf("Device - %d,\tSerial Number - %.16s,\tVersion - %.4s\n",i+1,DVS.Serial[i],DVS.Version[i]);
	}
}

void PrintDState(USMC_State State)
{
	printf( "The state is:\n" );
	printf( "- Current Position in microsteps - %d\n", State.CurPos );
	printf( "- Temperature - %.2f\xf8\x43\n", State.Temp );
	printf( "- Step Divisor - %d\n", State.SDivisor);
	printf( "- Loft State - %s\n", State.Loft?"Indefinite":"Fixed" );
	printf( "- Power - %s\n", State.Power?(State.FullPower?"Full":"Half"):"Off" );
	if(State.RUN)
		printf( "- Step Motor is Running in %s Direction %s\n",
				State.CW_CCW?"CCW":"CW", ((State.SDivisor==1) && State.FullSpeed)?"at Full Speed":"" );
	else
		printf( "- Step Motor is Not Running\n" );
	printf( "- Device %s\n", State.AReset?"is After Reset":"Position Already Set" );
	printf( "- Input Synchronization Logical Pin State - %s\n", State.SyncIN?"TRUE":"FALSE" );
	printf( "- Output Synchronization Logical Pin State - %s\n", State.SyncOUT?"TRUE":"FALSE" );
	printf( "- Rotary Transducer Logical Pin State - %s\n", State.RotTr?"TRUE":"FALSE" );
	printf( "- Rotary Transducer Error Flag - %s\n", State.RotTrErr?"Error":"Clear" );
	printf( "- Emergency Disable Button - %s\n", State.EmReset?"Pushed":"Unpushed" );
	printf( "- Trailer 1 Press State - %s\n", State.Trailer1?"Pushed":"Unpushed" );
	printf( "- Trailer 2 Press State - %s\n", State.Trailer2?"Pushed":"Unpushed" );
	if( State.Voltage == 0.0f )
		printf( "- Input Voltage - Low\n", State.Voltage);
	else
		printf( "- Input Voltage - %.1fV\n", State.Voltage);

}

void PrintDMode(USMC_Mode *Mode)
{
	printf( "Mode parameters:\n" );
	printf( "Buttons - ");
	if(Mode->PMode)
	{
		printf( "Disabled\n" );
	}else{
		printf( "Enabled\nButton 1 TRUE state - %s\n", Mode->Butt1T?"+3/+5 V":"0 V(GND)" );
		printf( "Button 2 TRUE state - %s\n", Mode->Butt2T?"+3/+5 V":"0 V(GND)" );
	}
	printf( "Current reduction regime - %s\n", Mode->PReg?"Used":"Not Used" );

	if(Mode->ResetD)
		printf( "Power - %s\n", Mode->EMReset?"Emerjency Off":"Off" );
	else
		printf( "Power - On\n" );
	if(Mode->Tr1En || Mode->Tr2En)
		printf( "Trailers are - %s\n", Mode->TrSwap?"Swapped":"Direct" );

	printf( "Trailer 1 - ");
	if(Mode->Tr1En)
		printf( "Enabled\nTrailer 1 TRUE state - %s\n", Mode->Tr1T?"+3/+5 V":"0 V(GND)" );
	else
		printf( "Disabled\n");
	printf( "Trailer 2 - ");
	if(Mode->Tr2En)
		printf( "Enabled\nTrailer 2 TRUE state - %s\n", Mode->Tr2T?"+3/+5 V":"0 V(GND)" );
	else
		printf( "Disabled\n");

	if(Mode->EncoderEn)
	{
		printf( "Encoder - Enabled\n");
		printf( "Encoder Position Counter is %s\n", Mode->EncoderInv?"Inverted":"Direct");
		printf( "Rotary Transducer and Input Syncronisation are\n"
				" Disabled Because of Encoder\n");
	}else{
		printf( "Encoder - Disabled\n");
		printf( "Rotary Transducer - ");
		if(Mode->RotTeEn)
		{
			printf( "Enabled\nRotary Transducer TRUE state - %s\n", Mode->RotTrT?"+3/+5 V":"0 V(GND)" );
			printf( "Rotary Transducer Operation - %s\n", Mode->RotTrOp?"Stop on error":"Check and ignore error" );
			printf( "Reset Rotary Transducer Check Positions - %s\n", Mode->ResetRT?"Initiated":"No, why?");
		}else{
			printf("Disabled\n");
		}
		printf("Synchronization input mode:\n");
		if(Mode->SyncINOp)
			printf("Step motor will move one time to the destination position\n");
		else
			printf("Step motor will move multiple times by [destination position]\n");

	}
	printf( "Output Syncronization - ");
	if(Mode->SyncOUTEn)
	{
		printf( "Enabled\nReset Output Synchronization Counter - %s\n", Mode->SyncOUTR?"Initiated":"No, why?" );
		printf( "Number of steps after which synchronization output sygnal occures - %u\n", Mode->SyncCount );
	}else{
		printf("Disabled\n");
	}
	printf("Synchronization Output is ");
	if(Mode->SyncInvert)
		printf("INVERTED\n");
	else
		printf("NORMAL\n");
}


void Set_My_Mode()
{
	Mode.PMode	 = 	FALSE; 	   	//Turn off buttons (TRUE - buttons disabled)
	Mode.PReg	=	TRUE;	  	//Current reduction regime (TRUE - regime is on)
	Mode.ResetD = FALSE;  	  	//Turn power off and make a whole step (TRUE - apply)
	Mode.EMReset = FALSE;		//Quick power off (see 5.4.6 at page 52) 
	Mode.Tr1T	 =	TRUE;     	//Limit switch 1 TRUE state (TRUE : +3/+5�; FALSE : 0�)   
	Mode.Tr2T	 =	TRUE;     	//Limit switch 2 TRUE state (TRUE : +3/+5�; FALSE : 0�)
	Mode.RotTrT  =	TRUE;     	//Rotary Transducer TRUE state (TRUE : +3/+5�; FALSE : 0�) 
	Mode.TrSwap  = FALSE;   	//If TRUE, Limit switches are treated to be swapped 
	Mode.Tr1En	  = FALSE;     	//If TRUE Limit switch 1 Operation Enabled 
	Mode.Tr2En	  = FALSE;     	//If TRUE Limit switch 2 Operation Enabled 
	Mode.RotTeEn = FALSE;    	//If TRUE Rotary Transducer Operation Enabled
	Mode.RotTrOp = FALSE;    	//Rotary Transducer Operation Select (stop on error if TRUE) 
	Mode.Butt1T  = TRUE	; 	//Button 1 TRUE state (TRUE : +3/+5�; FALSE : 0�)
	Mode.Butt2T  = TRUE	; 	//Button 2 TRUE state (TRUE : +3/+5�; FALSE : 0�)
	Mode.ResetRT  = TRUE; 		//Reset Rotary Transducer Check Positions (need one full revolution before it can detect error)
	Mode.SyncOUTEn = FALSE ;  	//If TRUE output synchronization enabled 
	Mode.SyncOUTR = FALSE ;  	//If TRUE output synchronization counter will be reset
	Mode.SyncINOp = FALSE;		//TRUE - Step motor will move one time to the DestPos
								//FALSE - Step motor will move multiple times by DestPos microsteps as distance
    Mode.SyncCount  =  FALSE;
	Mode.SyncInvert = FALSE;	//Set this bit to TRUE to invert output synchronization polarity
	Mode.EncoderEn  = FALSE;	//Enable Encoder on pins {SYNCIN,ROTTR} - disables Synchronization input and Rotary Transducer
	Mode.EncoderInv  =FALSE;	//Invert Encoder Counter Direction
	Mode.ResBEnc =    FALSE;	//Reset <EncoderPos> and <ECurPos> to 0
	Mode.ResEnc	 = FALSE;	//Reset <ECurPos> to <EncoderPos>   	//If TRUE, Limit switches are treated to be swapped ;
	USMC_SetMode(Dev,&Mode);
	
}

bool F1_Get_Device_State(void)
{
	if( USMC_GetState(Dev, &State) )
		return TRUE;

	PrintDState(State);
	printf("\n");
	return false;
}

int CloseController()
{
	int retCode = USMC_Close();
	return retCode; 
}

void Set_Position(int position)
{
	USMC_SetCurrentPosition(Dev,position);	
}

void Motor_Go()
{
	Start_Motor_Param.SDivisor=1;
	if(USMC_Start(Dev,dest_point,&speed,&Start_Motor_Param)) PopError();	
}

void My_Init_Motor()
{
	if(USMC_Init(&DVS))
	{
		PopError();
	}
	//if(USMC_SetCurrentPosition(Dev,0)) PopError();
	if(USMC_GetState(Dev,&State)) PopError();
	if(USMC_GetParameters(Dev,&MotorParams)) PopError();
	if(USMC_GetStartParameters(Dev,&Start_Motor_Param)) PopError();
	if(USMC_GetMode(Dev,&Mode)) PopError();
	Set_My_Mode();
	State.CurPos=0;
	Start_Motor_Param.SlStart=TRUE;
	Start_Motor_Param.LoftEn=FALSE;
}

void Set_Start_Param()
{
	Start_Motor_Param.SlStart=1;
	Start_Motor_Param.SDivisor=1;
}

void SetMovingData()
{
	speed=1000;	
}

void Move()
{
	SetMovingData();
	Set_Start_Param();
	Motor_Go();	
}

void Step(int steps)
{
	int previous;
	int PosProximityThreshold = 0;
	dest_point=(State.CurPos + (steps)*8);
	if(dest_point>=0) dest_point=0;
	if(dest_point<=-316000) dest_point=-316000;
	if(USMC_GetState(Dev,&State)) PopError();
	Move();
	ProcessDrawEvents();
	previous= abs(State.CurPos - dest_point); 
	while(abs(State.CurPos - dest_point)>PosProximityThreshold)
	{
		if(State.Trailer1 || State.Trailer2)
		{
			USMC_Stop(Dev);
			break;
		}
		if(USMC_GetState(Dev,&State)) PopError();
		Delay (Standa_Delay_Time/10);
//		if(previous<=abs(State.CurPos - dest_point))
//		{
//			USMC_Stop(Dev);
//			break;	
//		}
//		else
//		{
//			previous= abs(State.CurPos - dest_point);	
//		}
	}
	ProcessDrawEvents();
}

void Step2(int *steps)
{
	int previous;
	int PosProximityThreshold = 0;
	dest_point=(State.CurPos + (*steps)*8);
	if(dest_point>=0) dest_point=0;
	if(dest_point<=-316000) dest_point=-316000;
	if(USMC_GetState(Dev,&State)) PopError();
	Move();
//	ProcessDrawEvents();
	previous= abs(State.CurPos - dest_point); 
	while(abs(State.CurPos - dest_point)>PosProximityThreshold)
	{
		if(State.Trailer1 || State.Trailer2)
		{
			USMC_Stop(Dev);
			break;
		}
		if(USMC_GetState(Dev,&State)) PopError();
		Delay (Standa_Delay_Time/10);
//		if(previous<=abs(State.CurPos - dest_point))
//		{
//			USMC_Stop(Dev);
//			break;	
//		}
//		else
//		{
//			previous= abs(State.CurPos - dest_point);	
//		}
	}
//	ProcessDrawEvents();
}   



void MyCloseStanda()
{
	int PosProximityThreshold = 0;
	dest_point=0;
	if(USMC_GetState(Dev,&State)) PopError();
	Move();
	ProcessDrawEvents();
	while(abs(State.CurPos - dest_point)>PosProximityThreshold)
	{
		if(State.Trailer1 || State.Trailer2)
		{
			USMC_Stop(Dev);
			break;
		}
		if(USMC_GetState(Dev,&State)) PopError();
		Delay (Standa_Delay_Time/10);
	}
	ProcessDrawEvents();
	CloseController(); 
}
