#include <ansi_c.h>
#include <utility.h>
#include <userint.h>
#include "MIC_V2.h"
#include "PI_Control.h"


#pragma DisableUnreferencedIdentifiers

// Module Global Varibles//
ViSession PI_Session;
int PI_Status =-1;
int PI_ThreadID;   
int PI_Lock; 
char PI_ErrorString[2048];

static ViChar formatString[255];
static ViStatus SetTermCharAttributes(ViSession PI_Session, ViByte terminationCharacter);


int Initialize_PI_Stages(void)
{
	PI_SendCMD("SVO 1 1");  	//Sets SerVO-control mode on or off for axis 1 which must be turned on before operation 
	Delay(0.05);
	PI_SendCMD("FRF 1");		//Referance move
	return 1;
Error:
	Close_PI_InstrSession(); 
	MessagePopup ("PI ERROR ON STARTUP", "Errror on startup commands");
	return -1;
}


int PI_threaded(PI_Data *Params, int cmdType)
{
	if(PI_Status<0) return -1;
	switch (cmdType)
	{
		case PI_MOVE_ABS:								  //(DEFAULT_THREAD_POOL_HANDLE, PI_MoveAbsolute, Params, &PI_ThreadID);
			PI_Status = CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, PI_MoveAbsolute, Params, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL,  RUN_IN_SCHEDULED_THREAD, &PI_ThreadID);
		break;
														   
		case PI_MOVE_REL:								 //(DEFAULT_THREAD_POOL_HANDLE, PI_MoveRelative, Params, &PI_ThreadID);
			PI_Status = CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, PI_MoveRelative, Params, THREAD_PRIORITY_HIGHEST, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, RUN_IN_SCHEDULED_THREAD,&PI_ThreadID);
		break;

		case PI_STOP:
			 PI_Status = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, PI_Stop, Params, &PI_ThreadID);
		break;
		
		case PI_SET_SPEED:
			 PI_Status = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, PI_Speed, Params, &PI_ThreadID);
		break;
		
		case PI_SET_ACCELERATION:
			 PI_Status = CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, PI_Acceleration, Params, &PI_ThreadID);
		break;
		
	}
	CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, PI_ThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	return PI_Status;
}

	
//  Begin Module functions  //
int Open_PI_Port(ViSession resManeger )
{
	ViStatus ViErr = 0;
    ViString output = 0;
	
	// Open a session to the instrument
	ViErrChk(viOpen(resManeger, PI_COM_PORT, 4, VI_NULL, &PI_Session));
	// Set the timeout
	ViErrChk(viSetAttribute (PI_Session, VI_ATTR_TMO_VALUE, 3000));
	//Set the termination character attributes
	ViErrChk(SetTermCharAttributes(PI_Session, 13));
	
	CmtNewLock (NULL, 0, &PI_Lock);  //create thread lock
	PI_Status = 1;
	
	return PI_Status;
Error:
	PI_Status =-1;
return PI_Status;	

}


ViStatus PI_SendCMD(char* cmdString)
{
	ViStatus ViErr = 0;	
	
	ViErrChk(viFlush(PI_Session, VI_READ_BUF_DISCARD));
	
	ViErrChk(viPrintf(PI_Session, "%s\n", cmdString));	 
	ViErrChk(viFlush(PI_Session, VI_WRITE_BUF)); 	
	return 1;
	
Error:
	PI_Errors();
	return ViErr;
}
ViStatus PI_Quarry(char* quaryString, char* respondString)
{
	ViStatus ViErr = 0;	
	

	ViErrChk(viFlush(PI_Session, VI_READ_BUF_DISCARD));
	//ViErrChk(viPrintf(PI_Session, "%s\n", quaryString));	 
	ViErrChk(viWrite (PI_Session, quaryString,strlen(quaryString) , VI_NULL));
	ViErrChk(viFlush(PI_Session, VI_WRITE_BUF)); 	
//	ViErrChk(viScanf(PI_Session, respondString)); 
	ViErrChk(viRead(PI_Session, respondString, 1024, VI_NULL));
	
	Delay(0.05);		//comunication delay    
	
	return 1;
	
Error: 
	return ViErr;
} 
 


int PI_MoveRelative(PI_Data *Params)  //Moves Axis#  relative to current position in RelMove [mm]
{

	char cmd[MAX_PI_CMD_LEN];
	
	CmtGetLock (PI_Lock);  
	sprintf(cmd,"%s %d %1.6lf","MVR", Params->Axis, Params->data1);
	PI_SendCMD(cmd);
	PI_WaitUntilReady(Params->Axis);
	CmtReleaseLock (PI_Lock);
	return 1;
}
int PI_MoveAbsolute(PI_Data *Params)  //Moves Axis# to position [mm]
{

	char cmd[MAX_PI_CMD_LEN];
	CmtGetLock (PI_Lock);  
	
	sprintf(cmd,"%s %d %1.6lf","MOV", Params->Axis,Params->data1);
	PI_SendCMD(cmd);
	PI_WaitUntilReady(Params->Axis);
	CmtReleaseLock (PI_Lock);
	return 1;

}
int PI_Speed(PI_Data *Params)  //Set Axis#  Speed      
{
	char cmd[MAX_PI_CMD_LEN];
	CmtGetLock (PI_Lock);
	sprintf(cmd,"%s %d %1.3lf","VEL", Params->Axis,Params->data1);
	PI_SendCMD(cmd);
	CmtReleaseLock (PI_Lock);
	return 1;
}
int PI_Acceleration(PI_Data *Params)  //Set Axis#  Acceleration
{


	char cmd[MAX_PI_CMD_LEN];
	CmtGetLock (PI_Lock); 
	sprintf(cmd,"%s %d %1.3lf","ACC", Params->Axis,Params->data1);
	PI_SendCMD(cmd);
	CmtReleaseLock (PI_Lock);
	return 1;
}
int PI_ShutDown(void)
{
	PI_SendCMD("0MOT0");
	return 1;
}

int PI_SetZero()  //Set Current Axis posotion to be the new Zero location
{
    char cmd[MAX_PI_CMD_LEN];
	CmtGetLock (PI_Lock);  
	sprintf(cmd, "%s", "POS 1 0.0");
	PI_SendCMD(cmd);
	CmtReleaseLock (PI_Lock);	
	return 1;
}

int PI_Stop(PI_Data *Params)  //Stop Motion of Axis #
{
	char cmd[MAX_PI_CMD_LEN]=""; 

	sprintf(cmd, "\24");   //24 is the stop comand
	PI_SendCMD(cmd);	
	return 1;

}

void PI_ClearErrors(void)
{

	CmtGetLock (PI_Lock);  
	PI_SendCMD("EER?");
	CmtReleaseLock (PI_Lock);	
}
ViStatus Close_PI_InstrSession(void)  //This function is being called by the EndProgram_Sequance function in mic_V2.c file line 554. Its goal is to end the session with the PI.
{
	ViStatus ViErr = VI_SUCCESS;

	if (PI_Session) {
		// Close the session
		ViErrChk(viClose(PI_Session));
	}

	CmtDiscardLock (PI_Lock);
	
Error:
	return ViErr;
}
double PI_POS_Query(int Axis)  //Ask Axis#  for possition
{
	ViStatus ViErr = 0;
    ViString output = 0;
	char tmpStr[20]="";
	double result=0;;
	
	ViNullChk(output = (ViString)calloc(MAX_ARRAY_SIZE, 1));  
	ViErrChk(viFlush(PI_Session, VI_READ_BUF_DISCARD));
	//Reads actual position from motor encoder.
	ViErrChk(viPrintf(PI_Session, "%s\n", "POS?")); 
	ViErrChk(viFlush(PI_Session, VI_WRITE_BUF));    
	viScanf(PI_Session, "%11s", output);
	
	// Parse a delimited string   
	strncpy(tmpStr, output + 2, strlen(output) - 2);
	sscanf(tmpStr, "%lf", &result);
	
	return result;
	
	Error:
    if (ViErr < 0) {
		PI_Errors();
		return -10000000;
    }
	
}

ViStatus PI_WaitUntilReady(int Axis)
{
	ViStatus ViErr = 0;
	char StrCom[128]="";
    ViReal64 output2 = 0;
	int numRead;
	ViChar strOutput2[MAX_ARRAY_SIZE];
	int status_byte=-10;
			  
	while(status_byte!=0.0) // 0 indicats motion is done
	{
		//Reads the status byte.
		Delay (0.008);
		ViErrChk(viFlush(PI_Session, VI_READ_BUF_DISCARD));
		ViErrChk(viPrintf(PI_Session, "\5\n"));
		ViErrChk(viFlush(PI_Session, VI_WRITE_BUF));
		viRead (PI_Session, strOutput2, 1, &numRead);
		//ViErrChk(viScanf(PI_Session, "%*1c"));             
	//	ViErrChk(viScanf(PI_Session, "%3c", strOutput2));
		sscanf(strOutput2, "%lf", &output2);
		status_byte = output2;
	}
	return status_byte;
	Error:
	PI_Stop(0);
	return ViErr;
}
static ViStatus SetTermCharAttributes(ViSession session, ViByte terminationCharacter)
{
	ViStatus ViErr = VI_SUCCESS;
	ViUInt16 intfType = 0;

	// Set the termination character attributes if this is a serial resource
	ViErrChk(viGetAttribute(session, VI_ATTR_INTF_TYPE, &intfType));
	if (intfType == VI_INTF_ASRL) {
		if (terminationCharacter > 0) {
			ViErrChk(viSetAttribute(session, VI_ATTR_ASRL_END_IN, VI_ASRL_END_TERMCHAR));
		}
		else {
			ViErrChk(viSetAttribute(session, VI_ATTR_ASRL_END_IN, VI_ASRL_END_NONE));
		}
	}
	ViErrChk(viSetAttribute(session, VI_ATTR_TERMCHAR_EN, (terminationCharacter > 0)));
	ViErrChk(viSetAttribute(session, VI_ATTR_TERMCHAR, terminationCharacter));

Error:
    if (ViErr < 0) {
		Close_PI_InstrSession(); 
    }
	return ViErr;
	
}

void PI_Errors (void)
{
	ViStatus ViErr = 0;

	
	PI_Quarry("ERR?",PI_ErrorString);
	CmtReleaseLock (PI_Lock);
	
//	Close_PI_InstrSession();
	MessagePopup ("PI_ Error", "An error has occured. Communication to the motors was stopped.");
}




