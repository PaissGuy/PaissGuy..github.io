#ifndef FIANIUM_INCLUDE  
#define FIANIUM_INCLUDE       


#pragma DisableUnreferencedIdentifiers  
#define FIANIUM_COM_PORT    "COM5"
#define FUNDAMENTAL_OUTPUT	"pa2"
#define SC_OUTPUT	"Q"
#define BUAD_RATE 19200
#define DATA_BITS 8
#define STOP_BIT 1
#define PARITY 0
#define MAX_COMMAND_LENGTH	50
#define MAX_LASER_POWER 4
#define MAX_LASER_OUT 1990
#define MAX_FuLASER_POWER 100
#define MAX_FuLASER_OUT 2650

#include <visa.h>
#include <ansi_c.h>    

#ifdef __cplusplus
	extern "C" {
#endif

		
/*******************************************************************************/
//Prototypes //
int LaserPowerUpdate(char *Source, double NewOutput);
static ViStatus SetTermCharAttributes(ViSession resourceName, ViByte terminationCharacter);		
int OpenFianiumPort(ViSession resManeger);		
ViStatus CloseFianiumInstrSession(void) ;		
		
#endif  //end Header Guard
