#include "MG17MO~1.h"
#include "toolbox.h"
#include <utility.h>
#include <cvirte.h>		
#include <userint.h>
#include <visa.h> 
#include "MIC_V2.h"
#include "GUI_Functions.h"
#include "Micronix_Control.h" 
#include "Fianium_Control.h"
#include "PEM_Control.h"
#include "AOTF_Control.h"
#include "DAQ_Control.h"
#include "MIC_V2main.h"


#define FALSE 0
#define TRUE 1
#define VAL_MOVE 1
#define VAL_SAVE 0
#define STATE_ON 1
#define SCAN_LOC 0
#define BACKGROUND_LOC 1
#define STATE_OFF 0
#define USB_COM_DELAY 0.02
#define MAX_SCAN_NUMBER_LEN 4  
#define MAX_FILE_NAME_LENGTH  512
#define MAX_LINE_READ_LEN 256
#define PNG_TYPE ".png"
#define DAQ_MAX_SAMPLE_RATE 250000
#define NUMBER_OF_STORED_LOCATIONS 6
#define SCAN_DIR_A-to-D 0
#define SCAN_DIR_B-to-C 1
#define SCAN_DIR_D-to-A 2
#define SCAN_DIR_C-to-B 3
#define ARR_TYPE_DOUBLE 0
#define ARR_TYPE_SCANPOINT 1
#define SEARCH_TYPE_ORIGIN 0
#define SEARCH_TYPE_MIN 1
#define SEARCH_TYPE_MAX 2
#define AF_ON_MAX 0
#define AF_ON_MIN 0
#define SCAN_BREAK_STOP -1
#define SCAN_BREAK_PAUSE 1
#define		RUN_SCAN	 0
#define SCAN_DIR_FASTx_TOPtoBOTOM_FROM_LEFT 0
#define SCAN_DIR_FASTy_RIGHTtoLEFT_FROM_UP 1
#define SCAN_DIR_FASTx_BOTOMtoTOP_FROM_RIGHT 2
#define SCAN_DIR_FASTy_LEFTtoRIGHT_FROM_BOTOM 3
#define EQUATION_LOG 0
#define EQUATION_FRACTION 1  
#define EQUATION_NONE 2  

/*---------------------------------------------------------------------------*/
/* Macros :                                                                  */
/*---------------------------------------------------------------------------*/
#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else  



// ----------------------    Panel Handles   -------------------------------//
static int PanelHandleMain; 
static int PanelHandelSpectrarlChart;
static int PanelHandelGraph2;
static int PanelHandelStageSettings;
static int PanelHandelMicronixSettings;
static int PanelHandelAOTFSettings;
static int PanelHandelDAQsettings;
static int PanelHandeladvScanSettings;
static int PanelHandelmodulationSettings;
//--------------------------------------------------------------------------//


//----------------  RUN MODES  ---------------------------------------------//
int DEBUG_MODE=0;  		//0 for regular run, 1 debug mode on.
int Micronix_Online=1; 	//0 for ofline, 1 online 
int Fianium_Online=1;	//0 for ofline, 1 online.
int Rotation_Online=1;  //0 for ofline, 1 online
int MOVE_ENABLE = 1;	//0 for moving, 0 No movement in scan
int PEM_ONLINE =0;		//0 for ofline, 1 online 
int AOTF_Online =1;		//0 for ofline, 1 online
int USNIG_NIRVANA_PHOTODIODE=1;
//--------------------------------------------------------------------------//


//---------------		Struactures 		--------------------------------//
typedef struct
 {
	double data[MAX_DAQ_AI_CHAN];
	double X_Loc;
	double Y_Loc;
	double Z_Shift;
 } ScanPoint;

typedef struct
 {
	double X;
	double Y;
	double Z;
	int Point_Status;
}XYZ_Point;

typedef struct
 {
	double X;
	double Y;
	int Point_Status;
}XY_Point;

typedef struct
{
	XYZ_Point Scan_Loc;
	XYZ_Point BG_Loc;
} ScanLocation;

typedef struct
{
	int Wavelength;
	int AOTF_num;
	int RF_Power; //Not used now but it's here if there is a reason to change RF gain between wavelengths in Spectral Scan
}SpectralPoint; 

typedef struct
{
	double X_Step;
	double X_Size;
	double Y_Step;
	double Y_Size;
	double StepTime;
	int MeasureCycles;
	double StabTime;
	int ScanDir;
	double x0;
	double y0;
	int wavelength;
	int AI_Number;
	int AI_g1;
	int AI_g2;
	char FolderName[MAX_FILE_NAME_LENGTH/2];
	char FileName[MAX_FILE_NAME_LENGTH/2];
	int  pSearchChan;
	
	//Scan Corrections
	XY_Point DriftCorrLoc;   // Point_Status:  0 = NO, 1=YES 
	int SampleTiltCorr;   // 0 = NO, 1=YES       
	XYZ_Point TiltCorrLoc[4];	//[0-2]X,Y,Z;  
	
}ScanData;

//--------------------------------------------------------------------------//


//-----------------   Function Prototypes   ----------------------------------//  
void StartMicronixStages(void); 
int StartPEM_Sequance(void) ;
char** CreateOutPutFiles_XY(void) ;
FILE* MakeFile(char *fileName);
void AssignDaqDataTo_XYarrayChns(DAQtaskData *daqData,double *pointData,int group,int arrY_Pos,int arrX_Pos, int CollectionTimes);
void WriteXY_FileHeader(FILE* pFile);
int XY_Scan (void* );
void GetFileAndFolderNames(int panel); 
int GetScaleFactor(void);
double f_AutoFocus(void);
int GetAOTFdevID_From_aotf_type(int aotf_type) ;
int MoveToLocation(int loc,int type);
void f_AutoSetPowerBalance(void);  
void SaveLocation(int loc,int type);
int SetPowerBalance(double tolerance);
double GetDisplayValFromData(double valData, double valRef);
double GetBalanceValFromData(double Target,double ref);
//--------------------------------------------------------------------------// 


//-----------------   Controller Status   ----------------------------------//
int PEM_STATUS=0;     
int Micronix_STATUS=0;
int Fianium_STATUS=0;
int AOTF_STATUS=0;
//--------------------------------------------------------------------------//


//----------------		Micronix Globals		----------------------------//
extern int MicronixThreadID;
extern char MicronixErrorString[255];

int X_AXIS, Y_AXIS, Z_AXIS;
MicronixData *MicronixParam=NULL;
int PlotChan=0,RefChan=1, PlotChan2=2;
//--------------------------------------------------------------------------// 


//----------------		AOTF Globals		----------------------------//

int VIS_ID, NIR_ID, NIR2_ID;
int ActiveAOTF=-1;
//--------------------------------------------------------------------------// 
 

//----------------		Device Session Manegers		----------------------------//
ViSession DevicesSessionManeger=VI_NULL;
static int rotorStageHandle;
//--------------------------------------------------------------------------// 

//----------------		Program Globals 		----------------------------//
ScanLocation StoredLoc[6];
int ScanThreadID=-1;
int ScanBreak;  //-1 Stop Scan, 0 - Normal Run, 1 - Puase Scan
ScanPoint **XYarray, **oldXYarray;
SpectralPoint *WavelengthArray =NULL;
//double Plot1arr[GRAPH_SIZE][GRAPH_SIZE]={0}, Plot2arr[GRAPH_SIZE][GRAPH_SIZE]={0};
int X_Scan_size=0, Y_Scan_size=0;
int ScanRunning=0; 
ScanData sData={.AI_Number=0,.AI_g1=0,.AI_g2=0 };
XYZ_Point Min_Location={0}, Max_Location={0};
double XY_ScanMax,XY_ScanMin, BG_val;
//--------------------------------------------------------------------------// 




int LoadPannels(int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((PanelHandelSpectrarlChart = LoadPanel (0, "MIC_V2.uir", SPEC_PANEL)) < 0)
		return -1;
	if ((PanelHandelGraph2 = LoadPanel (0, "MIC_V2.uir", PLOT_PANEL)) < 0)
		return -1;
	if ((PanelHandleMain = LoadPanel (0, "MIC_V2.uir", MAIN_PANEL)) < 0)
		return -1;
	if ((PanelHandelMicronixSettings = LoadPanel (0, "MIC_V2.uir", MICRONIX_S)) < 0)
		return -1;
	if ((PanelHandelAOTFSettings = LoadPanel (0, "MIC_V2.uir", AOTF_SETTI)) < 0)
		return -1;
	if ((PanelHandelDAQsettings = LoadPanel (0, "MIC_V2.uir", DAQ_SETTI)) < 0)
		return -1;
	if ((PanelHandeladvScanSettings = LoadPanel (0, "MIC_V2.uir", ADV_SCAN_S)) < 0)
		return -1;
	if ((PanelHandelmodulationSettings = LoadPanel (0, "MIC_V2.uir", MOD_SETTIN)) < 0)
		return -1;	
	if ((PanelHandelStageSettings = LoadPanel (0, "MIC_V2.uir", STAGE_SETT)) < 0)
		return -1;
	return 0;
}

int DiscardPanels(void)
{
	DiscardPanel (PanelHandelSpectrarlChart);
	DiscardPanel (PanelHandelGraph2);
	DiscardPanel (PanelHandelStageSettings);
	DiscardPanel (PanelHandleMain);
	DiscardPanel (PanelHandelMicronixSettings);
	DiscardPanel (PanelHandelAOTFSettings);
	DiscardPanel (PanelHandelDAQsettings);
	DiscardPanel (PanelHandeladvScanSettings);
	DiscardPanel (PanelHandelmodulationSettings);	
	
	return 0;
}

int StartMicronix_Sequance(void)
{
	if( (MicronixParam=malloc(sizeof(MicronixData)))==NULL ) goto Error; 
	StartMicronixStages();
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_LED,1);
	
	return 0;
Error: 
	return -1;
}
int StartFianium_Sequance(void)
{
	OpenFianiumPort(DevicesSessionManeger );
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_FIANIUM_LED,1);
	return 0;
}
int StartPEM_Sequance(void)
{
	OPEN_PEM_port_RS232();	
	Delay(0.20);
	PEM_change_Echo(1);
	Delay(0.20);
	PEM__Inhibit(0); //Make sure normal operation is on	
	return 0;
}
int StartAOTF_Sequance(void)
{
	hinstLib = LoadLibrary("AotfLibrary.dll");
	AOTFInitLibrary();
	AOTF_STATUS= 1;

	GetAOTF_IDs( PanelHandelAOTFSettings , &VIS_ID, &NIR_ID, &NIR2_ID); 
	SetAOTF_IDs(VIS_ID,NIR_ID,NIR2_ID);
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_LED,1);
	return 0;
	
}
int ContorllersStartUP_Sequance(void)
{
//Initialize Devices
	int tmp;
	
	if (Micronix_Online) StartMicronix_Sequance();

	if (Fianium_Online)  StartFianium_Sequance();
	
	if (AOTF_Online)	 StartAOTF_Sequance();
	
	if (PEM_ONLINE) 	 StartPEM_Sequance();
	
	if(Rotation_Online) 
	{
		GetObjHandleFromActiveXCtrl (PanelHandelStageSettings, STAGE_SETT_MG17MOTOR, &rotorStageHandle);
		MG17MotorLib__DMG17MotorStartCtrl (rotorStageHandle, NULL, &tmp);
		SetCtrlVal(PanelHandleMain,MAIN_PANEL_TRANSLATION_LED,1); 
	}
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_DAQ_LED,1); 
		
return 0;	
}

void EndProgram_Sequance(void)
{
	long tmp; 
	if (MicronixParam!=NULL) free (MicronixParam);
	if (AOTF_Online) AOTFCloseLibrary();
	if (PEM_ONLINE) Close_PEM_port_RS232();
	if (Rotation_Online) MG17MotorLib__DMG17MotorStopCtrl (rotorStageHandle, NULL, &tmp);
	if (Fianium_Online) 
	{
		LaserPowerUpdate(FUNDAMENTAL_OUTPUT, 0.0);
		LaserPowerUpdate(SC_OUTPUT, 0.0);	
	}
	

	
}
void InitailizeGlobalVars(void)
{	  
	int k;
	for (k=0;k<NUMBER_OF_STORED_LOCATIONS;k++)
	{
		StoredLoc[k].BG_Loc.Point_Status=0;
		StoredLoc[k].Scan_Loc.Point_Status=0;
	}
	
}
int main (int argc, char *argv[])
{
	ViStatus ViErr = 0;
	
	
	LoadPannels( argc,  argv);
	
	SetGUI_InitialState (PanelHandleMain,PanelHandelGraph2, PanelHandelSpectrarlChart);
	
	//Create Device Session Maneger
	ViErrChk(viOpenDefaultRM(&DevicesSessionManeger));
	
	ContorllersStartUP_Sequance();
	
	InitailizeGlobalVars();
	
	
	DisplayPanel (PanelHandelDAQsettings); 
	DisplayPanel (PanelHandleMain);
	
//	DisplayPanel (PanelHandelSpectrarlChart);
	
	RunUserInterface ();

	DiscardPanels();
	
	
	EndProgram_Sequance();
	 
	
	return 0;
	
Error:
	MessagePopup("Error", "Can't Open Resource maneger Session");
return -1;
}


int CVICALLBACK QuitCallback (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			QuitUserInterface (PanelHandleMain);
			break;
	}
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			SCAN				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////


int GetXYScanData( int panel )
{
	int g1=0,g2=0;

	
	GetCtrlVal(panel, MAIN_PANEL_X_SIZE,&sData.X_Size);
	GetCtrlVal(panel, MAIN_PANEL_Y_SIZE,&sData.Y_Size);
	GetCtrlVal(panel, MAIN_PANEL_STEP_SIZE_X,&sData.X_Step);
	GetCtrlVal(panel, MAIN_PANEL_STEP_SIZE_Y,&sData.Y_Step); 	
	GetCtrlVal(panel, MAIN_PANEL_STEP_TIME,&sData.StepTime);
	GetCtrlVal(panel, MAIN_PANEL_STEP_DELAY,&sData.StabTime);
	GetCtrlVal(panel, MAIN_PANEL_SCAN_DIRECTION,&sData.ScanDir);
	GetCtrlVal(panel,MAIN_PANEL_WAVELENGTH_INDICATOR,&sData.wavelength);	
	sData.AI_Number = GetNumberOfActiveChannelsInEachGroup(PanelHandelDAQsettings, &g1, &g2,NULL);
	sData.AI_g1=g1;
	sData.AI_g2=g2;
	
	GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_PARTICLE_SEARCH_CHAN,&sData.pSearchChan);
	
	GetFileAndFolderNames( PanelHandleMain);
	
	if(Micronix_Online)
	{
		sData.x0=MicronixPOS_Query(X_AXIS);
		Delay(USB_COM_DELAY);
		sData.y0=MicronixPOS_Query(Y_AXIS);
		Delay(USB_COM_DELAY);
	}
	return 0;
	
}


int CVICALLBACK f_start_scan (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp,num=0;
			GetCtrlVal(panel,control,&tmp);
			
			if(tmp && !ScanRunning)
			{
				ScanRunning=1;
				
				SetGUI_ForXYScan(PanelHandleMain,PanelHandelGraph2);
				GetXYScanData( PanelHandleMain);
			
		
				CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, XY_Scan, NULL, &ScanThreadID);
			
				CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
				SetGUI_AfterScan(PanelHandleMain);
				
				ScanRunning=0;
				ScanBreak=0;
				
				GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,num+1);
				
			}
			else if (tmp && ScanRunning) ScanBreak = 1;
			else if (!tmp && ScanRunning) ScanBreak=0;
			break;
	}
	
	return 0;
}

int ClearAlocatedArray_ScanPoint(ScanPoint **arr)
{
	int i;
	if (arr!=NULL)
		for(i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
		{
			free(arr[i]);
		}
		free(arr);
	
	return 0;
}
void InitializeArray_Double(double arr[][GRAPH_SIZE])
{
	int i,j;
	for(i=0;i<GRAPH_SIZE;i++)
		for(j=0;j<GRAPH_SIZE;j++)
			arr[i][j]=0;

}
void MovePreviusResultToArray_ScanPoint (ScanPoint **dataArr,ScanPoint **containerArr)
{
	int x,y,yNum,xNum;
	
	yNum = sizeof(ScanPoint)/sizeof(dataArr[0]);
	xNum=  sizeof(dataArr[0])/sizeof(dataArr[0][0]);
	
	containerArr = (ScanPoint **)malloc((yNum)*sizeof(ScanPoint*));
	
	for(y=0;y<yNum;y++) 
		containerArr[y] = (ScanPoint *)malloc((xNum)*sizeof(ScanPoint));

	for(y=0;y<yNum;y++)   	
		for(x=0;x<xNum;x++)   
			containerArr[y][x]=dataArr[y][x];
		
}			
void MovePreviusResultToArray_DOUBLE (double dataArr[][GRAPH_SIZE],double containerArr[][GRAPH_SIZE])
{
	int x,y,yNum,xNum;
	
	yNum = sizeof(ScanPoint)/sizeof(dataArr[0]);
	xNum=  sizeof(dataArr[0])/sizeof(dataArr[0][0]);
	
	for(y=0;y<yNum;y++)   	
		for(x=0;x<xNum;x++)   
			containerArr[y][x]=dataArr[y][x];
		
}			
int CreateNewResultArray_XY(int Y_Points, int X_Points)
{
	
	int i,j,k;
	
	ClearAlocatedArray_ScanPoint(oldXYarray);
	MovePreviusResultToArray_ScanPoint(XYarray,oldXYarray); 
	ClearAlocatedArray_ScanPoint(XYarray);

	
	/////////////////Create New Result Array and initialize it   //////////////////
	XYarray = (ScanPoint **)malloc((Y_Points)*sizeof(ScanPoint*));
	for(i=0;i<Y_Points;i++)  
	{
		XYarray[i] = (ScanPoint *)malloc((X_Points)*sizeof(ScanPoint));
	}
	
	for(i=0;i<Y_Points;i++)   	
		for(j=0;j<X_Points;j++)   
		{
			for(k=0;k<MAX_DAQ_AI_CHAN;k++) 
			{
				XYarray[i][j].data[k]=0.0;
				XYarray[i][j].Z_Shift= 0.0;
			}
		}
	return 0;	
}

int  GetTaskGroupData (DAQtaskData *data)
{
	int k;
	
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)
	{
		data[k] = GetDaqChannelData(k, PanelHandelDAQsettings);	
		strcat(data[k].Dev_Name,"AI_Ch");
		sprintf(data[k].Dev_Name, "%d",k);
	}
return 0;	
}


void  Create_ScanXY_DAQtask(TaskHandle *task1,TaskHandle *task2, int *nPoints_G1, int *nPoints_G2 ,DAQtaskData *data)
{
	int freq,samps ;
	double time1=0,aux;

	GetTaskGroupData(data);
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP1,&freq);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AI_AVEREGING_G1,&samps);
	*nPoints_G1 =samps;
	CreateDAQtask(task1, data, freq, samps,1);
	if(sData.AI_g1) time1=1.0*samps/freq;
	

	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP2,&freq);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AI_AVEREGING_G2,&samps);
	*nPoints_G2 =samps;
	CreateDAQtask(task2, data, freq, samps,2);

	aux=(time1)*1000;
	sData.MeasureCycles=sData.StepTime/aux; 
	if (!sData.MeasureCycles ) sData.MeasureCycles=1;
	
}
void GetScanPointLocations(int Y_Points, int X_Points,double Y_Step,double X_Step, double x0, double y0 )
{
	int k,l;

	for(k=0;k<Y_Points;k++)
	  for(l=0;l<X_Points;l++)  
	  {
		XYarray[k][l].X_Loc = x0+((l*X_Step)-((X_Points/2)*X_Step))/1000; 	  
		XYarray[k][l].Y_Loc = y0+((k*Y_Step)-((Y_Points/2)*Y_Step))/1000; 
		XYarray[k][l].Z_Shift = 0;    
	  }
	
}

void GetFastSlowAxesFromScanDirection(int *fastMax,int *slowMax,MicronixData *fastData, MicronixData *slowData,int  X_Points,int  Y_Points, ScanData sData)
{
	switch(sData.ScanDir)
	{
		case 0:
			*fastMax = X_Points;
			*slowMax = Y_Points;
			fastData->Axis = X_AXIS;
			slowData->Axis = Y_AXIS;
			
		break;
		
		case 1:
			*fastMax = Y_Points;
			*slowMax = X_Points;
			fastData->Axis = Y_AXIS;
			slowData->Axis = X_AXIS;
		
		break;
		
		case 2:
			*fastMax = X_Points;
			*slowMax = Y_Points;
			fastData->Axis = X_AXIS;
			slowData->Axis = Y_AXIS;
		break;
		
		case 3:
			*fastMax = Y_Points;
			*slowMax = X_Points;
			fastData->Axis = Y_AXIS;
			slowData->Axis = X_AXIS;
		break;
	}	
	
}

void GetScanPointsNumber(int *X_Points, int *Y_Points, double X_Size ,double X_Step,double Y_Size ,double Y_Step)
{
	*X_Points= RoundRealToNearestInteger(  X_Size/X_Step );
	*Y_Points= RoundRealToNearestInteger(  Y_Size/Y_Step );
	if(!*X_Points/2) *X_Points++;
	if(!*Y_Points/2) *Y_Points++;	
	X_Scan_size=*X_Points;
	Y_Scan_size=*Y_Points;
	
	
}
void StopScanSequance_XY(void )
{
	if(Micronix_Online)
	{
		MicronixParam->Axis=X_AXIS;
		MicronixParam->data1=sData.x0;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
		MicronixParam->Axis=Y_AXIS;
		MicronixParam->data1=sData.y0;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	}
	
}

int GetScaleFactor(void)
{
	int graphScaleFactor;
	
	if(Y_Scan_size*X_Scan_size==0) return 0;
	if(Y_Scan_size>X_Scan_size) graphScaleFactor = GRAPH_SIZE/Y_Scan_size;
	else				  graphScaleFactor = GRAPH_SIZE/X_Scan_size;	
	
	return graphScaleFactor;
	
}
void GetArrayIndexFromScanIndexandDirection(int *Xind,int *Yind,int SlowInd,int FastInd)
{
	switch (sData.ScanDir)
	{
		case SCAN_DIR_FASTx_TOPtoBOTOM_FROM_LEFT:
			*Xind=FastInd;
			*Yind=SlowInd;
			break;
  
		case SCAN_DIR_FASTy_RIGHTtoLEFT_FROM_UP:
			*Xind=X_Scan_size-SlowInd-1;
			*Yind=FastInd;
			break;
		case SCAN_DIR_FASTx_BOTOMtoTOP_FROM_RIGHT:
			*Xind=X_Scan_size-FastInd-1;
			*Yind=Y_Scan_size-SlowInd-1;
			break; 
 		case SCAN_DIR_FASTy_LEFTtoRIGHT_FROM_BOTOM:
			*Xind=SlowInd;
			*Yind=Y_Scan_size-FastInd-1;
			break; 		
			
	}
	
}
int XY_Scan (void *dat )
{
	FILE *resFiles[MAX_DAQ_AI_CHAN+1];
	char **resFileNames=NULL;
	int X_Points, Y_Points;
	int graphScaleFactor,gY=0,gX=0;
	double PlotPointVal=0.0;
	int i,j,k, l, fastMax, slowMax, Xind, Yind;
	double pointData[MAX_DAQ_AI_CHAN]={0.0};
	XYZ_Point point;
	TaskHandle DAQtask_G1=0,DAQtask_G2=0;
	int nPoints_G1, nPoints_G2,daqAux;
	DAQtaskData *daqData;
	MicronixData *fastData=NULL,*slowData=NULL;
	int32 error=0;
	int32 DAQmxError = DAQmxSuccess;
	double minVal=1000.0,maxVal=-1000.0;
	int aquisitionLoop;
	
	daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData)); 
	fastData=(MicronixData*)malloc(sizeof(MicronixData));
	slowData=(MicronixData*)malloc(sizeof(MicronixData));

	
	GetScanPointsNumber(&X_Points, &Y_Points, sData.X_Size , sData.X_Step, sData.Y_Size ,sData.Y_Step);
	
	resFileNames=CreateOutPutFiles_XY();
	
	CreateNewResultArray_XY(Y_Points, X_Points);
	 
	Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
	
	GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,sData.x0, sData.y0 );
	 
	graphScaleFactor = GetScaleFactor();
	

	//Raster Scan//
	GetFastSlowAxesFromScanDirection(&fastMax, &slowMax, fastData, slowData, X_Points, Y_Points, sData);
	
	for(k=0;k<slowMax;k++)
	{
		for(l=0;l<fastMax;l++)
		{											   
			GetArrayIndexFromScanIndexandDirection(&Xind,&Yind,k,l);

			
			if(sData.ScanDir==1 || sData.ScanDir==3)
			{
				slowData->data1 = XYarray[Yind][Xind].X_Loc;
				fastData->data1 = XYarray[Yind][Xind].Y_Loc; 
			}
			else
			{
				slowData->data1 = XYarray[Yind][Xind].Y_Loc;
				fastData->data1 = XYarray[Yind][Xind].X_Loc; 				 
			}
		
			if(!l) 
			{
				Micronixthreaded(slowData,MOTOR_MOVE_ABS);
			}
			
			Micronixthreaded(fastData,MOTOR_MOVE_ABS);
			
			if(sData.StabTime) Delay(sData.StabTime/1000);
			if(sData.AI_g1)
			{
				for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles; aquisitionLoop++)   
				{
					DAQmxErrChk (DAQmxStartTask(DAQtask_G1));
					GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData);
					AssignDaqDataTo_XYarrayChns(daqData, pointData,1,Yind,Xind,sData.MeasureCycles);
					DAQmxStopTask(DAQtask_G1); 
				}
				
			}
			if(sData.AI_g2)
			{
				DAQmxErrChk (DAQmxStartTask(DAQtask_G2));
				GetDataFromDAQ(DAQtask_G2,sData.AI_g2 , nPoints_G2, pointData);
				AssignDaqDataTo_XYarrayChns(daqData, pointData,2,Yind,Xind,1);
				DAQmxStopTask(DAQtask_G2);
			}	
		
			PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan],XYarray[Yind][Xind].data[RefChan]);
			
			if(GetDisplayValFromData(XYarray[Yind][Xind].data[sData.pSearchChan],XYarray[Yind][Xind].data[RefChan])>maxVal) 
			{
				Max_Location.X= XYarray[Yind][Xind].X_Loc;
				Max_Location.Y= XYarray[Yind][Xind].Y_Loc; 
				Max_Location.Z= XYarray[Yind][Xind].Z_Shift; 
				maxVal=XY_ScanMax = GetDisplayValFromData(XYarray[Yind][Xind].data[sData.pSearchChan],XYarray[Yind][Xind].data[RefChan]);
			}
			if(GetDisplayValFromData(XYarray[Yind][Xind].data[sData.pSearchChan],XYarray[Yind][Xind].data[RefChan])<minVal) 
			{
				Min_Location.X= XYarray[Yind][Xind].X_Loc;
				Min_Location.Y= XYarray[Yind][Xind].Y_Loc; 
				Min_Location.Z= XYarray[Yind][Xind].Z_Shift; 
				minVal=XY_ScanMin  = GetDisplayValFromData(XYarray[Yind][Xind].data[sData.pSearchChan],XYarray[Yind][Xind].data[RefChan]);
			}

			//if(DEBUG_MODE)  PointVal=10.0*Yind*Xind/Y_Points/X_Points;
				
			
			PlotScanPoint(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, PlotPointVal, Xind, Yind, graphScaleFactor); 
	
			if  (PlotChan2>=0)
			{
				PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan2],XYarray[Yind][Xind].data[RefChan]); 
				PlotScanPoint(PanelHandelGraph2, PLOT_PANEL_XY_SCAN_PLOT_2, PlotPointVal, Xind, Yind, graphScaleFactor); 
			}
			
			while (ScanBreak ==SCAN_BREAK_PAUSE){} 
			if(ScanBreak==SCAN_BREAK_STOP) 
			{
				k=slowMax;
				l=fastMax;
			}
		}//fast loop
		
		
		//move slow		
		
	} //slow loop
	
	for(i=0;i<sData.AI_Number;i++) 
	{
			resFiles[i]=fopen(resFileNames[i], "a");
			WriteXY_FileHeader(resFiles[i]);
		
			for(k=0; k<Y_Points;k++)
			{	
				for(l=0; l<X_Points;l++)	
				{
					fprintf(resFiles[i],"\t %lf", XYarray[k][l].data[i]); 	
				}
				fprintf(resFiles[i],"\n");
			}
			fclose(resFiles[i]);
	}
	resFiles[i]=fopen(resFileNames[i], "a");
	WriteXY_FileHeader(resFiles[i]);
	
	for(k=0; k<Y_Points;k++)
	{	
		for(l=0; l<X_Points;l++)	
		{
			fprintf(resFiles[i],"\t %lf", GetDisplayValFromData(XYarray[k][l].data[PlotChan],XYarray[k][l].data[RefChan])); 	
		}
		fprintf(resFiles[i],"\n");
	}
	
	free(daqData);
	free(fastData);
	free(slowData);
	DAQmxClearTask(DAQtask_G1);
	DAQmxClearTask(DAQtask_G2);
	
	StopScanSequance_XY();
	
	return 0;	
	
Error:
	
return -1;
}
void AssignDaqDataTo_XYarrayChns(DAQtaskData *daqData,double *pointData,int group,int arrY_Pos,int arrX_Pos, int CollectionTimes)
{

	int k;
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)  if(daqData[k].Dev_Status && daqData[k].Group==group) XYarray[arrY_Pos][arrX_Pos].data[k]+=pointData[k]/CollectionTimes; 
}

int CVICALLBACK f_scan_emr_stop (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			ScanBreak=SCAN_BREAK_STOP;
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			SPECTRAL 		///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int GetSpectralWavelengthData()
{
	int count,i=0,size=0;
	int waveMin1=0, waveMax1=0, res1=0, aoft1=0, size1=0;
	int waveMin2=0, waveMax2=0, res2=0, aoft2=0, size2=0; 
	int waveMin3=0, waveMax3=0, res3=0, aoft3=0, size3=0; 
	int waveMin4=0, waveMax4=0, res4=0, aoft4=0, size4=0; 
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_1,&aoft1);
	if(aoft1)
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_1,&waveMin1);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_1,&waveMax1);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_1,&res1);	
		size1 =  (waveMax1-waveMin1)/res1;
		if (!((waveMax1-waveMin1)%res1)) size1++;
		
	}
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_2,&aoft2);
	if(aoft2)	
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_2,&waveMin2);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_2,&waveMax2);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_2,&res2);	
		size2 = (waveMax2-waveMin2)/res2;
		if (!((waveMax2-waveMin2)%res2)) size2++;
	}

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_3,&aoft3);
	if(aoft3)	
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_3,&waveMin3);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_3,&waveMax3);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_3,&res3);	
		size3 = (waveMax3-waveMin3)/res3;
		if (!((waveMax3-waveMin3)%res3)) size3++;
	}

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_4,&aoft4);
	if(aoft4)	
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_4,&waveMin4);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_4,&waveMax4);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_4,&res4);	
		size4 = (waveMax4-waveMin4)/res4;
		if (!((waveMax4-waveMin4)%res4)) size4++;
	}
	size=size1+size2+size3+size4;
	WavelengthArray = (SpectralPoint*) calloc(size, sizeof(SpectralPoint)); 
	
	count=0;
	if(aoft1)
		for(i=size1-1; i>=0;i--)
			if((waveMax1-count*res1)>=waveMin1) 
			{	
				WavelengthArray[i].Wavelength=waveMax1-count*res1;
				WavelengthArray[i].AOTF_num= aoft1;
				count++;
			}
	count=0;
	if(aoft2)
		for(i=size2-1; i>=0;i--)
			if((waveMax2-count*res2)>=waveMin2) 
			{	
				WavelengthArray[i].Wavelength=waveMax2-count*res2;
				WavelengthArray[i].AOTF_num=aoft2;
				count++;
			}
	count=0;
	if(aoft3)
		for(i=size3-1; i>=0;i--)
			if((waveMax3-count*res3)>=waveMin3) 
			{	
				WavelengthArray[i].Wavelength=waveMax3-count*res3;
				WavelengthArray[i].AOTF_num=aoft3;
				count++;
			}
	count=0;
	if(aoft4)
		for(i=size4-1; i>=0;i--)
			if((waveMax4-count*res4)>=waveMin4) 
			{	
				WavelengthArray[i].Wavelength=waveMax4-count*res4;
				WavelengthArray[i].AOTF_num=aoft4;
				count++;
			}
	return size;
}


void  SetCurrentWavelength( SpectralPoint CurPoint)
{
	int Dev;
	
	
	
	if (ActiveAOTF != CurPoint.AOTF_num)
	{	
		char config_msg[120]="Please change system state to the current AOTF configuration: ";
		char tmpSTR[3]="";
			   
		sprintf(tmpSTR,"%d " ,CurPoint.AOTF_num);
		strcat(config_msg,tmpSTR);
		strcat(config_msg,"\n Reminder: 1-vis, 2- nir, 3-nir2");
		
		ConfirmPopup ("System State", config_msg);
	 	ActiveAOTF= CurPoint.AOTF_num;
	}
	
	Dev= GetAOTFdevID_From_aotf_type(CurPoint.AOTF_num);
	if(CurPoint.RF_Power)	Set_AOTF_freq_gain(Dev,0,Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength), CurPoint.RF_Power);
	else 					Set_AOTF_freq(Dev,0,Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength));

	
	
}

void MoveToBG_AFandBalanceSet(int powerBalance_active, int AF_active, int Loc)
{
	int tmp=0;
	double  tolerance;
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,&tolerance);
	if(powerBalance_active||AF_active)
		if (Micronix_Online) MoveToLocation(Loc,BACKGROUND_LOC); 		

	if(AF_active)  f_AutoFocus();	
	if(powerBalance_active)	tmp= SetPowerBalance(tolerance);

	if (tmp<0) ConfirmPopup ("Power Balance Failed", "Here is your option to manually adjust the power balance");
}
void MoveToScanOrigin(int scanLoc,int pSearchType)
{
	switch(	pSearchType)
	{
		case SEARCH_TYPE_ORIGIN: 
			MoveToLocation(scanLoc,SCAN_LOC); 
			return;
		
		case SEARCH_TYPE_MIN:
			MicronixParam->Axis=X_AXIS;
			MicronixParam->data1=Min_Location.X;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			MicronixParam->Axis=Y_AXIS;
			MicronixParam->data1=Min_Location.Y;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			break;
			
		case SEARCH_TYPE_MAX:
			MicronixParam->Axis=X_AXIS;
			MicronixParam->data1=Max_Location.X;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			MicronixParam->Axis=Y_AXIS;
			MicronixParam->data1=Max_Location.Y;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			break;
			
		
	}
	
}
void AdjustFileNameToCurrentWavelength(int wavelength, char *name)
{
	char tmpStr[6]; 					
	
	strcpy(sData.FileName,name);
	strcat(sData.FileName,"W");
	sprintf(tmpStr,"%d",wavelength);
	strcat(sData.FileName,"tmpStr");	
}

void  GetSpectralScanSettings(int *AFcorection, int *powerBalanceCorection, int *scanLoc  ,int *pSearchType, int PanelHandleMain)
{
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AF_ON_SCAN, AFcorection);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SPLIT_PWR_STEP_ADJ, powerBalanceCorection);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SPC_BAGROUND_LOCATION, scanLoc);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SEARCH_TYPE_MAX_MIN, pSearchType);
	GetXYScanData(PanelHandleMain);
	SaveLocation(0,BACKGROUND_LOC);	
}
int CVICALLBACK f_start_spectral (int panel, int control, int event,
								  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp, curWavelength,arrSize,i;
			int AFcorection,powerBalanceCorection,scanLoc,pSearchType;
			char FileNameConst[MAX_FILE_NAME_LENGTH]="";

			
			GetCtrlVal(panel,control,&tmp); 
			
			if (tmp && ScanRunning) ScanBreak = SCAN_BREAK_PAUSE;
			else if (!tmp && ScanRunning) ScanBreak=RUN_SCAN;
			else if(tmp && !ScanRunning)
			{
			
				ScanRunning=1;
													
				SetGUI_ForSpectralScan(PanelHandleMain,PanelHandelGraph2,PanelHandelSpectrarlChart);
				arrSize=GetSpectralWavelengthData();
				
				GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType, PanelHandleMain);
				
				strcpy(FileNameConst,sData.FileName);
				
				Set_AOTF_ALL_Zero();
				
				for(i=arrSize-1;i>=0;i--)
				{
					SetCurrentWavelength(WavelengthArray[i]);
					
					AdjustFileNameToCurrentWavelength(WavelengthArray[i].Wavelength, FileNameConst);
					
					MoveToBG_AFandBalanceSet(powerBalanceCorection, AFcorection, scanLoc);
					
					MoveToScanOrigin(scanLoc, pSearchType);
					
					CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, XY_Scan, NULL, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, 0, &ScanThreadID);
					CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);	
					if(ScanBreak==SCAN_BREAK_STOP) i=-2;
					
					AddPointToSpectralChart(PanelHandelSpectrarlChart, WavelengthArray[i].Wavelength, XY_ScanMax, XY_ScanMin);
				 }													   
			
				ScanRunning=0;
				free(WavelengthArray);
				SetGUI_AfterScan(PanelHandleMain);
				
			}
		
			
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////			FILE Save & Load				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK fLoadImage (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		
		case EVENT_COMMIT:
			int  status; 
			char path[MAX_FILE_NAME_LENGTH];
			FILE *pFile;
			char lineStr[MAX_LINE_READ_LEN];
			int i,j,numCols,numLines,scaleFactor,scaleType;
			float val;
			double **arr,minVal=1000,maxVal=-1000;
			
			status = FileSelectPopup ("", "*.*", "*.AI_*", "Load Image File", VAL_LOAD_BUTTON, 0, 0, 1, 0, path);
			if (!status) return -1;
			
			pFile=fopen(path,"r");
			if ( pFile == NULL ) return -2;
			
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
	
			fscanf (pFile, " %s %d [^\n]\n", lineStr, &numLines);
			fscanf (pFile, " %s %d [^\n]\n", lineStr, &numCols); 
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			
			arr=(double**)malloc(numLines*sizeof(double*));
			for(i=0;i<numLines;i++) arr[i]=(double*)calloc(numCols,sizeof(double));
			
			for(i=0;i<numLines;i++)
				for(j=0;j<numCols;j++)
				{
					fscanf (pFile, " %f ", &val);
					arr[i][j]=(double)val;
					if(val>maxVal) maxVal=val;
					if(val<minVal) minVal=val;  
				}
			fclose(pFile);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_PLOT_COLORMAP  ,&scaleType);
			LoadColormap( scaleType, maxVal, minVal); 
			PlotScaleBar(panel, MAIN_PANEL_XY_SCAN_PLOT_SCALE_1) ; 
			if(numCols>numLines)	scaleFactor=GRAPH_SIZE/numCols;
			else 					scaleFactor=GRAPH_SIZE/numLines;
			UpdateGraph( panel, MAIN_PANEL_XY_SCAN_PLOT_1, arr,numCols, numLines, scaleFactor);   
			////
			
			break;
	}
	return 0;
}

void GetFileAndFolderNames( int panel)
{
	char tmpStr[MAX_FILE_NAME_LENGTH]="";
	
										   
	GetCtrlVal(panel,MAIN_PANEL_FILE_NAME, tmpStr);
	if(strlen(tmpStr)<1) 
	{
		PromptPopup ("File Name Error", "Please enter a file name", tmpStr, MAX_FILE_NAME_LENGTH);
		SetCtrlVal(PanelHandleMain,MAIN_PANEL_FILE_NAME, tmpStr);
	}
	strcpy (sData.FileName, tmpStr);
	strcpy (tmpStr, "");
	
	GetCtrlVal(panel,MAIN_PANEL_FOLDER_NAME,tmpStr );
	
	if(strlen(tmpStr)<1) 
	{
		f_folder_browse(tmpStr);
		SetCtrlVal (panel, MAIN_PANEL_FOLDER_NAME, tmpStr);	
	}
	strcpy (sData.FolderName, tmpStr);
}

int CVICALLBACK scan_folder_browse (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			char directory_name[MAX_FILE_NAME_LENGTH];  
			f_folder_browse(directory_name);
			
			SetCtrlAttribute (panel, MAIN_PANEL_FOLDER_NAME, ATTR_DFLT_VALUE, directory_name);
			SetCtrlVal (panel, MAIN_PANEL_FOLDER_NAME, directory_name);
			break;
	}
	return 0;
}
int f_create_save_file_name(char * path, int scannumber,char * ftype)
{
	char tmpSTR[MAX_SCAN_NUMBER_LEN/2],tmpSTR2[MAX_SCAN_NUMBER_LEN+1]="";
	
	if (strlen(sData.FolderName)<1) return -1;
	strcpy(path,sData.FolderName);
	if(sData.FolderName[strlen(sData.FolderName)]!='\\') strcat (path, "\\");
	strcat (path, sData.FileName);
	
	sprintf (tmpSTR, "%d", scannumber);
	while((strlen(tmpSTR)+strlen(tmpSTR2))<MAX_SCAN_NUMBER_LEN)
	{
		strcat (tmpSTR2, "0");	
	}
	
	strcat (tmpSTR2, tmpSTR);
	strcat (path, "_");
	strcat(path,tmpSTR2);
	strcat(path,ftype);

	return 0;
}

FILE* MakeFile(char *fileName)
{
	FILE *pFile;
	if((pFile = fopen (fileName,"w"))==NULL)
	{
		MessagePopup ("Error", "Can't open file for saving data");
		return NULL;
	}	
	fclose(pFile);
	return  pFile;
}

char** CreateOutPutFiles_XY(void)
{
	int k,scannum;
	char **resFileNames;
	char tmpStr[8]="", AInum[4]="";

	resFileNames = (char **)malloc((sData.AI_Number+1)*sizeof(char*));
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_SCAN_NUMBER, &scannum);
	strcpy(tmpStr,".AI_");
	
	for (k=0;k<sData.AI_Number; k++)
	{
		resFileNames[k] = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));  
		strcpy(resFileNames[k],"");
		
		sprintf (AInum, "%d", k);
		strcat(tmpStr,AInum);
		f_create_save_file_name(resFileNames[k], scannum,tmpStr);
		strcpy(AInum,"");
		strcpy(tmpStr,".AI_");
		MakeFile(resFileNames[k]);
	}
	resFileNames[k] = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	f_create_save_file_name(resFileNames[k], scannum,".Output");
	MakeFile(resFileNames[k]);
	return resFileNames;
	
}
int CVICALLBACK fSaveImage (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		
		
		int  scannum;
		char filename[MAX_FILE_NAME_LENGTH/2],foldername[MAX_FILE_NAME_LENGTH/2];
		char path[MAX_FILE_NAME_LENGTH];
		
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_FILE_NAME, filename);
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_FOLDER_NAME, foldername);
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_SCAN_NUMBER, &scannum);
		
		f_create_save_file_name(path,scannum, PNG_TYPE);
		SaveGraphToImage(path,PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1 );
		
		break;
	}
	return 0;
}

double **AlocateDoubleArray(int ySize,int xSize)
{
	double **array;
	int y;
	
	array = (double **)malloc((ySize)*sizeof(double*));
	
	for(y=0;y<ySize;y++) 
		array[y] = (double *)malloc((xSize)*sizeof(double));
	
	return array;
		
}
int FreeArray(double **arr, int ySize)
{
	int k;
	
	for (k=0;k<ySize;k++)
		if (arr[k]!=NULL) free(arr[k]);
	free(arr);
	return 0;
	
}
double GetSellectedChannelData(int graph_num, int y, int x)
{
	
	int chan=0;
	
	if( graph_num ==1)
			GetCtrlVal(PanelHandleMain, MAIN_PANEL_CHANNEL_PLOT_SELECT_1, &chan);
	else if( graph_num ==2) 
			GetCtrlVal(PanelHandelGraph2, PLOT_PANEL_CHANNEL_PLOT_SELECT_2, &chan);   
			
	if (chan>0) 
		return XYarray[y][x].data[chan];
	else
	{
		GetCtrlVal(PanelHandleMain, MAIN_PANEL_CHANNEL_PLOT_SELECT_1, &chan);
		return oldXYarray[y][x].data[chan];
	}

}
int CVICALLBACK ChangeColorMap (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int type,i,j; 
			double max, min;
			double **arr;
			int gScaleFactor;
			
			arr=(double**)malloc((Y_Scan_size)*sizeof(double*));
			for (i=0;i<X_Scan_size;i++)	arr[i]=(double*)calloc(X_Scan_size,sizeof(double));
			
			
			GetCtrlVal(panel, MAIN_PANEL_MAX_SCALE,&max);
			GetCtrlVal(panel, MAIN_PANEL_MIN_SCALE,&min);
			GetCtrlVal(panel,MAIN_PANEL_PLOT_COLORMAP,&type);
			
			LoadColormap(type,max,min);
			PlotScaleBar(PanelHandleMain,MAIN_PANEL_XY_SCAN_PLOT_SCALE_1);
			
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
						arr[i][j]=XYarray[i][j].data[PlotChan]/XYarray[i][j].data[RefChan];
			
			gScaleFactor=GetScaleFactor();
			UpdateGraph(PanelHandleMain,MAIN_PANEL_XY_SCAN_PLOT_1, arr  ,X_Scan_size,Y_Scan_size,gScaleFactor);
			
			for (i=0;i<X_Scan_size;i++)	free(arr[i]);  
			free(arr);
			
			break;
	}
	return 0;
}

void WriteXY_FileHeader(FILE* pFile)
{
	fprintf(pFile,"Wavelength [nm]:\t%d\n",sData.wavelength);	
	fprintf(pFile,"Y_Scan_Points:\t%d\n",Y_Scan_size);
	fprintf(pFile,"X_Scan_Points:\t%d\n",X_Scan_size); 
	fprintf(pFile,"Y_Scan_Size[um]:\t%f\t Y Resolution[um]:\t%f\n",sData.Y_Size,sData.Y_Step ); 
	fprintf(pFile,"X_Scan_Size[um]:\t%f\t X Resolution[um]:\t%f\n",sData.X_Size,sData.X_Step );
	fprintf(pFile,"Scan Direction:\t%d\n",sData.ScanDir);
	
	
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////			AOTF				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK Change_AOTF_Dev_IDs (int panel, int control, int event,
									 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetAOTF_IDs( PanelHandelAOTFSettings , &VIS_ID, &NIR_ID, &NIR2_ID);
			SetAOTF_IDs(VIS_ID,NIR_ID,NIR2_ID);
			break;
	}
	return 0;
}
int CVICALLBACK AOTFSendString (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			char cmd[MAX_AOTF_CMD_LEN];
			int DevID=-1;
			int aotf_name;
			
			GetCtrlVal(PanelHandelAOTFSettings , AOTF_SETTI_AOTF_CMD_TEXT, cmd);
			GetCtrlVal(PanelHandelAOTFSettings , AOTF_SETTI_AOTF_DEVICE_ID, &aotf_name);
			
			
			switch (aotf_name)
			{
				case VIS:
					DevID=VIS_ID;	
				break;
		
				case NIR:
					 DevID=NIR_ID;
				break;
		
				case NIR2:
					 DevID=NIR2_ID; 
				break;
			
			}
			
			if (AOTF_Online) AOTFSendStringCmd(cmd, DevID);
			
			break;
	}
	return 0;
}
int GetAOTFdevID_From_aotf_type(aotf_type)
{
	int tmp=-1;
	
	switch(aotf_type)
	{
		case VIS:
			return VIS_ID;
		case NIR:
			return NIR_ID;
		case NIR2:
			return NIR2_ID;
	}
	return -1;
}
int CVICALLBACK f_AOTF_UPDATE (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int control2;
			int wavelength, gain,state;
			int chan, aotf_type, command_Type,state_control;
			int Dev=-1;
			double freq=0.0;
			
			
			control2=GetAOTFUsefullControlNumber(control);
			aotf_type = GetAOTF_ID_FromControlHandle(control2);
			chan = GetAOTF_Channel_FromControlHandle(control2);
			command_Type = GetAOTF_Command_FromControlHandle(control2);
			state_control = GetAOTFControlFromUsfulNumber (control2);
			Dev= GetAOTFdevID_From_aotf_type(aotf_type);
			
			GetCtrlVal(panel,state_control,&state);
			if (state)
			{
				switch (command_Type)
				{
					case AOTF_COMMAND_SET_STATE:
						 GetCtrlVal(panel, GetAOTFControlFromUsfulNumber(control2+10),&wavelength);
						 GetCtrlVal(panel, GetAOTFControlFromUsfulNumber(control2+20),&gain);
						 if(AOTF_Online)  Set_AOTF_freq_gain(Dev, chan,Find_Freq_From_Wavelength_Dev(aotf_type,wavelength),gain); 
					break;
					
					case AOTF_COMMAND_SET_WAVE:
						 GetCtrlVal(panel,control,&wavelength);
						 if(AOTF_Online) Set_AOTF_freq(Dev, chan, Find_Freq_From_Wavelength_Dev(aotf_type,wavelength));
					break;
					
					case AOTF_COMMAND_SET_POWER:
						 GetCtrlVal(panel,control,&gain); 
						 if(AOTF_Online) Set_AOTF_gain(Dev,chan,gain);
					break;
				}
			}
			else  
				if(AOTF_Online) Set_AOTF_gain(Dev,chan,0);	
		break;
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////			FIANIUM				///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK power_update (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			double tmp; 
			switch(control)
			{
			case MAIN_PANEL_Fu_POWER_OUT:
				GetCtrlVal (panel, MAIN_PANEL_Fu_POWER_OUT, &tmp);
				if(Fianium_Online) LaserPowerUpdate(FUNDAMENTAL_OUTPUT,tmp);
				
				break;
				
			case MAIN_PANEL_SC_POWER_OUT:
				GetCtrlVal (panel, MAIN_PANEL_SC_POWER_OUT, &tmp);
				if(Fianium_Online) LaserPowerUpdate(SC_OUTPUT,tmp);

			}
			break;
			
			
	}
	return 0;
}








///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////			MICRONIX				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void  MicronixErrorProcedure()
{
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_SHOW_SETINGS,STATE_ON);
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_LED,STATE_OFF);
	SetCtrlVal(PanelHandelMicronixSettings,MICRONIX_S_MICRONIX_ERR_MSG,MicronixErrorString);   
	DisplayPanel( PanelHandelMicronixSettings );	
}

void StartMicronixStages(void)
{
	GetMotorsAxisIDs(PanelHandelMicronixSettings, &X_AXIS, &Y_AXIS, &Z_AXIS);
	SetMotorsAxisIDs(X_AXIS, Y_AXIS, Z_AXIS);
	OpenMicronixPort(DevicesSessionManeger);
	InitializeMicronixStages();
	Micronix_STATUS=1;
}
int CVICALLBACK fnc_xyz_stop (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MicronixStop(0);
			break;
	}
	return 0;
}
int CVICALLBACK fnc_z_stop (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			MicronixParam->Axis=Z_AXIS;
			MicronixStop(MicronixParam); 
			break;
	}
	return 0;

}
int CVICALLBACK fMpveContinus (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case 	EVENT_LEFT_CLICK:
				SetMouseCursor (VAL_HOUR_GLASS_CURSOR);
				//This fonction initiates a continus move as long as the left mouse button is pressed on the control.
			
				
				switch (control)
					{
						case MAIN_PANEL_UP_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Y_AXIS;
						break;
							
						case MAIN_PANEL_DOWN_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Y_AXIS;
						break;
						
						case MAIN_PANEL_LEFT_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=X_AXIS;
						break;
						
						case MAIN_PANEL_RIGHT_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=X_AXIS;
						break;
						
						case MAIN_PANEL_Z_MINUS:
							GetCtrlVal (panel, MAIN_PANEL_Z_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Z_AXIS;
						break;
						
						case MAIN_PANEL_Z_Plus:
							GetCtrlVal (panel, MAIN_PANEL_Z_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Z_AXIS;
						break;
					  
					}
				int tmp=1;   
				while (tmp)
				{
					if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
					DelayWithEventProcessing(0.2);
					GetGlobalMouseState (NULL, NULL, NULL, &tmp, NULL, NULL);
				}
				
				
				if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIX_X_POS, MicronixPOS_Query(X_AXIS)); //updates the display.
				Delay(USB_COM_DELAY);
				if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIX_Y_POS, MicronixPOS_Query(Y_AXIS)); //updates the display.  
				Delay(USB_COM_DELAY);
				if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIXZPOS, MicronixPOS_Query(Z_AXIS)); //updates the display.
				SetMouseCursor(VAL_DEFAULT_CURSOR); 
				
				if (Micronix_STATUS<0)  MicronixErrorProcedure();
				
		break;
	
	
	
	}
	return 0;
	
}
int CVICALLBACK MicronixPowerOnOff (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			GetCtrlVal(panel,control,&tmp);
			if(tmp) 
			{
				StartMicronixStages();
			}
			else	
			{
				CloseMicronixInstrSession();
				Micronix_STATUS = 0;	
			}
			SetCtrlVal(PanelHandleMain, MAIN_PANEL_MICRONIX_LED, tmp);
			
			break;
	}
	return 0;
}
int CVICALLBACK ChangeMotorIDs (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetMotorsAxisIDs(PanelHandelMicronixSettings,&X_AXIS, &Y_AXIS, &Z_AXIS);
			SetMotorsAxisIDs(X_AXIS, Y_AXIS, Z_AXIS);
			break;
	}
	return 0;
}
int CVICALLBACK ClearErrorMsgBox (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			ResetTextBox (panel, MICRONIX_S_MICRONIX_ERR_MSG, "");
			
			break;
	}
	return 0;
}
int CVICALLBACK fnc_XY_home (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MicronixParam->Axis=X_AXIS;
			Micronix_STATUS = Micronixthreaded(MicronixParam, MOTOR_HOME);
			
			MicronixParam->Axis=Y_AXIS;
			Micronix_STATUS = Micronixthreaded(MicronixParam, MOTOR_HOME);
			break;
	}
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;
}
int CVICALLBACK MicronixSendString (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			char cmd[MAX_MICRONIX_CMD_LEN];
			
			GetCtrlVal(PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_CMD_TEXT, cmd);
			if (Micronix_Online)	MicronixSendCMD(cmd); 
			break;
	}
	return 0;
}
int CVICALLBACK fZPOS_CHK (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_TIMER_TICK:
			ViReal64 output = 0;
			output=MicronixPOS_Query(Z_AXIS);
			SetCtrlVal (PanelHandleMain,MAIN_PANEL_indMICRONIXZPOS, output); //updates the display. 
			break;
			
	}
	return 0;
}
int CVICALLBACK fnc_MicronixSpeed (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(control==MICRONIX_S_XY_SPEED)
			{
				MicronixParam->Axis=X_AXIS;
				GetCtrlVal(panel,control,&MicronixParam->data1);
				Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_SPEED); 
				MicronixParam->Axis=Y_AXIS; 
				Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_SPEED); 
			break;	
			}
			else
			{
				MicronixParam->Axis=Z_AXIS;
				GetCtrlVal(panel,control,&MicronixParam->data1);
				Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_SPEED); 	
			}
			break;
	}
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;
}
int CVICALLBACK fnc_MicronixAcceleration (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MicronixParam->Axis=X_AXIS;
			GetCtrlVal(panel,control,&MicronixParam->data1);
			Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_ACCELERATION); 
			MicronixParam->Axis=Y_AXIS; 
			Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_ACCELERATION); 
			break;
	}
	if (Micronix_STATUS<0) MicronixErrorProcedure();
	return Micronix_STATUS;
}
int fMicronixCenterOnPoint(double xP,double yP)
{
	MicronixParam->Axis=X_AXIS;
	MicronixParam->data1=xP;
	if (Micronix_Online) Micronix_STATUS=Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	
	
	MicronixParam->Axis=Y_AXIS;
	MicronixParam->data1=yP;
	if (Micronix_Online) Micronix_STATUS=Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;
}
int  CVICALLBACK fCenterOnSpot (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			double xi,yi;
			GetCtrlVal (panel, MAIN_PANEL_PLOT1_XPOS, &xi);
			GetCtrlVal (panel, MAIN_PANEL_PLOT1_YPOS, &yi);
			fMicronixCenterOnPoint(xi/1000.0,yi/1000.0);  // Micronix needs the values in mm form
			break;
	}
   return 0;
}
void SaveLocation(int loc,int type)	
{
	switch(type)
	{
		case SCAN_LOC:
			StoredLoc[loc].Scan_Loc.Point_Status = 1;
			if(!Micronix_Online) return;
			StoredLoc[loc].Scan_Loc.X  = MicronixPOS_Query(X_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].Scan_Loc.Y  = MicronixPOS_Query(Y_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].Scan_Loc.Z  = MicronixPOS_Query(Z_AXIS);
			
			
			break;
			
		case BACKGROUND_LOC:
			StoredLoc[loc].BG_Loc.Point_Status = 1;
			if(!Micronix_Online) return;  
			StoredLoc[loc].BG_Loc.X  = MicronixPOS_Query(X_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].BG_Loc.Y  = MicronixPOS_Query(Y_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].BG_Loc.Z  = MicronixPOS_Query(Z_AXIS);	
			
			
			break;
	}

}
int MoveToLocation(int loc,int type)
{
	int tmp;
	switch(type)
	{
		case SCAN_LOC:
			if (!StoredLoc[loc].Scan_Loc.Point_Status) return -1;
			MicronixParam->Axis=X_AXIS; 
			MicronixParam->data1=StoredLoc[loc].Scan_Loc.X;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			MicronixParam->Axis=Y_AXIS; 
			MicronixParam->data1=StoredLoc[loc].Scan_Loc.Y;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_STORELOC_Z_MOVE,&tmp);
			if (tmp)
			{
				MicronixParam->Axis=Z_AXIS; 
				MicronixParam->data1=StoredLoc[loc].Scan_Loc.Z;
				Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			}
			break;
			
		case BACKGROUND_LOC:
			if (!StoredLoc[loc].BG_Loc.Point_Status) return -1;  
			MicronixParam->Axis=X_AXIS; 
			MicronixParam->data1=StoredLoc[loc].BG_Loc.X;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			MicronixParam->Axis=Y_AXIS; 
			MicronixParam->data1=StoredLoc[loc].BG_Loc.Y;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_STORELOC_Z_MOVE,&tmp);
			if (tmp)
			{
				MicronixParam->Axis=Z_AXIS; 
				MicronixParam->data1=StoredLoc[loc].BG_Loc.Z;
				Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			}
			break;
	}
	
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;

		
}
void ResetStoredLocationButtonColors(void )
{
	
	int color[NUMBER_OF_STORED_LOCATIONS][2]={0},k;
	
	for (k=1;k<NUMBER_OF_STORED_LOCATIONS;k++)
	{
		if(StoredLoc[k].Scan_Loc.Point_Status) 	color[k][0] = VAL_YELLOW ;	
		else	color[k][0] = 0x00FF9900 ;				
		if(StoredLoc[k].BG_Loc.Point_Status) 	color[k][1] = VAL_YELLOW ;
		else color[k][1] =  0x00FF9900 ;				 
	}
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_1, 	ATTR_CMD_BUTTON_COLOR, color[1][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG1, 	ATTR_CMD_BUTTON_COLOR, color[1][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_2, 	ATTR_CMD_BUTTON_COLOR, color[2][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG2, 	ATTR_CMD_BUTTON_COLOR, color[2][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_3, 	ATTR_CMD_BUTTON_COLOR, color[3][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG3, 	ATTR_CMD_BUTTON_COLOR, color[3][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_4,	 	ATTR_CMD_BUTTON_COLOR, color[4][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG4, 	ATTR_CMD_BUTTON_COLOR, color[4][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_5, 	ATTR_CMD_BUTTON_COLOR, color[5][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG5, 	ATTR_CMD_BUTTON_COLOR, color[5][1]);
}

int CVICALLBACK fStoredLocEvent (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int loc,type,saveORmove,tmp=0;
			loc=GetLocationTypeandNum_FromControl(control);
			type = loc%10;
			loc  = loc/10;
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_SAVE_MOVE_CHK,&saveORmove);
			
			switch (saveORmove)
			{
				case VAL_SAVE:
					SaveLocation(loc,type);
					SetCtrlAttribute (panel, control, ATTR_CMD_BUTTON_COLOR, VAL_YELLOW);
					break;
					
				case VAL_MOVE:
					if (Micronix_Online) tmp= MoveToLocation(loc,type);
					if(tmp<0) return -1;
					ResetStoredLocationButtonColors();
					SetCtrlAttribute (panel, control, ATTR_CMD_BUTTON_COLOR, VAL_DK_GREEN); 
					break;
					
			}
	}
	return 0;
}

int CVICALLBACK fnc_MicronixPID_SET (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			double  P_PID,I_PID,D_PID=0.0;
			
			
			GetCtrlVal (PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_PID_P, &P_PID);
			GetCtrlVal (PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_PID_I, &I_PID);  
			
			MicronixParam->Axis=MICRONIX_ALL_AXES;      
			MicronixParam->data1=P_PID;	
			MicronixParam->data2=I_PID;	
			MicronixParam->data3=D_PID;	
			Micronixthreaded(MicronixParam, MOTOR_SET_PID);			
			break;
	}
	return 0;
}
int CVICALLBACK f_Focus_Swing (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
		int i,j;
		double Zinitial=0.0;
	
		Zinitial=MicronixPOS_Query(Z_AXIS);
		Delay(USB_COM_DELAY);
		for(i=0;i<30;i++)
			for(j=-10;j<10;j++)
			{
				MicronixParam->Axis=Z_AXIS;
				MicronixParam->data1=Zinitial+j/20000.0;
				Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
				Delay(0.05);
			}
	
		MicronixParam->Axis=Z_AXIS;
		MicronixParam->data1=Zinitial;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	
		break;
	}
	return 0;
}
double f_AutoFocus(void)
{
	int freq,samps, AF_type,maxSteps=20;
	int i,i_max=0;
	DAQtaskData data;
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'};
    TaskHandle 	 AFdaqTask=NULL;
	double pointdata,MaxVal;
	double  Zinitial,ZmaxReading, stepSize;

	
	data.maxIn=10;
	freq=200000;
	samps=3000;
	stepSize=20.0/1000000; //20nm in mm.
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AF_CHANNEL , data.DevID);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AF_METHOD , &AF_type);	
	
	
	
	DAQmxErrChk(DAQmxCreateTask("AF_Task", &AFdaqTask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (AFdaqTask, data.DevID,  "AF_Chan", DAQmx_Val_RSE, -data.maxIn, data.maxIn, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (AFdaqTask, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	DAQmxStartTask(AFdaqTask);
	GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata);
	DAQmxStopTask(AFdaqTask);

	MaxVal=pointdata;
	Zinitial=MicronixPOS_Query(Z_AXIS);
	ZmaxReading=Zinitial;
	MicronixParam->Axis=Z_AXIS;
	
	for(i=1;i<=maxSteps;i++)
	{
		MicronixParam->data1=Zinitial+stepSize*i;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);

		DAQmxErrChk (DAQmxStartTask(AFdaqTask));
		GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata);
		DAQmxStopTask(AFdaqTask);
			
		if(AF_type==AF_ON_MAX)
		{
			if( (pointdata)>=(MaxVal))
			{
				ZmaxReading=MicronixPOS_Query(Z_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if((i-i_max)>4) break;	
		}
		else
		{
			if(fabs(pointdata)>=fabs(MaxVal))
			{
				ZmaxReading=Zinitial+stepSize*i;
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if((i-i_max)>4) break;	
		}
	}
	for(i=-1;i>=-maxSteps;i--)
	{
		MicronixParam->data1=Zinitial+stepSize*i;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);

		DAQmxErrChk (DAQmxStartTask(AFdaqTask));
		GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata);
		DAQmxStopTask(AFdaqTask);
		
		if(AF_type==AF_ON_MAX)
		{
			if( (pointdata)>=(MaxVal))
			{
				ZmaxReading=Zinitial+stepSize*i;
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if(abs(i-i_max)>4) break;	
		}
		else
		{
			if( fabs(pointdata)>=fabs(MaxVal))
			{
				ZmaxReading=Zinitial+stepSize*i;
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if(abs(i-i_max)>4) break;	
		}
		
	}
	
	MicronixParam->data1=ZmaxReading;
	Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);

	DAQmxClearTask (AFdaqTask);
	
	return (ZmaxReading-Zinitial);
		
		

Error:

	MicronixParam->data1=Zinitial;
	Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	
	if( DAQmxFailed (error) )
		DAQmxGetExtendedErrorInfo(errBuff,2048);
	if( AFdaqTask!=0 ) 
		DAQmxStopTask(AFdaqTask);
		DAQmxClearTask (AFdaqTask);
		
	if( DAQmxFailed (error) )
		MessagePopup("DAQmx Error",errBuff);
	return 0.0;
}

int CVICALLBACK AutoFocusButton (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
	{
		case EVENT_COMMIT: 
		f_AutoFocus();		
	}
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			PEM				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK fPEM_Control (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	if(PEM_ONLINE) 
	{
		switch (event)
		{
			case EVENT_COMMIT:
					int tmp;
					switch (control)
					{
						case MOD_SETTIN_PEM_ON_OFF:
							GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_ON_OFF,&PEM_STATUS);
							if(PEM_STATUS)
							{
								GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&tmp); 
								PEM_change_R(tmp);
								Delay(0.25); 
								GetCtrlVal(PanelHandleMain,MAIN_PANEL_WAVELENGTH_INDICATOR,&tmp);  
								if(tmp) PEM_change_Wavelength(tmp);
								Delay(0.25); 
								PEM_STATUS=1;
							}
							else
							{
								PEM__Inhibit(1); //Make sure No modulation is on
								Delay(0.25);
								Close_PEM_port_RS232() ;
								PEM_STATUS=0;
							}
						break;
					
						case MOD_SETTIN_PEM_RETARDANCE: 
							if(PEM_STATUS)
							{
								GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&tmp); 
								PEM_change_R(tmp);
								
							}
						break;
					
					}
				break;
		}
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			DAQ				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
 int CVICALLBACK DAQ_stateChange (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int group1=0, group2=0, activChanSeq[MAX_DAQ_AI_CHAN]={0};
			
			GetNumberOfActiveChannelsInEachGroup(PanelHandelDAQsettings, &group1, &group2, activChanSeq);
			if(group1) SetCtrlAttribute (PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP1, ATTR_MAX_VALUE, DAQ_MAX_SAMPLE_RATE/group1 );
			if(group2) SetCtrlAttribute (PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP2, ATTR_MAX_VALUE, DAQ_MAX_SAMPLE_RATE/group2 ); 
			UpdatePlotListControl(activChanSeq, PanelHandleMain, PanelHandelGraph2);
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			Power Balance     /////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

int f_rotate_wheel(double StepSize)
{
	long tmp=0;
	if(!Rotation_Online)  return -1;
	MG17MotorLib__DMG17MotorMoveRelativeEx (rotorStageHandle, NULL, 0, StepSize, 0, VTRUE, &tmp);
	return 0;
}
int SetPowerBalance(double tolerance)
{
		
	int freq,samps,maxSteps=30;
	int counter=0,tmp;
	DAQtaskData data[2];
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'},tmpStr[3];
    TaskHandle 	 PowerDAQtask=NULL;
	double pointdata[2],delta,lvalue;
	double  stepSize;
	int RotateDirection,DeltaSign,DeltaSignLast;

	  
	data[0].maxIn=10;
	data[1].maxIn=10;
	freq=100000;
	samps=1500;
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_REF_CHANNEL , &tmp);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_BALANCE_CHAN , data[1].DevID); 
	strcpy(data[0].DevID,data[1].DevID);
	data[0].DevID[7]='\0';
	sprintf(tmpStr,"%d",tmp);	
	strcat(data[0].DevID,tmpStr);
	
	DAQmxErrChk(DAQmxCreateTask("PowerBalanceTask", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, data[0].DevID,  "RefChan", DAQmx_Val_RSE, -data[0].maxIn, data[0].maxIn, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, data[1].DevID,  "TargetChan", DAQmx_Val_RSE, -data[1].maxIn, data[1].maxIn, DAQmx_Val_Volts, ""));
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	DAQmxStartTask(PowerDAQtask);
	GetDataFromDAQ(PowerDAQtask, 2, samps, pointdata);	
	
	stepSize = 0.5;
	delta=(GetBalanceValFromData(pointdata[1],pointdata[0]));
	DeltaSignLast=(delta/fabs(delta));
	if (fabs(delta)>1.5)   stepSize = 10;
	else if  (fabs(delta)>0.5)    stepSize = 5; 

	if (delta>0)
		RotateDirection=-1;		
	else
	  	RotateDirection =1;
	lvalue=fabs(delta);
	do 
	{
		f_rotate_wheel(stepSize*RotateDirection);
		DAQmxStartTask(PowerDAQtask);
		GetDataFromDAQ(PowerDAQtask, 2, samps, pointdata);
		delta=GetBalanceValFromData(pointdata[1],pointdata[0]);
		DeltaSign=(delta/fabs(delta)); 
		if(DeltaSign!=DeltaSignLast) RotateDirection=-RotateDirection;
		else if(fabs(delta)>lvalue) RotateDirection=-RotateDirection;
		
		DeltaSignLast=DeltaSign;
		stepSize=stepSize/1.5;
		counter++;
		delta=fabs(delta);
		lvalue=delta;
	} while( delta>tolerance && counter<maxSteps && stepSize>0.014);	
	
	SetCtrlVal (PanelHandleMain, MAIN_PANEL_BALANCE_ERR, delta); 
	DAQmxClearTask(PowerDAQtask); 
	
	if (delta>tolerance) return -1;
	
Error:
	
	DAQmxClearTask(PowerDAQtask);
	
	return 0;
	
}



int CVICALLBACK fSplitPowerBalance (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			double tolerance;
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,&tolerance);
			tmp= SetPowerBalance(tolerance);
		
			if (tmp<0 ) MessagePopup ("Optimization Failed", "Tolerance value couldn't be met, try ajusting referance beam power level");
			else  MessagePopup ("Optical split tuning", "Done");

			
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			GUI				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK gui_function (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			switch (control)
			{
			
			case MAIN_PANEL_DAQ_SHOW_SETTINGS:
				ShowHidePanel(panel,MAIN_PANEL_DAQ_SHOW_SETTINGS, PanelHandelDAQsettings );
			break;
			
			case MAIN_PANEL_AOTF_SHOW_SETTINGS:
				ShowHidePanel(panel,MAIN_PANEL_AOTF_SHOW_SETTINGS, PanelHandelAOTFSettings );
			break;
			
			case MAIN_PANEL_MICRONIX_SHOW_SETINGS:
				ShowHidePanel(panel,MAIN_PANEL_MICRONIX_SHOW_SETINGS, PanelHandelMicronixSettings ); 
			break;
			
			case MAIN_PANEL_SCAN_SHOW_SETINGS:
				ShowHidePanel(panel,MAIN_PANEL_SCAN_SHOW_SETINGS, PanelHandeladvScanSettings ); 
			break;
			
			case MAIN_PANEL_MODUL_SHOW_SETTINGS:
				ShowHidePanel(panel,MAIN_PANEL_MODUL_SHOW_SETTINGS, PanelHandelmodulationSettings );
			break;
			
			case MAIN_PANEL_STAGES_SHOW_SETTINGS:
				ShowHidePanel(panel,MAIN_PANEL_STAGES_SHOW_SETTINGS, PanelHandelStageSettings );
			break;
			
			case MAIN_PANEL_SECONED_PLOT_OPT:
				ShowHidePanel(panel,MAIN_PANEL_SECONED_PLOT_OPT, PanelHandelGraph2 );
			break;
			
			case DAQ_SETTI_CLOSE_DAQ_SETTINGS:
				HidePanelAndChangeToggleState(PanelHandelDAQsettings, PanelHandleMain,MAIN_PANEL_DAQ_SHOW_SETTINGS, STATE_OFF); 
			break;
																		
			case AOTF_SETTI_CLOSE_AOTF_SETTINGS:
				HidePanelAndChangeToggleState(PanelHandelAOTFSettings, PanelHandleMain,MAIN_PANEL_AOTF_SHOW_SETTINGS, STATE_OFF); 
			break;
			
			case MICRONIX_S_CLOSE_MICRONIX_SET:
				HidePanelAndChangeToggleState(PanelHandelMicronixSettings, PanelHandleMain,MAIN_PANEL_MICRONIX_SHOW_SETINGS, STATE_OFF); 
			break;
			
			case MOD_SETTIN_CLOSE_PEM_SETTINGS:
				HidePanelAndChangeToggleState(PanelHandelmodulationSettings, PanelHandleMain,MAIN_PANEL_MODUL_SHOW_SETTINGS, STATE_OFF); 
			break;
			
			case ADV_SCAN_S_CLOSE_DAQ_SETTINGS:
				HidePanelAndChangeToggleState(PanelHandeladvScanSettings, PanelHandleMain,MAIN_PANEL_SCAN_SHOW_SETINGS, STATE_OFF); 
			break;
			
			case STAGE_SETT_CLOSE_STAGE_SETTINGS:
				HidePanelAndChangeToggleState(PanelHandelStageSettings, PanelHandleMain,MAIN_PANEL_STAGES_SHOW_SETTINGS, STATE_OFF); 
			break;
			}
			
		break; //case_commit
	}
	return 0;
}

int CVICALLBACK PlotChannelSelect (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			switch (control)
			{
				case MAIN_PANEL_CHANNEL_PLOT_SELECT_1:
					GetCtrlVal(PanelHandleMain,MAIN_PANEL_CHANNEL_PLOT_SELECT_1,&tmp);
				   	PlotChan=tmp;
				break;
				
				case PLOT_PANEL_CHANNEL_PLOT_SELECT_2:
					GetCtrlVal(PanelHandelGraph2,PLOT_PANEL_CHANNEL_PLOT_SELECT_2,&tmp);
				   	PlotChan2=tmp;
					break;
				
				
				case DAQ_SETTI_REF_CHANNEL:
					GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_REF_CHANNEL,&tmp);
				   	RefChan=tmp;
					break;
			}
	
	}
	return 0;
}

int CVICALLBACK ScaleXY_Graph (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int colormap,scaleFactor;
			int i,j,chan;  
			double min,max;
			double **arr;
			
	
			arr=(double**)malloc((Y_Scan_size)*sizeof(double*));
			for (i=0;i<Y_Scan_size;i++)	arr[i]=(double*)calloc(X_Scan_size,sizeof(double)); 
			
			
			GetCtrlVal(panel,MAIN_PANEL_MAX_SCALE,&max);
			GetCtrlVal(panel,MAIN_PANEL_MIN_SCALE,&min);
			GetCtrlVal(panel,MAIN_PANEL_PLOT_COLORMAP,&colormap);
		
			switch (control)
			{
				
				case MAIN_PANEL_CANVAS_RESCALE:
					max=-1000;
					min=1000;
				
					for(i=0;i<Y_Scan_size;i++)
						for(j=0;j<X_Scan_size;j++)  
						{
							if (max<GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan])) max=	GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan]);
							if (min>GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan])) min=	GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan]); 
						}
						if(max>0) max=max*1.05; 	  else max=max-(max*0.05);
						if(min>0) min=min-(min*0.05); else min=min*1.05;
					
					break;
		
					
			}
			LoadColormap( colormap,  max,  min); 
			PlotScaleBar( PanelHandleMain,  MAIN_PANEL_XY_SCAN_PLOT_SCALE_1); 
			
			//PlotScaleBar( PanelHandelGraph2,  PLOT_PANEL_XY_SCAN_PLOT_2);	
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
						arr[i][j]=GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan]);
			
			scaleFactor=GetScaleFactor();
			UpdateGraph(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, arr, X_Scan_size,  Y_Scan_size,  scaleFactor);
			
			for (i=0;i<X_Scan_size;i++)	free(arr[i]);  
			free(arr);
			
			break;
	}
	return 0;
}

void fUpdateTimeEst(void)
{
	double time,stepTime,delayTime,XstepSize,Xsize,YstepSize,Ysize;
	int numPoints;
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_X,&XstepSize); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_X_SIZE,&Xsize);
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_Y,&YstepSize); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_Y_SIZE,&Ysize);
	numPoints=(1+RoundRealToNearestInteger(Xsize/XstepSize))*(1+RoundRealToNearestInteger(Ysize/YstepSize));
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_TIME,&stepTime); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_DELAY,&delayTime);
	
	time=(stepTime/1000.0 +delayTime/1000.0 +USB_COM_DELAY)*numPoints/60/60;
	SetCtrlVal(PanelHandleMain, MAIN_PANEL_EST_SCAN_TIME,time);	
}

int CVICALLBACK UpdateScanTime (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			fUpdateTimeEst();
			break;
	}
	return 0;
}

int CVICALLBACK StepSizeChange (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			double stepSize;
			
			GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_ENABLE_UNIQUE_STEP_XY ,&tmp);
			if (!tmp)
			{
				GetCtrlVal(panel,control ,&stepSize); 
				SetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_X,stepSize);
				SetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_Y,stepSize);
			}
			fUpdateTimeEst();
			break;
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

int CVICALLBACK f_samps_chan_change (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK f_in_scan_corrections (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK ChangeMicronixIO_Out (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK fCanvasPointPress (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	
	
	switch (event)
	{
		case EVENT_LEFT_CLICK:
			int xi,yi,xi2=-1,yi2=-1,tmp,Scaling,xtmp,ytmp,boundsCHK=1;
			
			
			GetRelativeMouseState (panel, MAIN_PANEL_XY_SCAN_PLOT_1, &xi, &yi, NULL, NULL, NULL); 
			Scaling=GetScaleFactor();
			if(!Scaling) return -1;
			xtmp=xi/Scaling;
			ytmp=yi/Scaling;

			SetCtrlAttribute (panel, MAIN_PANEL_XY_SCAN_PLOT_1, ATTR_PEN_COLOR, MakeColor(255,255,255));
  			CanvasDrawPoint  (panel, MAIN_PANEL_XY_SCAN_PLOT_1, MakePoint(xi,yi));
			
			if (xtmp>=X_Scan_size)
			{
				MessagePopup ("Out of scan Area", "Chosen point X value is out of the scan area");
				boundsCHK=0;
			}
			if (ytmp>=Y_Scan_size)
			{
				MessagePopup ("Out of scan Area", "Chosen point Y value is out of the scan area");
				boundsCHK=0;
			}				
			if (XYarray && boundsCHK)
			{
				
				SetCtrlVal (panel, MAIN_PANEL_CANVAS_DATA_POINT,GetDisplayValFromData(XYarray[ytmp][xtmp].data[PlotChan],XYarray[ytmp][xtmp].data[RefChan]));
				SetCtrlVal (panel, MAIN_PANEL_PLOT1_XPOS,  1000*XYarray[ytmp][xtmp].X_Loc);
				SetCtrlVal (panel, MAIN_PANEL_PLOT1_YPOS,  1000*XYarray[ytmp][xtmp].Y_Loc);
			}

			break;
			
		case EVENT_RIGHT_CLICK: 
			
			GetRelativeMouseState (panel, MAIN_PANEL_XY_SCAN_PLOT_1, &xi, &yi, NULL, &tmp, NULL);
			Scaling=GetScaleFactor();
			if(!Scaling) return -1;
			xtmp=xi/Scaling;
			ytmp=yi/Scaling;
			while(tmp>0)
			{
				GetRelativeMouseState (panel, MAIN_PANEL_XY_SCAN_PLOT_1, &xi2, &yi2, NULL, &tmp, NULL);
			}
			SetCtrlAttribute (panel, MAIN_PANEL_XY_SCAN_PLOT_1, ATTR_PEN_COLOR, MakeColor(255,255,255));
			if (abs(xi-xi2)>abs(yi-yi2))
			{
				double *arr;
				int i,j;
				
				arr=(double*)calloc(X_Scan_size*Scaling,sizeof(double));
				for(i=0;i<X_Scan_size;i++)
					for(j=0;j<Scaling;j++)
						arr[i*Scaling+j]=XYarray[ytmp][i].data[PlotChan]; 
				
				ClearStripChart (PanelHandleMain, MAIN_PANEL_LINECHART);
				
				PlotStripChart (PanelHandleMain, MAIN_PANEL_LINECHART, arr, X_Scan_size*Scaling, 0, 0, VAL_DOUBLE);
			    free(arr);	
				CanvasDrawLine(panel,MAIN_PANEL_XY_SCAN_PLOT_1,MakePoint(xi,yi),MakePoint(xi2,yi)); 
			}
			else
			{
				double *arr;
				int i,j;
				
				arr=(double*)calloc(Y_Scan_size*Scaling,sizeof(double));
				for(i=0;i<Y_Scan_size;i++) 
					for(j=0;j<Scaling;j++) 
						arr[i*Scaling+j]=XYarray[i][xtmp].data[PlotChan]; 
				ClearStripChart (PanelHandleMain, MAIN_PANEL_LINECHART);
				PlotStripChart (PanelHandleMain, MAIN_PANEL_LINECHART, arr, Y_Scan_size*Scaling, 0, 0, VAL_DOUBLE);
			    free(arr);
				CanvasDrawLine(panel,MAIN_PANEL_XY_SCAN_PLOT_1,MakePoint(xi,yi),MakePoint(xi,yi2));
			}
	}
	return 0;
}
double GetDisplayValFromData(double valData, double valRef)
{
	int Equation;
	
	GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_EQUATION_SELECT,&Equation);
	switch (Equation)
	{
		case EQUATION_LOG:		return 	-log((valRef/valData)); 
			
		case EQUATION_FRACTION:	return 	valData/valRef;
			
		case EQUATION_NONE:		return 	valData;
		
	}
}
double GetBalanceValFromData(double Target,double ref)
{
	if (USNIG_NIRVANA_PHOTODIODE)  return Target;
	else  return  ref-Target;
}
