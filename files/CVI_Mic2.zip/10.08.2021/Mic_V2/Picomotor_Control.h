#ifndef PICOMOTOR_INCLUDE
#define PICOMOTOR_INCLUDE

#define bool unsigned char
#define BOOL unsigned char  
#define	HANDLE  int
#define DWORD   unsigned int
#include "ldcncom.h"
#include "stepper.h"
#include "servo.h"

#define PICOMOTOR_COM_PORT_NAME "COM1"
#define PICOMOTOR_BUAD_RATE 19200
#define PICOMOTOR_MOVE_UP 1
#define PICOMOTOR_MOVE_DOWN -1
#define TRANSMISSION_AXIS 1
#define 	SET_CH_A          	0x00  	
#define 	SET_CH_B          	0x01
#define		TYPE_TINY	  		0x10	
#define		TYPE_STD	  		0x00


int  InitializePicomotor(void);
void PicomotorSetAcceleration(int Acc);
void PicomotorSetSpeed(int Speed);
void PicomotorMoveRelative(int Steps);
void PicomotorMoveAbsolute(int Location);
void PicomotorMoveCont(int Direction);
long PicomotorLocationQuarry(void);
void PicomotorShutDown(void);
void PicomotorStop (void);
void PicomotorWaitTillReady(void);




#endif // ifndef PICOMOTOR_INCLUDE  
