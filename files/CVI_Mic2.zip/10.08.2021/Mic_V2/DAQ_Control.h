#ifndef MY_DAQ_INCLUDE  
#define MY_DAQ_INCLUDE       

#include <NIDAQmx.h>  
#define MAX_DAQ_AI_CHAN 6

/*---------------------------------------------------------------------------*/
/* Macros :                                                                  */
/*---------------------------------------------------------------------------*/
#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else 



typedef struct 
{
	char DevID[15];
	int  Dev_Status;
	int  Group;
	char Dev_Name[30];
	float64 maxIn;
	
}DAQtaskData;

int32 CreateDAQtask(TaskHandle *task, DAQtaskData *data , int freq , int samps, int group );
void GetDataFromDAQ(TaskHandle DAQtask, int numChans, int numPoints, double pointdata[], int chanPos) ;
double ReadDaqChan(char *daqChan);
void GetDataFromDAQ_Thorlabs_Cal(TaskHandle DAQtask, int numChans, int numPoints, double pointdata[],int chanPos ) ;          
#endif  //end Header Guard




