#include <utility.h>
#include <userint.h>
#include "MIC_V2.h"
#include "SRS830_LIA_Control.h"
#include "ansi_c.h"

//Globals

int SRS830_LIA_address;
int SRS830_LIA_device;



void SRS830_setup_LIA (int ParametersPanel)
{
	GetCtrlVal (ParametersPanel, MOD_SETTIN_SRS_GPIB_ADDRESS, &SRS830_LIA_address);
	SRS830_LIA_device = ibdev (0, SRS830_LIA_address, NO_SAD, T1s, 1, 0);
	
}


int SRS830_LIA_SendGPIB_cmd(char *cmd)
{

	ibwrt (SRS830_LIA_device, cmd, strlen(cmd)); 
	if (ibsta & 0x8000) 
	{	
		return -1;
	}
	
	return 0;
}

int SRS830_ReadGPIB(char *readbuff)
{
	ibrd (SRS830_LIA_device, readbuff, 50);
	if (ibsta & 0x8000)
	{	
		return -1;
	}
	
	return 0;
	
}


//Instrument Commands//

void SRS830_Clear_Status_Bits(void)
{
	char cmd[50]="*CLS";
	SRS830_LIA_SendGPIB_cmd(cmd);
}

int SRS830_OverloadCheck(void)
{
	char readbuff[51];
	int Overload_Status=2;
	char cmd[50]="LIAS? 1";
	int count=0;

	SRS830_LIA_SendGPIB_cmd(cmd);		
	ibrd (SRS830_LIA_device, readbuff, 50);
	sscanf(readbuff,"%d",&Overload_Status);
	while (Overload_Status>1 && count<30)
	{
		Delay(0.1);
		SRS830_LIA_SendGPIB_cmd(cmd);		
		ibrd (SRS830_LIA_device, readbuff, 50);
		sscanf(readbuff,"%d",&Overload_Status);
		count++	;
	}
	return Overload_Status;
}

void SRS830_LIA_AutoPhase(void)
{
	char cmd[50]="APHS";
	SRS830_LIA_SendGPIB_cmd(cmd);	
}
void SRS830_LIA_AutoOffset(void)
{
	char cmd[50]="AOFF3";
	SRS830_LIA_SendGPIB_cmd(cmd);
}

void SRS830_LIA_AutoSensitivity(void)
{
	char cmd[50]="AGAN";
	SRS830_LIA_SendGPIB_cmd(cmd);
	SRS830_Clear_Status_Bits(); 
}
void SRS830_LIA_Set_Sensitivity(int NewSetting)
{
	char cmd[50]="";
	sprintf(cmd,"SENS%d",NewSetting);
	SRS830_LIA_SendGPIB_cmd(cmd);	
	
}
int SRS830_LIA_Read_V_Sensitivity_Setting(void)
{
	char cmd[50]="SENS?";
	char readbuff[51];
	int senSetting1=-1,senSetting2=-2;

	while( senSetting1!=senSetting2)
	{
		SRS830_LIA_SendGPIB_cmd(cmd);
		Delay(0.05); 
		ibrd (SRS830_LIA_device, readbuff, 50);
		sscanf(readbuff,"%d",&senSetting1);
	
		SRS830_LIA_SendGPIB_cmd(cmd);
		ibrd (SRS830_LIA_device, readbuff, 50);
		sscanf(readbuff,"%d",&senSetting2);
		Delay(0.05);
	}
	
	
	return senSetting1;
}

	
double SRS830_Read_Sensitivity_Double(void)
{

	double Sen=-1;
	int senSetting;
	
	
	senSetting= SRS830_LIA_Read_V_Sensitivity_Setting();
	
	switch (senSetting)
	{
		case 0:  Sen=0.000000002; 	break;
		case 1:  Sen=0.000000005; 	break;
		case 2:  Sen=0.00000001; 	break;
		case 3:  Sen=0.00000002; 	break;
		case 4:  Sen=0.00000005; 	break;
		case 5:  Sen=0.0000001; 	break;
		case 6:  Sen=0.0000002; 	break;
		case 7:  Sen=0.0000005; 	break;
		case 8:  Sen=0.000001; 		break;
		case 9:  Sen=0.000002; 		break;
		case 10: Sen=0.000005; 		break;
		case 11: Sen=0.00001; 		break;
		case 12: Sen=0.00002; 		break;
		case 13: Sen=0.00005; 		break;
		case 14: Sen=0.0001; 		break;
		case 15: Sen=0.0002; 		break;
		case 16: Sen=0.0005; 		break;
		case 17: Sen=0.001; 		break;
		case 18: Sen=0.002; 		break;
		case 19: Sen=0.005; 		break;
		case 20: Sen=0.01; 			break;
		case 21: Sen=0.02; 			break;
		case 22: Sen=0.05; 			break;
		case 23: Sen=0.1; 			break;
		case 24: Sen=0.2; 			break;
		case 25: Sen=0.5; 			break;
		case 26: Sen=1; 			break;
	}
	return Sen;
}
void SRS830_Change_SensitivityBy(int SettingNumChange)
{
	int curSetting;
	
	curSetting=SRS830_LIA_Read_V_Sensitivity_Setting();
	
	while(abs(SettingNumChange)>=1)
	{
		if((curSetting+SettingNumChange>=0) && (curSetting+SettingNumChange<=26)) 
		{
			SRS830_LIA_Set_Sensitivity(curSetting+SettingNumChange);		
			break;
		}
		else
		{
			if(SettingNumChange>0) SettingNumChange--;	
			else				   SettingNumChange++;
		}
	}	
	
	
}
