/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  ADV_SCAN_S                       1
#define  ADV_SCAN_S_DECORATION_6          2       /* control type: deco, callback function: (none) */
#define  ADV_SCAN_S_SAMPLE_TILT_CORR      3       /* control type: radioButton, callback function: (none) */
#define  ADV_SCAN_S_FOCUS_DRIFT_CORR      4       /* control type: radioButton, callback function: (none) */
#define  ADV_SCAN_S_DRIFT_CORRECT_POS_Y   5       /* control type: string, callback function: (none) */
#define  ADV_SCAN_S_DRIFT_CORRECT_POS_X   6       /* control type: string, callback function: (none) */
#define  ADV_SCAN_S_DRIFT_CORR_SET_LOC    7       /* control type: command, callback function: f_in_scan_corrections */
#define  ADV_SCAN_S_CD_CAL_TEST           8       /* control type: command, callback function: TEST_RETARDANCE */
#define  ADV_SCAN_S_DAQ_MIN_CHAN          9       /* control type: string, callback function: (none) */
#define  ADV_SCAN_S_CMD_Test_Ret_2        10      /* control type: command, callback function: TEST_RETARDANCE */
#define  ADV_SCAN_S_CMD_Test_Ret          11      /* control type: command, callback function: TEST_RETARDANCE */
#define  ADV_SCAN_S_TILT_CORR_LR          12      /* control type: command, callback function: f_in_scan_corrections */
#define  ADV_SCAN_S_TILT_CORR_CLEAR_LOC   13      /* control type: command, callback function: f_in_scan_corrections */
#define  ADV_SCAN_S_TILT_CORR_UR          14      /* control type: command, callback function: f_in_scan_corrections */
#define  ADV_SCAN_S_TILT_CORR_LL          15      /* control type: command, callback function: f_in_scan_corrections */
#define  ADV_SCAN_S_TILT_CORR_UL          16      /* control type: command, callback function: f_in_scan_corrections */
#define  ADV_SCAN_S_FOCUS_DRIFT_LINE_FREQ 17      /* control type: numeric, callback function: (none) */
#define  ADV_SCAN_S_CLOSE_DAQ_SETTINGS    18      /* control type: command, callback function: gui_function_scansettings */
#define  ADV_SCAN_S_ENABLE_UNIQUE_STEP_XY 19      /* control type: slide, callback function: (none) */
#define  ADV_SCAN_S_SCAN_TYPE             20      /* control type: ring, callback function: (none) */
#define  ADV_SCAN_S_MANUAL_ADJUST_AT_NEW  21      /* control type: textButton, callback function: f_change_spec_pause_state */
#define  ADV_SCAN_S_START_SPECTRAL_SCAN_B 22      /* control type: textButton, callback function: f_simple_spc */
#define  ADV_SCAN_S_START_SPECTRAL_SCAN   23      /* control type: textButton, callback function: f_simple_spc */
#define  ADV_SCAN_S_LIMIT_EXPOSURE        24      /* control type: radioButton, callback function: (none) */
#define  ADV_SCAN_S_EXP_DELAY             25      /* control type: numeric, callback function: (none) */
#define  ADV_SCAN_S_POL_V_2               26      /* control type: numeric, callback function: (none) */
#define  ADV_SCAN_S_POL_V_1               27      /* control type: numeric, callback function: (none) */
#define  ADV_SCAN_S_LCRV_METHUD_SWITCH    28      /* control type: binary, callback function: fnc_change_method */
#define  ADV_SCAN_S_OPTIMIZE_LOC          29      /* control type: binary, callback function: (none) */

#define  AOTF_SETTI                       2
#define  AOTF_SETTI_NIR2_AOTF_ID          2       /* control type: numeric, callback function: Change_AOTF_Dev_IDs */
#define  AOTF_SETTI_NIR_AOTF_ID           3       /* control type: numeric, callback function: Change_AOTF_Dev_IDs */
#define  AOTF_SETTI_VIS_AOTF_ID           4       /* control type: numeric, callback function: Change_AOTF_Dev_IDs */
#define  AOTF_SETTI_AOTF_CMD_TEXT         5       /* control type: string, callback function: (none) */
#define  AOTF_SETTI_DECORATION            6       /* control type: deco, callback function: (none) */
#define  AOTF_SETTI_AOTF_DEVICE_ID        7       /* control type: ring, callback function: (none) */
#define  AOTF_SETTI_AOTF_SEND             8       /* control type: command, callback function: AOTFSendString */
#define  AOTF_SETTI_DECORATION_2          9       /* control type: deco, callback function: (none) */
#define  AOTF_SETTI_NIR_AOTF_Wave_CH5     10      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_NIR_STATE_CHAN5       11      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_NIR_AOTF_Wave_CH3     12      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_6             13      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_NIR_STATE_CHAN4       14      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_SET_PWR_LIMIT_4       15      /* control type: radioButton, callback function: (none) */
#define  AOTF_SETTI_SET_PWR_LIMIT_3       16      /* control type: radioButton, callback function: (none) */
#define  AOTF_SETTI_SET_PWR_LIMIT_2       17      /* control type: radioButton, callback function: (none) */
#define  AOTF_SETTI_SET_PWR_LIMIT_1       18      /* control type: radioButton, callback function: (none) */
#define  AOTF_SETTI_NIR_AOTF_Wave_CH4     19      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_7             20      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_NIR_STATE_CHAN3       21      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_NIR_AOTF_POWER_CH5    22      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_NIR_AOTF_POWER_CH4    23      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_8             24      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_TEXTMSG_9             25      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_NIR_STATE_CHAN2       26      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_NIR_AOTF_Wave_CH2     27      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_10            28      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_DECORATION_4          29      /* control type: deco, callback function: (none) */
#define  AOTF_SETTI_NIR_AOTF_POWER_CH3    30      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_NIR_AOTF_POWER_CH2    31      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_Wave_CH7     32      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_STATE_CHAN7       33      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_Wave_CH6     34      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_STATE_CHAN6       35      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_Wave_CH5     36      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_STATE_CHAN5       37      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_12            38      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_VIS_AOTF_Wave_CH3     39      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_POWER_CH7    40      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_4             41      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_TEXTMSG_11            42      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_VIS_STATE_CHAN4       43      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_POWER_CH6    44      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_Wave_CH4     45      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG_5             46      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_VIS_STATE_CHAN3       47      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_POWER_CH5    48      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_VIS_AOTF_POWER_CH4    49      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_TEXTMSG               50      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_TEXTMSG_2             51      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_VIS_STATE_CHAN2       52      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_W_LIMIT_4             53      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_W_LIMIT_3             54      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_W_LIMIT_2             55      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_W_LIMIT_1             56      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_VIS_AOTF_Wave_CH2     57      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_W_LIMITPOWER_4        58      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_TEXTMSG_3             59      /* control type: textMsg, callback function: (none) */
#define  AOTF_SETTI_W_LIMITPOWER_3        60      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_DECORATION_3          61      /* control type: deco, callback function: (none) */
#define  AOTF_SETTI_W_LIMITPOWER_2        62      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_VIS_AOTF_POWER_CH3    63      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_W_LIMITPOWER_1        64      /* control type: numeric, callback function: (none) */
#define  AOTF_SETTI_VIS_AOTF_POWER_CH2    65      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  AOTF_SETTI_CLOSE_AOTF_SETTINGS   66      /* control type: command, callback function: gui_function_AOTF */

#define  DAQ_SETTI                        3
#define  DAQ_SETTI_DAQ_TRIGGER            2       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_5              3       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_4              4       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_3              5       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_2              6       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_1              7       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_DAQ_BALANCE_CHAN       8       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_DAQ_AF_TRANSMISSION    9       /* control type: string, callback function: (none) */
#define  DAQ_SETTI_DAQ_AF_CHANNEL         10      /* control type: string, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_0              11      /* control type: string, callback function: (none) */
#define  DAQ_SETTI_DAQ_AI_AVEREGING_G2    12      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_DAQ_AI_AVEREGING_G1    13      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_AI_SAMPLE_RATE_GROUP2  14      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_AI_SAMPLE_RATE_GROUP1  15      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_DECORATION_4           16      /* control type: deco, callback function: (none) */
#define  DAQ_SETTI_DECORATION_3           17      /* control type: deco, callback function: (none) */
#define  DAQ_SETTI_TEXTMSG_4              18      /* control type: textMsg, callback function: (none) */
#define  DAQ_SETTI_TEXTMSG                19      /* control type: textMsg, callback function: (none) */
#define  DAQ_SETTI_TEXTMSG_3              20      /* control type: textMsg, callback function: (none) */
#define  DAQ_SETTI_TEXTMSG_2              21      /* control type: textMsg, callback function: (none) */
#define  DAQ_SETTI_TRIGGER_EDGE           22      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_RANGE_5        23      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_SOURCE_CH_1            24      /* control type: ring, callback function: fChange_LIA_R_Chan */
#define  DAQ_SETTI_SOURCE_CH_5            25      /* control type: ring, callback function: fChange_LIA_R_Chan */
#define  DAQ_SETTI_SOURCE_CH_4            26      /* control type: ring, callback function: fChange_LIA_R_Chan */
#define  DAQ_SETTI_SOURCE_CH_3            27      /* control type: ring, callback function: fChange_LIA_R_Chan */
#define  DAQ_SETTI_SOURCE_CH_2            28      /* control type: ring, callback function: fChange_LIA_R_Chan */
#define  DAQ_SETTI_SOURCE_CH_0            29      /* control type: ring, callback function: fChange_LIA_R_Chan */
#define  DAQ_SETTI_AF_METHOD              30      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_RANGE_4        31      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_RANGE_3        32      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_ACTIVE_5       33      /* control type: textButton, callback function: DAQ_stateChange */
#define  DAQ_SETTI_CLOSE_DAQ_SETTINGS     34      /* control type: command, callback function: gui_function_daq */
#define  DAQ_SETTI_AI_CHAN_RANGE_2        35      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_ACTIVE_4       36      /* control type: textButton, callback function: DAQ_stateChange */
#define  DAQ_SETTI_AI_CHAN_RANGE_0        37      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_RANGE_1        38      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_AI_CHAN_ACTIVE_3       39      /* control type: textButton, callback function: DAQ_stateChange */
#define  DAQ_SETTI_DAQ_GROUP_CH5          40      /* control type: numeric, callback function: DAQ_stateChange */
#define  DAQ_SETTI_AI_CHAN_ACTIVE_2       41      /* control type: textButton, callback function: DAQ_stateChange */
#define  DAQ_SETTI_AI_CHAN_ACTIVE_0       42      /* control type: textButton, callback function: DAQ_stateChange */
#define  DAQ_SETTI_AI_CHAN_ACTIVE_1       43      /* control type: textButton, callback function: DAQ_stateChange */
#define  DAQ_SETTI_DAQ_GROUP_CH4          44      /* control type: numeric, callback function: DAQ_stateChange */
#define  DAQ_SETTI_DAQ_GROUP_CH3          45      /* control type: numeric, callback function: DAQ_stateChange */
#define  DAQ_SETTI_DAQ_GROUP_CH2          46      /* control type: numeric, callback function: DAQ_stateChange */
#define  DAQ_SETTI_DAQ_GROUP_CH1          47      /* control type: numeric, callback function: DAQ_stateChange */
#define  DAQ_SETTI_DAQ_GROUP_CH0          48      /* control type: numeric, callback function: DAQ_stateChange */
#define  DAQ_SETTI_PARTICLE_SEARCH_CHAN   49      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_REF_CHANNEL            50      /* control type: numeric, callback function: PlotChannelSelect */
#define  DAQ_SETTI_TEXTMSG_5              51      /* control type: textMsg, callback function: (none) */
#define  DAQ_SETTI_DECORATION             52      /* control type: deco, callback function: (none) */
#define  DAQ_SETTI_EQUATION_SELECT        53      /* control type: ring, callback function: (none) */
#define  DAQ_SETTI_LOAD_SETTINGS          54      /* control type: command, callback function: DaqSettingsSaveLoad */
#define  DAQ_SETTI_SAVE_SETTINGS          55      /* control type: command, callback function: DaqSettingsSaveLoad */
#define  DAQ_SETTI_SETTINGS_INDEX         56      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_SETTINGS_INFO          57      /* control type: string, callback function: (none) */
#define  DAQ_SETTI_DETECTORE_TOGGLE       58      /* control type: binary, callback function: gui_function */
#define  DAQ_SETTI_LIA_SIM_CYCLS          59      /* control type: numeric, callback function: (none) */
#define  DAQ_SETTI_DECORATION_2           60      /* control type: deco, callback function: (none) */

#define  MAIN_PANEL                       4
#define  MAIN_PANEL_STEP_DELAY            2       /* control type: numeric, callback function: UpdateScanTime */
#define  MAIN_PANEL_SEARCH_TYPE_MAX_MIN   3       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_BALANCE_ERR           4       /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MIN_WAVE_4            5       /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_RESULOTION_WAVE_4     6       /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MAX_WAVE_4            7       /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_AF_ON_SCAN            8       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_MIN_WAVE_3            9       /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_RESULOTION_WAVE_3     10      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MAX_WAVE_3            11      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MIN_WAVE_2            12      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_RESULOTION_WAVE_2     13      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MAX_WAVE_2            14      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_SET_VOLTAGE_LIMIT     15      /* control type: radioButton, callback function: (none) */
#define  MAIN_PANEL_SPLIT_PWR_STEP_ADJ    16      /* control type: radioButton, callback function: (none) */
#define  MAIN_PANEL_MIN_WAVE_1            17      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_SPC_BAGROUND_LOCATION 18      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_RESULOTION_WAVE_1     19      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MAX_WAVE_1            20      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_STEP_TIME             21      /* control type: numeric, callback function: UpdateScanTime */
#define  MAIN_PANEL_STEP_SIZE_Y           22      /* control type: numeric, callback function: StepSizeChange */
#define  MAIN_PANEL_STEP_SIZE_X           23      /* control type: numeric, callback function: StepSizeChange */
#define  MAIN_PANEL_Y_SIZE                24      /* control type: numeric, callback function: UpdateScanTime */
#define  MAIN_PANEL_X_SIZE                25      /* control type: numeric, callback function: UpdateScanTime */
#define  MAIN_PANEL_STOP_SCAN             26      /* control type: command, callback function: f_scan_emr_stop */
#define  MAIN_PANEL_STORELOC_Z_MOVE       27      /* control type: radioButton, callback function: (none) */
#define  MAIN_PANEL_MICRONIX_CUR_Y_POS    28      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MICRONIX_CUR_X_POS    29      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_XYZ_STOP              30      /* control type: command, callback function: fnc_xyz_stop */
#define  MAIN_PANEL_SCAN_STDEV            31      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_MIN_SCALE             32      /* control type: scale, callback function: ScaleXY_Graph */
#define  MAIN_PANEL_MAX_SCALE             33      /* control type: scale, callback function: ScaleXY_Graph */
#define  MAIN_PANEL_EST_SCAN_TIME         34      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_DECORATION_12         35      /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_CANVAS_RESCALE        36      /* control type: command, callback function: AutoScaleXY_Graph */
#define  MAIN_PANEL_CENTER_ON_SPOT        37      /* control type: command, callback function: fCenterOnSpot */
#define  MAIN_PANEL_DECORATION_11         38      /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_11            39      /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_PLOT1_YPOS            40      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_CANVAS_DATA_POINT     41      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_STORED_LOC_BG5        42      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_SET_MIN_VOLTAGE       43      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_SET_MAX_VOLTAGE       44      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_BALANCE_TOLERANCE     45      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_AUTO_SET_H_LAMBDA     46      /* control type: command, callback function: fSplitPowerBalance */
#define  MAIN_PANEL_PLOT1_XPOS            47      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_STORED_LOC_BG4        48      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_BG3        49      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_BG2        50      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_CLEAR      51      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_5          52      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_BG1        53      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_4          54      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_3          55      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_STORED_LOC_2          56      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_Z_INCREMENT           57      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_SCAN_DIRECTION        58      /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_STORED_LOC_1          59      /* control type: command, callback function: fStoredLocEvent */
#define  MAIN_PANEL_Z_STOP                60      /* control type: command, callback function: fnc_z_stop */
#define  MAIN_PANEL_Z_Plus                61      /* control type: pictButton, callback function: fMpveContinus */
#define  MAIN_PANEL_Z_MINUS               62      /* control type: pictButton, callback function: fMpveContinus */
#define  MAIN_PANEL_SC_POWER_OUT          63      /* control type: scale, callback function: power_update */
#define  MAIN_PANEL_Fu_POWER_OUT          64      /* control type: scale, callback function: power_update */
#define  MAIN_PANEL_FOLDER_NAME           65      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_XY_INCREMENT          66      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_FILE_NAME             67      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_indPI_POS             68      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_indMICRONIXZPOS       69      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_indMICRONIX_Y_POS     70      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_indMICRONIX_X_POS     71      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_PI_UP_JOG             72      /* control type: pictButton, callback function: fMove_pi */
#define  MAIN_PANEL_UP_CONT               73      /* control type: pictButton, callback function: fMpveContinus */
#define  MAIN_PANEL_LEFT_CONT             74      /* control type: pictButton, callback function: fMpveContinus */
#define  MAIN_PANEL_PI_DOWN_JOG           75      /* control type: pictButton, callback function: fMove_pi */
#define  MAIN_PANEL_SET_POL_STATE_1       76      /* control type: pictButton, callback function: Set_Pol_State */
#define  MAIN_PANEL_SET_POL_STATE_2       77      /* control type: pictButton, callback function: Set_Pol_State */
#define  MAIN_PANEL_RIGHT_CONT            78      /* control type: pictButton, callback function: fMpveContinus */
#define  MAIN_PANEL_DOWN_CONT             79      /* control type: pictButton, callback function: fMpveContinus */
#define  MAIN_PANEL_SCAN_NUMBER           80      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_AUTOFOCUS_BUTTON      81      /* control type: command, callback function: AutoFocusButton */
#define  MAIN_PANEL_FOLDER_BROWSE         82      /* control type: command, callback function: scan_folder_browse */
#define  MAIN_PANEL_Decoration            83      /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_LOAD_IMAGE            84      /* control type: command, callback function: fLoadImage */
#define  MAIN_PANEL_SAVE_IMAGE            85      /* control type: command, callback function: fSaveImage */
#define  MAIN_PANEL_VIS_AOTF_Wave_CH1     86      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_NIR2_AOTF_Wave_CH0    87      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_NIR2_AOTF_POWER_CH0   88      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_TEXTMSG_7             89      /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_NIR2_STATE_CHAN0      90      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_VIS_AOTF_Wave_CH0     91      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_TEXTMSG_9             92      /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_DECORATION_5          93      /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_VIS_AOTF_POWER_CH0    94      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_NIR_AOTF_POWER_CH1    95      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_VIS_STATE_CHAN1       96      /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_TEXTMSG               97      /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_NIR_AOTF_Wave_CH1     98      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_NIR_AOTF_Wave_CH0     99      /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_NIR_AOTF_POWER_CH0    100     /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_NIR_STATE_CHAN1       101     /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_TEXTMSG_5             102     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_NIR_STATE_CHAN0       103     /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_TEXTMSG_6             104     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_2             105     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_DECORATION_4          106     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_VIS_STATE_CHAN0       107     /* control type: toggle, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_TEXTMSG_4             108     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_3             109     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_DECORATION_3          110     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_VIS_AOTF_POWER_CH1    111     /* control type: numeric, callback function: f_AOTF_UPDATE */
#define  MAIN_PANEL_DAQ_SHOW_SETTINGS     112     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_OPEN_STANDA_PNL       113     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_STAGES_SHOW_SETTINGS  114     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_MODUL_SHOW_SETTINGS   115     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_SCAN_SHOW_SETINGS     116     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_MICRONIX_SHOW_SETINGS 117     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_AOTF_SHOW_SETTINGS    118     /* control type: textButton, callback function: gui_function */
#define  MAIN_PANEL_DECORATION_2          119     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_DECORATION_6          120     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_SPLITTER_7            121     /* control type: splitter, callback function: (none) */
#define  MAIN_PANEL_SPLITTER              122     /* control type: splitter, callback function: (none) */
#define  MAIN_PANEL_DECORATION_8          123     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_SECONED_PLOT_OPT      124     /* control type: binary, callback function: gui_function */
#define  MAIN_PANEL_TRANSMISSION_CHK      125     /* control type: binary, callback function: fTransmissionState */
#define  MAIN_PANEL_SAVE_MOVE_CHK         126     /* control type: binary, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_10            127     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_DECORATION_10         128     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_AOTF_WAVE_4           129     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_PLOT_COLORMAP         130     /* control type: slide, callback function: ChangeColorMap */
#define  MAIN_PANEL_CHANNEL_PLOT_SELECT_1 131     /* control type: slide, callback function: PlotChannelSelect */
#define  MAIN_PANEL_DECORATION_9          132     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_WAVELENGTH_INDICATOR  133     /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_AOTF_WAVE_3           134     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_START_SPECTRAL_SCAN   135     /* control type: textButton, callback function: f_start_spectral */
#define  MAIN_PANEL_CD_START              136     /* control type: textButton, callback function: f_start_cd_scan */
#define  MAIN_PANEL_START_SCAN            137     /* control type: textButton, callback function: f_start_scan */
#define  MAIN_PANEL_AOTF_INDICATOR        138     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_13            139     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_AOTF_WAVE_2           140     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_8             141     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_14            142     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_POL_2                 143     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_POL_1                 144     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_AOTF_WAVE_1           145     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_SPLITTER_4            146     /* control type: splitter, callback function: (none) */
#define  MAIN_PANEL_SPLITTER_3            147     /* control type: splitter, callback function: (none) */
#define  MAIN_PANEL_SPLITTER_2            148     /* control type: splitter, callback function: (none) */
#define  MAIN_PANEL_SPLITTER_6            149     /* control type: splitter, callback function: (none) */
#define  MAIN_PANEL_TRANSLATION_LED       150     /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_DAQ_LED               151     /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_AOTF_LED              152     /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_PI_LED                153     /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_FIANIUM_LED           154     /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_MICRONIX_LED          155     /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_DECORATION_13         156     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_QUITBUTTON            157     /* control type: command, callback function: QuitCallback */
#define  MAIN_PANEL_TEXTMSG_16            158     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_18            159     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_17            160     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_LINECHART             161     /* control type: strip, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_19            162     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_20            163     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_XY_SCAN_PLOT_1        164     /* control type: canvas, callback function: fCanvasPointPress */
#define  MAIN_PANEL_XY_SCAN_PLOT_SCALE_1  165     /* control type: canvas, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_22            166     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_21            167     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_23            168     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_AF_STEP_SIZE          169     /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_DECORATION_7          170     /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG_15            171     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_PI_STEP_SIZE          172     /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_SET_BACKGROUND_VAL    173     /* control type: command, callback function: SetBackgroundValue */
#define  MAIN_PANEL_TEXTMSG_12            174     /* control type: textMsg, callback function: (none) */
#define  MAIN_PANEL_ENABLE_USER_CONTROL   175     /* control type: binary, callback function: (none) */
#define  MAIN_PANEL_ALTR_SCAN_SET         176     /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_PI_POS_CHK            177     /* control type: radioButton, callback function: (none) */
#define  MAIN_PANEL_CD_CYCLES             178     /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_PARTICLE_TRACKING     179     /* control type: textButton, callback function: fTrackParticle */

#define  MICRONIX_S                       5
#define  MICRONIX_S_Z_AXIS_ID             2       /* control type: numeric, callback function: ChangeMotorIDs */
#define  MICRONIX_S_Y_AXIS_ID             3       /* control type: numeric, callback function: ChangeMotorIDs */
#define  MICRONIX_S_X_AXIS_ID             4       /* control type: numeric, callback function: ChangeMotorIDs */
#define  MICRONIX_S_CLOSE_MICRONIX_SET    5       /* control type: command, callback function: gui_function_Micronix */
#define  MICRONIX_S_XY_HOME               6       /* control type: command, callback function: fnc_XY_home */
#define  MICRONIX_S_DECORATION            7       /* control type: deco, callback function: (none) */
#define  MICRONIX_S_MICRONIX_ON_OFF       8       /* control type: binary, callback function: MicronixPowerOnOff */
#define  MICRONIX_S_MICRONIX_ERR_MSG      9       /* control type: textBox, callback function: (none) */
#define  MICRONIX_S_Z_SPEED               10      /* control type: numeric, callback function: fnc_MicronixSpeed */
#define  MICRONIX_S_MICRONIX_CMD_TEXT     11      /* control type: string, callback function: (none) */
#define  MICRONIX_S_XY_ACCELERATION       12      /* control type: numeric, callback function: fnc_MicronixAcceleration */
#define  MICRONIX_S_DECORATION_3          13      /* control type: deco, callback function: (none) */
#define  MICRONIX_S_DECORATION_2          14      /* control type: deco, callback function: (none) */
#define  MICRONIX_S_XY_SPEED              15      /* control type: numeric, callback function: fnc_MicronixSpeed */
#define  MICRONIX_S_MICRONIX_SEND         16      /* control type: command, callback function: MicronixSendString */
#define  MICRONIX_S_Image                 17      /* control type: picture, callback function: f_Focus_Swing */
#define  MICRONIX_S_Z_POS_TIMER           18      /* control type: timer, callback function: fZPOS_CHK */
#define  MICRONIX_S_MICRONIX_PID_I        19      /* control type: numeric, callback function: fnc_MicronixPID_SET */
#define  MICRONIX_S_MICRONIX_PID_P        20      /* control type: numeric, callback function: fnc_MicronixPID_SET */
#define  MICRONIX_S_TEXTMSG_3             21      /* control type: textMsg, callback function: (none) */
#define  MICRONIX_S_CHAN_3_IO1            22      /* control type: ring, callback function: ChangeMicronixIO_Out */
#define  MICRONIX_S_CHAN_1_IO1            23      /* control type: ring, callback function: ChangeMicronixIO_Out */
#define  MICRONIX_S_CLEAR_ERRORS          24      /* control type: command, callback function: ClearErrorMsgBox */
#define  MICRONIX_S_CHAN_2_IO1            25      /* control type: ring, callback function: ChangeMicronixIO_Out */
#define  MICRONIX_S_MYTEST                26      /* control type: command, callback function: f_Focus_Swing */
#define  MICRONIX_S_NUMERIC               27      /* control type: numeric, callback function: (none) */

#define  MOD_SETTIN                       6
#define  MOD_SETTIN_PEM_ON_OFF            2       /* control type: binary, callback function: fPEM_Control */
#define  MOD_SETTIN_PEM_RETARDANCE        3       /* control type: slide, callback function: fPEM_Control */
#define  MOD_SETTIN_CLOSE_PEM_SETTINGS    4       /* control type: command, callback function: gui_function_mod */
#define  MOD_SETTIN_SRS_GPIB_ADDRESS      5       /* control type: numeric, callback function: Change_SRS830_LIA_GPIB_address */
#define  MOD_SETTIN_SRS830_LIA_SEND_TEXT  6       /* control type: command, callback function: LIA_cmds */
#define  MOD_SETTIN_SRS830LIA_AUTO_OFFSET 7       /* control type: command, callback function: LIA_cmds */
#define  MOD_SETTIN_SRS830_LIA_AUTO_PHASE 8       /* control type: command, callback function: LIA_cmds */
#define  MOD_SETTIN_SRS830_LIA_TEXT_CMD   9       /* control type: string, callback function: (none) */
#define  MOD_SETTIN_SRS_R_CHAN            10      /* control type: string, callback function: (none) */
#define  MOD_SETTIN_EGNG_R_CHAN           11      /* control type: string, callback function: (none) */
#define  MOD_SETTIN_LIA_GPIB_ADDRESS      12      /* control type: numeric, callback function: Change_LIA_GPIB_address */
#define  MOD_SETTIN_DECORATION_3          13      /* control type: deco, callback function: (none) */
#define  MOD_SETTIN_LIA_SEND_TEXT         14      /* control type: command, callback function: LIA_cmds */
#define  MOD_SETTIN_LIA_AUTO_OFFSET       15      /* control type: command, callback function: LIA_cmds */
#define  MOD_SETTIN_LIA_AUTO_PHASE        16      /* control type: command, callback function: LIA_cmds */
#define  MOD_SETTIN_LIA_TEXT_CMD          17      /* control type: string, callback function: (none) */
#define  MOD_SETTIN_DECORATION            18      /* control type: deco, callback function: (none) */
#define  MOD_SETTIN_DECORATION_2          19      /* control type: deco, callback function: (none) */

#define  PLOT_PANEL                       7
#define  PLOT_PANEL_CHANNEL_PLOT_SELECT_2 2       /* control type: slide, callback function: PlotChannelSelect */
#define  PLOT_PANEL_XY_SCAN_PLOT_2        3       /* control type: canvas, callback function: gui_function */
#define  PLOT_PANEL_XY_SCAN_PLOT_SCALE_2  4       /* control type: canvas, callback function: (none) */
#define  PLOT_PANEL_MIN_SCALE             5       /* control type: scale, callback function: ScaleXY_Graph2 */
#define  PLOT_PANEL_MAX_SCALE             6       /* control type: scale, callback function: ScaleXY_Graph2 */
#define  PLOT_PANEL_EQUATION_SELECT       7       /* control type: ring, callback function: (none) */
#define  PLOT_PANEL_TEXTMSG_5             8       /* control type: textMsg, callback function: (none) */

#define  SPEC_PANEL                       8       /* callback function: spec_char_cb */
#define  SPEC_PANEL_SPECTRAL_CHART        2       /* control type: graph, callback function: (none) */
#define  SPEC_PANEL_CLOSE_GRAPH           3       /* control type: command, callback function: gui_function */
#define  SPEC_PANEL_SPLITTER_2            4       /* control type: splitter, callback function: (none) */
#define  SPEC_PANEL_SPLITTER              5       /* control type: splitter, callback function: (none) */
#define  SPEC_PANEL_TEXTMSG               6       /* control type: textMsg, callback function: (none) */
#define  SPEC_PANEL_PIXEL_GRAPH           7       /* control type: command, callback function: fCreateGrapthForPixel */
#define  SPEC_PANEL_PLOT_CH_5             8       /* control type: radioButton, callback function: (none) */
#define  SPEC_PANEL_PLOT_CH_4             9       /* control type: radioButton, callback function: (none) */
#define  SPEC_PANEL_PLOT_CH_3             10      /* control type: radioButton, callback function: (none) */
#define  SPEC_PANEL_PLOT_CH_2             11      /* control type: radioButton, callback function: (none) */
#define  SPEC_PANEL_PLOT_CH_0             12      /* control type: radioButton, callback function: (none) */
#define  SPEC_PANEL_PLOT_CH_1             13      /* control type: radioButton, callback function: (none) */
#define  SPEC_PANEL_TEXTMSG_2             14      /* control type: textMsg, callback function: (none) */

#define  STAGE_SETT                       9
#define  STAGE_SETT_MG17MOTOR             2       /* control type: activeX, callback function: (none) */
#define  STAGE_SETT_CLOSE_STAGE_SETTINGS  3       /* control type: command, callback function: gui_function_stage */
#define  STAGE_SETT_TEXTMSG               4       /* control type: textMsg, callback function: (none) */
#define  STAGE_SETT_TEXTMSG_2             5       /* control type: textMsg, callback function: (none) */
#define  STAGE_SETT_DLINE_SPEED           6       /* control type: numeric, callback function: (none) */
#define  STAGE_SETT_STEP_SIZE             7       /* control type: ring, callback function: (none) */

#define  STNDA_PNL                        10
#define  STNDA_PNL_STEP_SIZE              2       /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_COMMANDBUTTON_2        3       /* control type: command, callback function: Minus_Step */
#define  STNDA_PNL_COMMANDBUTTON          4       /* control type: command, callback function: Plus_Step */
#define  STNDA_PNL_STANDA_DELAY           5       /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_STANDA_DISTANCE        6       /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_POSITION               7       /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_STRING_4               8       /* control type: string, callback function: (none) */
#define  STNDA_PNL_STRING_3               9       /* control type: string, callback function: (none) */
#define  STNDA_PNL_STRING_2               10      /* control type: string, callback function: (none) */
#define  STNDA_PNL_STRING                 11      /* control type: string, callback function: (none) */
#define  STNDA_PNL_Moving_LED             12      /* control type: LED, callback function: (none) */
#define  STNDA_PNL_DECORATION             13      /* control type: deco, callback function: (none) */
#define  STNDA_PNL_DECORATION_3           14      /* control type: deco, callback function: (none) */
#define  STNDA_PNL_STANDA_OFFSET          15      /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_PROBE_WAVELENGTH       16      /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_DIRECTION_SWITCH       17      /* control type: binary, callback function: (none) */
#define  STNDA_PNL_SCAN_SWITCH            18      /* control type: binary, callback function: (none) */
#define  STNDA_PNL_PB_PUMB_CB             19      /* control type: radioButton, callback function: (none) */
#define  STNDA_PNL_TRACK_SET              20      /* control type: binary, callback function: (none) */
#define  STNDA_PNL_DECORATION_4           21      /* control type: deco, callback function: (none) */
#define  STNDA_PNL_STEP_COUNTS            22      /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_NUM_OF_SCANS           23      /* control type: numeric, callback function: (none) */
#define  STNDA_PNL_DECORATION_5           24      /* control type: deco, callback function: (none) */
#define  STNDA_PNL_STEPS_UNITS_SWITCH     25      /* control type: binary, callback function: (none) */
#define  STNDA_PNL_RINGSLIDE_2            26      /* control type: slide, callback function: (none) */
#define  STNDA_PNL_RINGSLIDE              27      /* control type: slide, callback function: (none) */
#define  STNDA_PNL_DECORATION_2           28      /* control type: deco, callback function: (none) */

#define  USER_PROM                        11
#define  USER_PROM_TEXTMSG                2       /* control type: textMsg, callback function: (none) */
#define  USER_PROM_POPUP_TIMER_COUNT      3       /* control type: timer, callback function: CounterTick */
#define  USER_PROM_POPUP_TIMER            4       /* control type: timer, callback function: SimulateUserClick */
#define  USER_PROM_COMMANDBUTTON          5       /* control type: command, callback function: SimulateUserClick */
#define  USER_PROM_COUNTDOWN              6       /* control type: numeric, callback function: (none) */
#define  USER_PROM_TEXTMSG_2              7       /* control type: textMsg, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK AOTFSendString(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK AutoFocusButton(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK AutoScaleXY_Graph(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Change_AOTF_Dev_IDs(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Change_LIA_GPIB_address(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Change_SRS830_LIA_GPIB_address(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeColorMap(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeMicronixIO_Out(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ChangeMotorIDs(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ClearErrorMsgBox(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CounterTick(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DAQ_stateChange(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DaqSettingsSaveLoad(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_AOTF_UPDATE(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_change_spec_pause_state(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_Focus_Swing(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_in_scan_corrections(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_scan_emr_stop(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_simple_spc(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_start_cd_scan(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_start_scan(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK f_start_spectral(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fCanvasPointPress(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fCenterOnSpot(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fChange_LIA_R_Chan(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fCreateGrapthForPixel(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fLoadImage(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fMove_pi(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fMpveContinus(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_change_method(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_MicronixAcceleration(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_MicronixPID_SET(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_MicronixSpeed(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_XY_home(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_xyz_stop(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fnc_z_stop(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fPEM_Control(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fSaveImage(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fSplitPowerBalance(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fStoredLocEvent(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fTrackParticle(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fTransmissionState(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK fZPOS_CHK(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function_AOTF(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function_daq(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function_Micronix(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function_mod(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function_scansettings(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK gui_function_stage(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK LIA_cmds(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK MicronixPowerOnOff(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK MicronixSendString(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Minus_Step(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PlotChannelSelect(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Plus_Step(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK power_update(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK QuitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ScaleXY_Graph(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ScaleXY_Graph2(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK scan_folder_browse(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Set_Pol_State(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetBackgroundValue(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SimulateUserClick(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK spec_char_cb(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK StepSizeChange(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TEST_RETARDANCE(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK UpdateScanTime(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
