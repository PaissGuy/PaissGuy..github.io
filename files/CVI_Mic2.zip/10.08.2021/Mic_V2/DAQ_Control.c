#include "MIC_V2.h"
#include <analysis.h>
#include <utility.h>
#include <ansi_c.h>
#include <userint.h>
#include "DAQ_Control.h"

double ReadDaqChan(char *daqChan)
{
	TaskHandle tempTask=NULL;
	int samps =10000;
	double data[1];
	int32    	 error=0;
	
	DAQmxErrChk(DAQmxCreateTask("tempTask", &tempTask));
	DAQmxErrChk(DAQmxCreateAIVoltageChan (tempTask, daqChan, "AI_chan", DAQmx_Val_RSE, -10, 10, DAQmx_Val_Volts, "")); 
	DAQmxErrChk(DAQmxCfgSampClkTiming (tempTask, NULL, 150000, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));
	DAQmxErrChk(DAQmxCfgInputBuffer (tempTask, samps)); 
	
	DAQmxErrChk (DAQmxStartTask(tempTask));
	GetDataFromDAQ(tempTask,1 , samps, data,0);
	DAQmxStopTask(tempTask);
	
	DAQmxClearTask(tempTask);
	
	return data[0];
	
Error:
	return 0.0;
	
}

int32 CreateDAQtask(TaskHandle *task, DAQtaskData *data , int freq , int samps, int group ) //This function is being called by the Create_ScanXY_DAQtask function in MIC_V2.C and it gets a taskhandle, an array of daqtaskdata, the sampling frequency and amount of samples by which to average. Also group variable.
{
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'};
    TaskHandle 	 taskOut=NULL;
	int i,numchan=0;;
	
	
	if (group==1)  DAQmxErrChk(DAQmxCreateTask("AI_Group1", &taskOut)); 	
	else		   DAQmxErrChk(DAQmxCreateTask("AI_Group2", &taskOut));
	
	for (i=0; i<MAX_DAQ_AI_CHAN; i++)
	{
							 
							  
		if(data[i].Group==group && data[i].Dev_Status)
		{
			DAQmxErrChk(DAQmxCreateAIVoltageChan (taskOut, data[i].DevID, data[i].Dev_Name, DAQmx_Val_Diff, -data[i].maxIn, data[i].maxIn, DAQmx_Val_Volts, ""));
			numchan++;	
		}
	}
	if(numchan) 
	{
		DAQmxErrChk(DAQmxCfgSampClkTiming (taskOut, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		 //Set Scan rate and samples per chanel
		DAQmxErrChk(DAQmxCfgInputBuffer (taskOut, samps));
	}

	
	*task = taskOut;
	return numchan;
				  
Error:
	return DAQmxError;	
	
}

void GetDataFromDAQ(TaskHandle DAQtask, int numChans, int numPoints, double pointdata[],int chanPos ) // This function is being called by the xy_scan function in line 1204.
{
	int			k;
	int32      	numRead, error=0;
	float64     *data=NULL;   

//	DAQmxErrChk (DAQmxWaitUntilTaskDone (DAQtask, 20));
	
	if( (data=malloc(numChans*numPoints*sizeof(float64)))==NULL ) goto Error;


	DAQmxErrChk (DAQmxReadAnalogF64 (DAQtask, numPoints, 1, DAQmx_Val_GroupByChannel, data, numPoints*numChans, &numRead, 0));

	for(k=0;k<numChans;k++)
	{
		Median (&data[k*numPoints], numPoints, &pointdata[k+chanPos]); 
	//	pointdata[k]=0.0;
	//	for(l=(numRead*(k-chanPos));l<(numRead*((k-chanPos)+1));l++)		
	//		pointdata[k]+=(data[l]/numRead);	
	}
	
	
	if( data ) free(data);
	return;
	
Error:
	if( DAQmxFailed (error) )
	{
		char      	errBuff[2048]={""}; 
		DAQmxGetExtendedErrorInfo(errBuff,2048);
		MessagePopup("DAQmx Error",errBuff);
		return;
	}
}	 

void GetDataFromDAQ_Thorlabs_Cal(TaskHandle DAQtask, int numChans, int numPoints, double pointdata[],int chanPos )
{
	int			k;
	int32      	numRead, error=0;
	float64     *data=NULL;   

//	DAQmxErrChk (DAQmxWaitUntilTaskDone (DAQtask, 20));
	
	if( (data=malloc(numChans*numPoints*sizeof(float64)))==NULL ) goto Error;


	DAQmxErrChk (DAQmxReadAnalogF64 (DAQtask, numPoints, 1, DAQmx_Val_GroupByChannel, data, numPoints*numChans, &numRead, 0));

	Median (&data[0], numPoints, &pointdata[chanPos]); 
	RMS (&data[numPoints], numPoints, &pointdata[chanPos+1]);   
	
	//	for(l=(numRead*(k-chanPos));l<(numRead*((k-chanPos)+1));l++)		
	//		pointdata[k]+=(data[l]/numRead);	
	
	
	
	if( data ) free(data);
	return;
	
Error:
	if( DAQmxFailed (error) )
	{
		char      	errBuff[2048]={""}; 
		DAQmxGetExtendedErrorInfo(errBuff,2048);
		MessagePopup("DAQmx Error",errBuff);
		return;
	}
}
