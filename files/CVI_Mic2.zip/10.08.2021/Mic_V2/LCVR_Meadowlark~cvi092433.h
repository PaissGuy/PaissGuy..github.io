
#ifndef LCVR_INCLUDE  
#define LCVR_INCLUDE       


#pragma DisableUnreferencedIdentifiers  
#define LCVR_COM_PORT    6
#define LCVR_DEVICE_NAME    "COM6"
#define LCVR_BUAD_RATE 38400

#define THORLABS_LCVR_COM_PORT    6
#define THORLABS_LCVR_DEVICE_NAME    "COM6"
#define THORLABS_LCVR_BUAD_RATE 115200

#define DATA_BITS 8
#define STOP_BIT 1
#define PARITY 0
#define Q_SIZE 512
#define MAX_COMMAND_LENGTH	50
#define ZERO_LAMBDA 0						  	
#define QWP_LAMBDA 1	//LCP
#define HWP_LAMBDA 2
#define THREE_QWP_LAMBDA 3   //RCP
#define LCVR_CHAN 2
#define CUSTOM_VOLTAGE 4
#define LCVR_MEADOWLARK 0
#define LCRV_THORLABS 1

#define ViErrChk(WrappedFunc) {ViErr = (WrappedFunc); if (ViErr < 0) {goto Error;}}
#define ViNullChk(WrappedFunc) {if (0 == (WrappedFunc)) {ViErr = VI_ERROR_ALLOC; goto Error;}}

//#include <rs232.h> 

#ifdef __cplusplus
	extern "C" {
#endif

		
/*******************************************************************************/
//Prototypes //
int OPEN_LCVR_port(ViSession resManeger ); 
void Close_LCVR_port(void) ;
void LCRV_Set_Retardation (int wavelength, int retardation, int chan);
double LCRV_Get_Retardation_Voltage(int wavelength, int retardation);      
int LCVR_Set_Modulation_V (int chan, double Voltage);  //chan=1,2,3,4   
#endif  //end Header Guard
