#include <ansi_c.h>
#include <userint.h>
#include "DAQ_Control.h"



int32 CreateDAQtask(TaskHandle *task, DAQtaskData *data , int freq , int samps, int group )
{
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'};
    TaskHandle 	 taskOut=NULL;
	int i,numchan=0;;
	
	
	if (group==1)  DAQmxErrChk(DAQmxCreateTask("AI_Group1", &taskOut)); 	
	else		  DAQmxErrChk(DAQmxCreateTask("AI_Group2", &taskOut));
	
	for (i=0; i<MAX_DAQ_AI_CHAN; i++)
	{
							 
							  
		if(data[i].Group==group && data[i].Dev_Status)
		{
			DAQmxErrChk(DAQmxCreateAIVoltageChan (taskOut, data[i].DevID, data[i].Dev_Name, DAQmx_Val_RSE, -data[i].maxIn, data[i].maxIn, DAQmx_Val_Volts, ""));
			numchan++;	
		}
	}
	if(numchan) 
	{
		DAQmxErrChk(DAQmxCfgSampClkTiming (taskOut, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		 //Set Scan rate and samples per chanel
		DAQmxErrChk(DAQmxCfgInputBuffer (taskOut, samps));
	}

	
	*task = taskOut;
	return numchan;
				  
Error:
	return DAQmxError;	
	
}

void GetDataFromDAQ(TaskHandle DAQtask, int numChans, int numPoints, double pointdata[] )
{
	int			k,l;
	int32      	numRead, error=0;
	float64     *data=NULL;   

	DAQmxErrChk (DAQmxWaitUntilTaskDone (DAQtask, 20));
	
	if( (data=malloc(numChans*numPoints*sizeof(float64)))==NULL ) goto Error;


	DAQmxErrChk (DAQmxReadAnalogF64 (DAQtask, numPoints, 1, DAQmx_Val_GroupByChannel, data, numPoints*numChans, &numRead, 0));

	for(k=0;k<numChans;k++)
	{
		pointdata[k]=0.0;
		for(l=(numRead*k);l<(numRead*(k+1));l++)		
			pointdata[k]+=(data[l]/numRead);	
	}
	
	
	if( data ) free(data);
	return;
	
Error:
	if( DAQmxFailed (error) )
	{
		char      	errBuff[2048]={""}; 
		DAQmxGetExtendedErrorInfo(errBuff,2048);
		MessagePopup("DAQmx Error",errBuff);
		return;
	}
}	 

