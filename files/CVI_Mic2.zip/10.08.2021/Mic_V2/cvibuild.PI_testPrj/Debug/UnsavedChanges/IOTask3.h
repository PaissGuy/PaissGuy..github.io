//**************************************************************************
//* WARNING: This file was automatically generated.  Any changes you make  *
//*          to this file will be lost if you generate the file again.     *
//**************************************************************************
#ifndef IOTASK3_INCLUDE
#define IOTASK3_INCLUDE
#include <visa.h>

#ifdef __cplusplus
	extern "C" {
#endif

/*******************************************************************************/
/* Any strings or arrays returned by this function should be freed by calling  */
/* the ANSI free function:                                                     */
/*                                                                             */
/*            ViByte *str1;                                                    */
/*            RunIOTask(&str1);                                                */
/*            free (str1);                                                     */
/*                                                                             */
/*******************************************************************************/
ViStatus RunIOTask3(ViPReal64 *token,
                    ViUInt32 *tokenSize);

#ifdef __cplusplus
	}
#endif

#endif // ifndef IOTASK3_INCLUDE
