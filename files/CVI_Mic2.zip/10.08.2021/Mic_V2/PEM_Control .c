#include <formatio.h>
#include <userint.h>
#include <utility.h>
#include <ansi_c.h>
#include "PEM_Control.h"


#define PEM_CORECTION_FACTOR 0.95

int port_open;		//Com Port Status

//local prototypes
int Add_Leading_Zeros(char *str, int cur_len, int final_len)  ;  


///


int  FlushOutQCallBack (int comport)
{
 
 	FlushOutQ (comport);
    return 0;
Error:
	return -1;
}
void SendAscii (char* send_data)
{
    int stringsize,bytes_sent;
	
	stringsize = StringLength (send_data);
    bytes_sent = ComWrt (PEM_COM_PORT, send_data, stringsize);
}
void DisplayRS232Error (int RS232Error)
{
    char ErrorMessage[200];
    switch (RS232Error)
        {
        default :
            if (RS232Error < 0)
                {  
                Fmt (ErrorMessage, "%s<RS232 error number %i", RS232Error);
                MessagePopup ("RS232 Message", ErrorMessage);
                }
            break;
        case 0  :
            MessagePopup ("RS232 Message", "No errors.");
            break;
        case -2 :
            Fmt (ErrorMessage, "%s", "Invalid port number (must be in the "
                                     "range 1 to 8).");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        case -3 :
            Fmt (ErrorMessage, "%s", "No port is open.\n"
                 "Check COM Port setting in Configure.");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        case -99 :
            Fmt (ErrorMessage, "%s", "Timeout error.\n\n"
                 "Either increase timeout value,\n"
                 "       check COM Port setting, or\n"
                 "       check device.");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        }
}
void OPEN_PEM_port_RS232(void)
{
	int RS232Error=0;
	
	DisableBreakOnLibraryErrors (); 
	RS232Error=OpenComConfig (PEM_COM_PORT, PEM_DEVICE_NAME, 9600, 0, 8, 1, 512, 512);
	EnableBreakOnLibraryErrors ();      
	
	if (RS232Error) DisplayRS232Error (RS232Error);
    if (RS232Error == 0)
    {
          port_open = 1;
          SetXMode (PEM_COM_PORT, 0);
          SetCTSMode (PEM_COM_PORT, 0);
   	      SetComTime (PEM_COM_PORT, 5);
	}
}	

void Close_PEM_port_RS232(void)  //This function is being called by the EndProgram_Sequance function in MIC_V2.c file line 556. Its main goal is to close the port with the PEM if he is online.
{
	int  RS232Error=0, outqlen;
	
	if (port_open)
                {
                
                do
                {
					outqlen = GetOutQLen (PEM_COM_PORT);
					Delay(0.01); 
				}while (outqlen > 0); 
				
                RS232Error = CloseCom (PEM_COM_PORT);
                if (RS232Error)
                    DisplayRS232Error (RS232Error);
                }
				port_open=0;

}

int PEM__Inhibit(int inh)
{
	char StrCom[128]="";
	char tmpStr[128]="";
 
	FlushOutQCallBack (PEM_COM_PORT) ;
	
	//Create the Command to send
	strcat (StrCom,"I:" ); 
    sprintf (tmpStr, "%d\r", inh);
	strcat (StrCom,tmpStr); 
	
	//Send the command to the instrument
	if (!port_open)  OPEN_PEM_port_RS232(); 
	SendAscii (StrCom);      


	return 0;
Error:
	
	return -1;	
	
}
int Add_Leading_Zeros(char *str, int cur_len, int final_len)
{
	
	while (cur_len<final_len)
	{
		strcat (str,"0" );	
		cur_len++;
	}
	return 0;
	
}

int PEM_change_R(int retardance)
{
	char StrCom[16]="";
	char tmpStr[16]="";
    int retAdjust=0;
	
	retAdjust=PEM_CORECTION_FACTOR*retardance;
	FlushOutQCallBack (PEM_COM_PORT) ;
	
	//Create the Command to send
	strcat (StrCom,"R:" ); 
	sprintf (tmpStr, "%d", retAdjust);
	int k=strlen(tmpStr);
	
	Add_Leading_Zeros(StrCom,k,4);

	strcat (StrCom,tmpStr);
	strcat (StrCom,"\r");
   	
	//Send the command to the instrument
	if (!port_open)  OPEN_PEM_port_RS232(); 

	SendAscii (StrCom);      


	return 0;
Error:
	
	return -1;	
	
}
int PEM_change_Wavelength(int wavelength, int retardance)
{
	char StrCom[16]="";
	char tmpStr[16]="";
	
	
	FlushOutQCallBack (PEM_COM_PORT) ; 
	
	//Create the Command to send
	strcat (StrCom,"W:" ); 
	sprintf (tmpStr, "%d", wavelength);
	int k=strlen(tmpStr);
	
	Add_Leading_Zeros(StrCom,k,5); 
	
	strcat (StrCom,tmpStr);
	strcat (StrCom,".0");
	strcat (StrCom,"\r");
	

	//Send the command to the instrument
	if (!port_open)  OPEN_PEM_port_RS232();
	
	PEM_change_R(0);
	Delay(0.25);
	PEM_change_R(retardance);
	Delay(0.25);
	PEM_change_R(0);
	Delay(0.25);
	PEM_change_R(retardance);
	Delay(0.25);
	SendAscii (StrCom);      



	return 0;
Error:
	
	return -1;	
	
}


int PEM_change_Echo(int echo)
{
	char StrCom[16]="";
	char tmpStr[16]="";

	FlushOutQCallBack (PEM_COM_PORT) ; 
	
	
	//Create the Command to send
	if(!echo) strcat (StrCom,"E:0\r" ); 
	else   strcat (StrCom,"E:1\r" );
				 //0=echo, 1=no echo
	
	//Send the command to the instrument
	if (!port_open)  OPEN_PEM_port_RS232(); 
		
	SendAscii (StrCom);      
	
	
	
	
	return 0;
Error:
	
	return -1;	
	
}
