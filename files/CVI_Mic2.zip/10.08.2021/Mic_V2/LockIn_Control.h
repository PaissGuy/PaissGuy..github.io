// GPIB Control of EG&G Lock-In ammplifier


#ifndef LIA_INCLUDE
#define LIA_INCLUDE

#ifdef __cplusplus
	extern "C" {
#endif
		
#include <gpib.h>
#define LIA_CHAN_SOURCE_X 0
#define LIA_CHAN_SOURCE_Y 1
#define LIA_CHAN_SOURCE_MAG 2		
#define LIA_CHAN_SOURCE_PHASE 3		  //9V=+180, -9V=-180 
#define LIA_CHAN_SOURCE_MAG2 12	
#define LIA_CHAN_SOURCE_PHASE2 13		  //9V=+180, -9V=-180
#define EGNG_OVERLOAD 17 
		
void setup_LIA (int ParametersPanel);		
int LIA_ChangeChanSource(int chan, int outputType) ;
void LIA_AutoPhase(void);
void LIA_AutoOffset(void);
int LIA_SendGPIB_cmd(char *cmd);
void LIA_AutoSensitivity(void);
double EGNG_Read_Sensitivity_Double(void);
void EGNG_Change_SensitivityBy(int SettingNumChange);
int LIA_OverloadCheck(void);
int LIA_Get_Mag(void); //written by Guy
int LIA_Get_Phase(void);
#ifdef __cplusplus
	}
#endif

#endif // ifndef AOTF_INCLUDE
