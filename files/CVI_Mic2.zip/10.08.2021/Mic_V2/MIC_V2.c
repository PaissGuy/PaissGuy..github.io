#include "MG17MO~1.h"			 //What is this library???
#include "toolbox.h"			 //National Instruments library containing useful and common functions
#include <utility.h>			 //National Instruments library 
#include <cvirte.h>				 //National Instruments library
#include <userint.h>			 //What is this library??
#include <visa.h> 				 //What is this library?
#include "MIC_V2.h"				 //Lab Windows/CVI User interface resource (UIR) Include File
#include "GUI_Functions.h"
#include "Micronix_Control.h"   //X,Y,Z stage for sample
#include "Fianium_Control.h"	// LASER
#include "PEM_Control.h"		// Photo-elastic modulator - @ gil markovitz lab
#include "AOTF_Control.h"		//  Filters for laser  AOTFs 

//#include <analysis.h>
#include "DAQ_Control.h"		//What is this library????
#include "MIC_V2main.h"			//What is this library??? ITS EMPTY!!!
//#include "Picomotor_Control.h"
#include "LockIn_Control.h"			 //EG&G lockin amplifier 7260
#include "SRS830_LIA_Control.h" 	 //SRS 830 lock in
#include "Standa_DLine_Control.h"    // Translation stage by Standa
#include "LCVR_Meadowlark.h"		 // Both meadowlark and Thorlabs Liquid crystal retarders  (need to change hardcoded integer to switch between them
#include "PI_Control.h"				 // Z stage of transmission objective

#define LIMIT_POWER_HARDCODED 1
#define LIMIT_POWER_GUI 0
#define FALSE 0
#define TRUE 1
#define VAL_MOVE 1
#define VAL_SAVE 0
#define STATE_ON 1
#define SCAN_LOC 0
#define BACKGROUND_LOC 1
#define STATE_OFF 0
#define USB_COM_DELAY 0.02
#define MAX_SCAN_NUMBER_LEN 4  
#define MAX_FILE_NAME_LENGTH  512
#define MAX_LINE_READ_LEN 25000
#define PNG_TYPE ".png"
#define DAQ_MAX_SAMPLE_RATE 250000
#define NUMBER_OF_STORED_LOCATIONS 6 // This variable is being used by the InitailizeGlobalVars in line 568 and its goal is to define how many points we can use to scan or save locations
#define SCAN_DIR_A-to-D 0
#define SCAN_DIR_B-to-C 1
#define SCAN_DIR_D-to-A 2
#define SCAN_DIR_C-to-B 3
#define ARR_TYPE_DOUBLE 0
#define ARR_TYPE_SCANPOINT 1
#define SEARCH_TYPE_ORIGIN 0
#define SEARCH_TYPE_MIN 1
#define SEARCH_TYPE_MAX 2
#define AF_ON_MAX 0
#define AF_ON_MIN 0
#define AF_ON_BG_AND_PARTICLE 3
#define AF_CURVE_ASSISTED_X50 4 
#define AF_CURVE_ASSISTED_X100 5
#define AF_CURVE_VIS_MAIN_WAVELENGTH 550
#define AF_CURVE_NIR_MAIN_WAVELENGTH 900 
#define AF_CURVE_NIR2_MAIN_WAVELENGTH 1100 
#define SCAN_BREAK_STOP -1
#define SCAN_BREAK_PAUSE 1
#define		RUN_SCAN	 0
#define SCAN_DIR_FASTx_TOPtoBOTOM_FROM_LEFT 0
#define SCAN_DIR_FASTy_RIGHTtoLEFT_FROM_UP 1
#define SCAN_DIR_FASTx_BOTOMtoTOP_FROM_RIGHT 2
#define SCAN_DIR_FASTy_LEFTtoRIGHT_FROM_BOTOM 3
#define MAIN_PANEL_IMAGE 100
#define SECONDARY_IMAGE 200 
#define EQUATION_LOG 0
#define EQUATION_FRACTION 1  
#define EQUATION_NONE 2  
#define EQUATION_NORMALIZED_LOG 3 
#define EQUATION_TIMES1000 4
#define EQUATION_CH_BG_COR 5
#define EQUATION_CD 6
#define EGNG_R_SOURCE 1
#define SRS_R_SOURCE 2
#define LIA_SEN_STATUS_OK 0   
#define LIA_SEN_STATUS_LOWER_SEN 1
#define LIA_SEN_STATUS_RAISE_SEN -1
#define LIA_SEN_STATUS_OVERLOAD 2
#define LIA_SEN_STATUS_UNDERLOAD -2 
#define EGNG_R_FULL_SCALE 10.0
#define SRS_R_FULL_SCALE 10.0
#define MAX_REFINMENT_STEPS 3
#define ALTR_SCANS_POL 1
#define ALTR_PIXEL_POL 2
#define ALTR_LINE_POL 3
#define ALTR_LIA_LIKE_MAX_MIN 4
#define CHAN_ALL 0
#define SIM_2D_GAUSSIAN 2
#define SIM_2D_HOLE 3
#define SIM_RANDOM 1
#define Transmission_Track 1 //Guy defined
#define Reflection_Track 2   //Guy defined
#define LIA_Track 3   //Guy defined
#define AF_WAVELENGTH_BASELINE 660



/*---------------------------------------------------------------------------*/
/* Macros :                                                                  */
/*---------------------------------------------------------------------------*/
#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else  



// ----------------------    Panel Handles   -------------------------------//
static int PanelHandleMain; 					   // A static global varialbe is a variable which is local to the file, and can't be called by other files using extern. The PanelHandleMain is the handle of the main panel and its goal is to
static int PanelHandelSpectrarlChart;			   // PanelHandelSpectrarlchart is the handle of the  SPEC_PANEL which is being display during a spectrum
static int PanelHandelGraph2;					   // PanelHandelHraph2 is the handle of the exptra plot panel which I have never used.
static int PanelHandelStageSettings;			   // PanelHandleStageSettings is the handle of the stage settings panel
static int PanelHandelMicronixSettings;			   // PanelHandelMicronixSettings is the handle of the Micronix advanced settings.
static int PanelHandelAOTFSettings;				   // PanelHandelAOTFSettings is the handle of the AOTF advanced settings
static int PanelHandelDAQsettings;				   // PanelHandelDAQsettings  is the handle of the daq settings.
static int PanelHandeladvScanSettings;			   // PanelHandeladvScanSettings  is the handle of the advance scan settings
static int PanelHandelmodulationSettings;		   // PanelHandelmodulationSettings is the handle of the PEM panel which is not connected.
static int PanelHandleStanda;					   // PanelHandleStanda is the handle for the standa panel.
	   int PanelHandlePopup;					   // PanelHandlePopup is the handle of the user prompt panel.
//--------------------------------------------------------------------------//

 
//----------------  RUN MODES  ---------------------------------------------//
int DEBUG_MODE=0;  		//0 for regular run, 1 debug mode on.
int Micronix_Online=1; 	//0 for ofline, 1 online. Micronix is the kinematic controller which cotrols the stage of the sample. 
int PI_Online=1;		//0 for ofline, 1 online  PI is the piezo responsible for lifting and descent the upper objective.
int Fianium_Online=1;	//0 for ofline, 1 online. Fianium is our super_continuum laser. 
int Rotation_Online=1;  //0 for ofline, 1 online  Rotation is used to say if the rotating motor just before the reference optic fiber is active or not.
int MOVE_ENABLE = 1;	//0 for moving, 0 No movement in scan
int PEM_ONLINE =0;		//0 for ofline, 1 online 
int AOTF_Online =1;		//0 for ofline, 1 online
int LCVR_Online =0;		//0 for ofline, 1 online
int STNDA_Motor_Online=0;	 //0 for ofline, 1 online Standa Stage for Pump Probe Measurement. 1 for pumpprobe
int EGNG_LIA_Online =0;		 //1 for pumpprobe
int SRS_LIA_Online =0;
int TRANSMISSION_MODE =1;    //0 for Reflection only, 1 Transmission mode, This is important! without it there would be no Auoto Focus.
int USNIG_NIRVANA_PHOTODIODE=0; 
int MANUAL_AJUST_ON_NEW_WAVELENGTH=0;
int GlobalTrackingState=0;
//--------------------------------------------------------------------------//


//---------------		Struactures 		--------------------------------//
typedef struct
 {
	double data[MAX_DAQ_AI_CHAN];
	double X_Loc;
	double Y_Loc;
	double Z_Shift;
 } ScanPoint;							// A struct of a scanpoint object used to record the voltage from the data aquisition, and its location.

typedef struct
 {
	double X;
	double Y;
	double Z;
	int Point_Status;				   // What does point_status means?
}XYZ_Point;

typedef struct
 {
	double X;
	double Y;
	int Point_Status;
}XY_Point;

typedef struct
{
	XYZ_Point Scan_Loc;
	XYZ_Point BG_Loc;
} ScanLocation;

typedef struct
{
	int Wavelength;
	int AOTF_num;
	int RF_Power; //used to change RF gain between wavelengths in Spectral Scan
}SpectralPoint; 

typedef struct
{
	double X_Step;
	double X_Size;
	double Y_Step;
	double Y_Size;
	double StepTime;
	int MeasureCycles;
	double StabTime;
	int ScanDir;
	double x0;
	double y0;
	double z0;
	int Scan_Type;
	int wavelength;
	int AI_Number;
	int AI_g1;
	int AI_g2;
	char FolderName[MAX_FILE_NAME_LENGTH/2];
	char FileName[MAX_FILE_NAME_LENGTH/2];
	int  pSearchChan;
	
	//Scan Corrections
	XY_Point DriftCorrLoc;   // Point_Status:  0 = NO, 1=YES 
	int SampleTiltCorr;   // 0 = NO, 1=YES       
	XYZ_Point TiltCorrLoc[4];	//[0-2]X,Y,Z;  
	
}ScanData;

//--------------------------------------------------------------------------//


//-----------------   Function Prototypes   ----------------------------------//  
void StartMicronixStages(void);
void Init_Standa(void);
int StartPEM_Sequance(void) ;
char** CreateOutPutFiles_XY(void) ;
FILE* MakeFile(char *fileName);
void AssignDaqDataTo_XYarrayChns(DAQtaskData *daqData,double *pointData,int group,int arrY_Pos,int arrX_Pos, int CollectionTimes);
void AssignDaqDataTo_RefinmentPointData(double *RefinmentData , DAQtaskData *daqData,double *pointData,int group,int CollectionTimes) ;
void AssignRefinmentDataTo_XYarray(DAQtaskData *daqData,double *pointData,int arrY_Pos,int arrX_Pos); 
void WriteXY_FileHeader(FILE* pFile, int index);
int XY_Scan (void* );
void GetFileAndFolderNames(int panel); 
int GetScaleFactor(void);
double f_AutoFocus(void);
int GetAOTFdevID_From_aotf_type(int aotf_type);
int MoveToLocation(int loc,int type);
void f_AutoSetPowerBalance(void);  
void SaveLocation(int loc,int type);
int SetPowerBalance(double tolerance);
double GetDisplayValFromData(double valData, double valRef, int ScanImage, double backRef, double backval);
double GetBalanceValFromData(double Target,double ref);
void GetBackgroundValues(void);
void Change_LIAs_Sensitivity(void);
void Read_LIAs_Sensitivity(void);   
double AF_Z_Curve_Adjusment(int Wavelength, int AOTF_num, int AF_Curve); 
double fAF_Transmission(void); 
int MoveToBackground(int Loc);   
void Test_Retardance_vs_Voltage(void);
void Start_PI_Stages(void); 
int f_rotate_wheel_home(void ) ;
void Delay_Line_Scan(int panel,int control);
void Delay_Line_Scan_Wavelength(int panel,int control);
char** Create_LIA_Files(int file_num); // Guy's function
void Create_Standa_Scan_File_Name(char *path); //Guy's Function.
void  SetPumpProbeWavelength( SpectralPoint CurPoint,int ProbeWavelength,int track,TaskHandle DAQtask_G1,int nPoints_G1,double *pointData); //Guy's Function
void Track_Particle_Reflection(TaskHandle DAQtask_G1,int nPoints_G1,double *pointData); //Guy's Function
void Track_Particle_Transmission(TaskHandle DAQtask_G1,int nPoints_G1,double *pointData); //Guy's Function
void Track_Particle_LIA(int wavelength); //Guy's function
void Calculate_Standa_Step(int units,int *arr); //Guy's Function 0 for picometer 1 for steps
int PP_AutoFocus(void); //Guy's Function
double Equated_AF(int target_wavelength , int wavelength_array_index , int wavelength_array_size);
double simple_Equated_AF(void);
void Move_Micronix_Af(double af_adjustment);
void Move_PI_Af(double af_adjustment);





XY_Point  SimpSpecBG_Loc;
//--------------------------------------------------------------------------// 


//-----------------   Controller Status   ----------------------------------//
int PEM_STATUS=0;     
int Micronix_STATUS=0;
int PI_STATUS=0;
int Fianium_STATUS=0;
int AOTF_STATUS=0;
//--------------------------------------------------------------------------//


//----------------		Micronix Globals		----------------------------//
extern int MicronixThreadID;
extern char MicronixErrorString[255];

int X_AXIS, Y_AXIS, Z_AXIS; //This globals define the x,y,z_axis ID fiels in the MicronixSettings panel..
MicronixData *MicronixParam=NULL;

//-----------------     Plot vars  ---------------------------------------//
int PlotChan=0,RefChan=1, PlotChan2=-1;
//--------------------------------------------------------------------------// 

//----------------		PI Globals		----------------------------//
extern char PI_ErrorString[255];
extern int PI_ThreadID;    

int PI_AXIS=1;
PI_Data *PI_Param=NULL;  		 //What?
//--------------------------------------------------------------------------//


//----------------		AOTF Globals		----------------------------//

int VIS_ID, NIR_ID, NIR2_ID; // AOTF control values.
int ActiveAOTF=-1;
//--------------------------------------------------------------------------// 
 

//----------------		Standa Globals		----------------------------//

int Standa_Current_Location=0;
//--------------------------------------------------------------------------// 
 
//----------------		Device Session Manegers		----------------------------//
ViSession DevicesSessionManeger=VI_NULL;
static int rotorStageHandle;
//--------------------------------------------------------------------------// 
 extern int LCRV_CalMethod=1;  //1 for absolute Retardance, 0 for Intersection Cal method
 
//----------------		Program Globals 		----------------------------//
ScanLocation StoredLoc[6]; // This variable is used to save the locations of the points we are using to scan and save;
double AF_Z_Offset=0;
int ScanThreadID=-1;
int ScanBreak;  //-1 Stop Scan, 0 - Normal Run, 1 - Puase Scan
ScanPoint **XYarray, **oldXYarray, **SPCarray;
double BackgroundVals[MAX_DAQ_AI_CHAN]={0.0}, DAQoffsetVals[MAX_DAQ_AI_CHAN]={0.0},Refinment_XY_Sum[MAX_DAQ_AI_CHAN]={0.0}, pol_LIA_disp_diff[4][MAX_DAQ_AI_CHAN] ={0.0};
SpectralPoint *WavelengthArray =NULL;
//double Plot1arr[GRAPH_SIZE][GRAPH_SIZE]={0}, Plot2arr[GRAPH_SIZE][GRAPH_SIZE]={0};
int X_Scan_size=0, Y_Scan_size=0;
int ScanRunning=0; 
ScanData sData={.AI_Number=0,.AI_g1=0,.AI_g2=0 };//Here I define the variable sData and initialize the 3 variables in the block to be 0. AI Number symbolize the number of active channels in each group, and g1 how many from g1 and g2 for how many from group 2.
XYZ_Point Min_Location={0}, Max_Location={0};
int X_Max_Loc_ind=0,Y_Max_Loc_ind=0,X_Min_Loc_ind=0,Y_Min_Loc_ind=0;
double XY_ScanMax,XY_ScanMin, BG_val;
int popup_confirm=0;
//Canvas Press Location Variable
int X_TMP=-1; Y_TMP=-1;
int GUI_Thread_Lock=0;

////////////////////	LOCK IN Related Variables ////////////////////////////
int  EGNG_R_chan=-1,EGNG_Sen_Status=0,SRS_R_chan=-1,SRS_Sen_Status=0;
double EGNG_R_Sen_Double, SRS_R_Sen_Double;
int ModulationFlag=0;
//--------------------------------------------------------------------------// 




int LoadPannels(int argc, char *argv[])  //This function main goal is to Load all the panels of the GUI.
{
	
	if ((PanelHandleMain = LoadPanel (0, "MIC_V2.uir", MAIN_PANEL)) < 0)	  //LoadPanel is a function made by National Instrumet to load the panels for the GUI.
		return -1;
	/*
	   int LoadPanel (int parentPanelHandle, char filename[], int panelResourceID);

Purpose
Loads a panel into memory from a user interface resource (.uir) file or text user interface (.tui) file you created in the User Interface Editor.

The panel becomes a child panel of the parent panel you specify by parentPanelHandle. To make the panel a top-level panel, pass 0 for the parentPanelHandle.

The function returns a panel handle that you use in subsequent function calls to specify the panel. You must call DisplayPanel to make the panel visible.
	 Parameters
Input
Name	Type	Description
parentPanelHandle	int	Handle of the panel into which to load the panel as a child panel. Pass 0 to load the panel as a top-level window.

You can obtain this handle from functions such as LoadPanel and NewPanel.
filename	char []	Name of the .uir or .tui that contains the panel.

You can use a complete pathname or a simple filename for filename. If the name is a simple filename that contains no directory path, the file is loaded from the directory that contains the executable.

You must call LoadPanelEx with a valid calling module handle to load an embedded .uir file from a DLL if you enable the Embed project .UIRs option in the Target Settings dialog box.
panelResourceID	int	Defined constant that you assigned to the panel in the User Interface Editor.

The panelResourceID is found in the .uir header file and you use it only to load the panel into memory. You use the panel handle this function returns to refer to the panel in subsequent function calls.

When you load a panel from a text user interface (.tui) file, the panelResourceID parameter must be the header number of the .tui file section that defines the panel. For example, if the section header for the panel is [Panel003], pass 3 as the panelResourceID.

	*/
	if (InitCVIRTE (0, argv, 0) == 0)  // InitCVIRTE is in cvirte.h The basic role of the InitCVIRTE function is to make the essential calls to startup code that is needed for your specific module (DLL, EXE).  This startup code is specific to your module and doesn't affect other modules using the CVI RTE.
		return -1;	/* out of memory */
	if ((PanelHandelSpectrarlChart = LoadPanel (0, "MIC_V2.uir", SPEC_PANEL)) < 0)
		return -1;
	if ((PanelHandelGraph2 = LoadPanel (0, "MIC_V2.uir", PLOT_PANEL)) < 0)
		return -1;
	if ((PanelHandelMicronixSettings = LoadPanel (0, "MIC_V2.uir", MICRONIX_S)) < 0)
		return -1;
	if ((PanelHandelAOTFSettings = LoadPanel (0, "MIC_V2.uir", AOTF_SETTI)) < 0)
		return -1;
	if ((PanelHandelDAQsettings = LoadPanel (0, "MIC_V2.uir", DAQ_SETTI)) < 0)
		return -1;
	if ((PanelHandeladvScanSettings = LoadPanel (0, "MIC_V2.uir", ADV_SCAN_S)) < 0)
		return -1;
	if ((PanelHandelmodulationSettings = LoadPanel (0, "MIC_V2.uir", MOD_SETTIN)) < 0)
		return -1;	
	if ((PanelHandelStageSettings = LoadPanel (0, "MIC_V2.uir", STAGE_SETT)) < 0)
		return -1;
	if ((PanelHandleStanda = LoadPanel (0, "MIC_V2.uir", STNDA_PNL)) < 0)
		return -1;
	return 0;
}

int DiscardPanels(void)   // This function is being called by the main function in line 606 and it's main goal is to Removes a panel and any of its child panels from memory and clears them from the screen if visible.
{
	DiscardPanel (PanelHandelSpectrarlChart); //SpectrarlChart
	DiscardPanel (PanelHandelGraph2);
	DiscardPanel (PanelHandelStageSettings);
	DiscardPanel (PanelHandleMain);
	DiscardPanel (PanelHandelMicronixSettings);
	DiscardPanel (PanelHandelAOTFSettings);
	DiscardPanel (PanelHandelDAQsettings);
	DiscardPanel (PanelHandeladvScanSettings);
	DiscardPanel (PanelHandelmodulationSettings);	
	
	return 0;
}

int StartMicronix_Sequance(void)  // A function which is being called by the ControllerStartup_Sequence in line 509 and its used to 
{
	if( (MicronixParam=malloc(sizeof(MicronixData)))==NULL ) goto Error; //A goto statement in C programming provides an unconditional jump from the 'goto' to a labeled statement in the same function. MicronixData is a struct used by the Micronix.h if the struct is null... so error 
	StartMicronixStages();//This function is defined in line 3136 and its job is  
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_LED,1);
	
	return 0;
Error: 
	
	return -1;
}
int Start_PI_Sequance(void)   // A function which is being called by the ControllerStartup_Sequence in line 509 and its used to start a port and servo of the piezo responsible for the upper objective. 
{
	if( (PI_Param=malloc(sizeof(PI_Data)))==NULL ) goto Error;    //Create a PI_data object, if no such object go to error.
	Start_PI_Stages();	// Open port, and start servo of the PI.
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_PI_LED,1);
	
	return 0;
Error: 
	return -1;
}
int StartFianium_Sequance(void) // This function responsible for the port establishment and initialization for the laser sequence.
{
	OpenFianiumPort(DevicesSessionManeger );
	LaserPowerUpdate(FUNDAMENTAL_OUTPUT, 0.0);
	LaserPowerUpdate(SC_OUTPUT, 0.0);
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_FIANIUM_LED,1);
	return 0;
}
int StartPEM_Sequance(void)   // Offline
{
	OPEN_PEM_port_RS232();	
	Delay(0.20);
	PEM_change_Echo(1);
	Delay(0.20);
	PEM__Inhibit(0); //Make sure normal operation is on	
	Delay(0.20);
	PEM_change_R(0);
	return 0;
}
int StartLCRV_Sequance(void) // Offline
{
	OPEN_LCVR_port(DevicesSessionManeger);
	Start_THORLABS_LCRV_Sequance();
	return 0;
}
int StartAOTF_Sequance(void) //This function is called by the ContorllersStartUP_Sequance in line 510 and its main goal is to initialize the AOTF.
{
	hinstLib = LoadLibrary("AotfLibrary.dll"); //LoadLibrary function is used to explicit link a dll to the memory. By doing so we can call the external functions in the dll.. 
	AOTFInitLibrary(); //This function turns the AOTF on and uses the AOTFIitiLibrary function in the AOTF_Control.c file.
	AOTF_STATUS= 1;	//Change the aotf status to 1.

	GetAOTF_IDs( PanelHandelAOTFSettings , &VIS_ID, &NIR_ID, &NIR2_ID);//Put the AOTF_IDs in the global values. 
	SetAOTF_IDs(VIS_ID,NIR_ID,NIR2_ID); //Pass the controller values to the AOTF_Controller file.
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_LED,1);//Change the value of the Led to on.
	return 0;
	
}
int StartPicomotor_sequance(void)
{
//	if(InitializePicomotor()>0)
//		SetCtrlVal(PanelHandleMain,MAIN_PANEL_PICOMOTOR_LED,1);
	return 0;	
}
void SimulateSigmal(double *Data, int simType,int chan, int X_Size,int Cur_X ,int Y_Size, int Cur_Y )
{

	int k,start,end;
	int aux;
	
	if (chan== CHAN_ALL) {
		start=0;
		end=sData.AI_Number;
	}
	else{
		start=chan;
		end=chan+1;	
	}


	switch(simType)
	{
		case SIM_RANDOM:
			srand((unsigned int)time(NULL));  
			for(k=start;k<end;k++) Data[k] =rand();
			break;
		case SIM_2D_GAUSSIAN:
			aux= (Cur_X-X_Size/2.0)*(Cur_X-X_Size/2.0)+(Cur_Y-Y_Size/2.0)*(Cur_Y-Y_Size/2.0);
			for(k=start;k<end;k++) Data[k] =-(1+rand())*(exp(-(aux)/2))/(6.28*X_Size*Y_Size); 
			break;
		case SIM_2D_HOLE:
			aux= (Cur_X-X_Size/2.0)*(Cur_X-X_Size/2.0)+(Cur_Y-Y_Size/2.0)*(Cur_Y-Y_Size/2.0);
			for(k=start;k<end;k++) Data[k] = -aux;
			break; 
	}
}


void SetDAQ_AI_Offset(void) // This function runs in the control startup sequence at line 544 and it calls for every channel which is on, the function ReadDaqChan in DAQ_Controler File.
{
	char daqChan[40]="";
	double powerTest;
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_0 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	DAQoffsetVals[0] =powerTest;
		
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_1 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	DAQoffsetVals[1] =powerTest;
		
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_2 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	DAQoffsetVals[2] =powerTest;	
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_3 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	DAQoffsetVals[3] =powerTest;
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_4 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	DAQoffsetVals[4] =powerTest;
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_5 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	DAQoffsetVals[5] =powerTest;

}

int ContorllersStartUP_Sequance(void)	 //This function is called by the main function in line 591. Its main goal is to do start sequence to all the modes defiend in run modes line 114
{
//Initialize Devices
	int tmp;
	
	if (Micronix_Online) StartMicronix_Sequance(); //This function does initialization and connection to the micronix device, and chage its value to 1.
	
	if (PI_Online) 		 Start_PI_Sequance();	 // This function build port and initialization sequence for the PI responsible for the upper objective. 

	if (Fianium_Online)  StartFianium_Sequance();  // This function calls the function in line 402 which  build port and initialization sequence for the fianium pulse laser.
	
	if (AOTF_Online)	 StartAOTF_Sequance();   // This function calls the function in line 427 which goal is to  
	
	if (PEM_ONLINE) 	 StartPEM_Sequance(); // This function calls the function in line 410 , but the pem is offline so it would not get there.
	
	if (LCVR_Online)     StartLCRV_Sequance(); // This function calls the function in line 421 but its offline

	if (STNDA_Motor_Online)     My_Init_Motor();
	
	if (EGNG_LIA_Online) setup_LIA ( PanelHandelmodulationSettings); // This function calls the function in line 14 of the lock in amplifier.c file. offline for now! 
	
	if (SRS_LIA_Online) SRS830_setup_LIA ( PanelHandelmodulationSettings); // This function calls the function in line 14 of SRS830_LIA_Controller.c but its offline for now.
	
	if(Rotation_Online) 	
	{
		GetObjHandleFromActiveXCtrl (PanelHandelStageSettings, STAGE_SETT_MG17MOTOR, &rotorStageHandle);
		MG17MotorLib__DMG17MotorStartCtrl (rotorStageHandle, NULL, &tmp);
		SetCtrlVal(PanelHandleMain,MAIN_PANEL_TRANSLATION_LED,1); 
	//	f_rotate_wheel_home();
	}
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_DAQ_LED,1);   // Set the led of the main panel daq led on.
	
	SetDAQ_AI_Offset();
		
return 0;	
}

void EndProgram_Sequance(void)  //This function is being called by the main function in line 609
{
	long tmp; 
	if (MicronixParam!=NULL) free (MicronixParam);// micronixparam is a MicronixData object type pointer that consists locations and axis. Why save all axis positions?? 
	if (PI_Param!=NULL) free (PI_Param);  		  // Pi_Param is  PI_Data object type pointer and it also save an axis, and three locations. This line free the object memory. Why save all axis positions????
	if (PI_Online) Close_PI_InstrSession() ;	  //  Calls the function in PI_Control.c file in line  203 which terminates the session with the PI.
	if (AOTF_Online) Set_AOTF_ALL_Zero();
	if (AOTF_Online) AOTFCloseLibrary();		  // Calls the function in AOTF_Control.c line 34. Its main goal is to free the aotf dll.
	if (PEM_ONLINE) Close_PEM_port_RS232();		  // Calls the function in PEM_Control.c file line 86. Its main goal is to close the port with the PEM if its online
	if (LCVR_Online)     Close_LCVR_port(); 	  // LCVR is also offline.
	if (Rotation_Online) MG17MotorLib__DMG17MotorStopCtrl (rotorStageHandle, NULL, &tmp);
	if (Fianium_Online) 
	{
		LaserPowerUpdate(FUNDAMENTAL_OUTPUT, 0.0);
		LaserPowerUpdate(SC_OUTPUT, 0.0);	
	}
	if(STNDA_Motor_Online) MyCloseStanda();

	
}
void InitailizeGlobalVars(void)  //This function is being called by the main function in line 578 and its goal is
{	  
	int k;
	for (k=0;k<NUMBER_OF_STORED_LOCATIONS;k++)  // For each point in the StoredLoc array which containts NUMBER_OF_STORED_LOCATIONS scan points, we default the location to 0.
	{
		StoredLoc[k].BG_Loc.Point_Status=0; // Why 0?
		StoredLoc[k].Scan_Loc.Point_Status=0;
	}
	
}
int main (int argc, char *argv[])			//Here is the main function.
{
	// int argc - FILL
	// int *argv[] - FILL
	ViStatus ViErr = 0;						//ViStatus is a type for signed int_32 initialized by typedef inside visatype.h 
	
	
	LoadPannels( argc,  argv);				//LoadPannels is a function defined in line 307. It's main goal is to use Load_Panel function for each panel created in the GUI, and by that giving each panel an ID..
	
	SetGUI_InitialState (PanelHandleMain,PanelHandelGraph2, PanelHandelSpectrarlChart); //SetGUI_InitialState is a function defined in GUI_Functions file and its goal is to draw and define the two scale bars and the color map. 
	
	//Create Device Session Maneger
	ViErrChk(viOpenDefaultRM(&DevicesSessionManeger));    //Somekind of weird VISA and NI function which must be called _ FILL
	
	ContorllersStartUP_Sequance();	  // This function calls the   ContorllersStartUP_Sequance function in line 510. The function main goal is to create ports and initialize parameters for all the online devices 
	
	InitailizeGlobalVars();  // This function calls the function in line  568 in its main goal is 
	
	DisplayPanel (PanelHandleMain); // DisplayPanel is a CVI function and it displays a panel. When a panel is visible and enabled, the user can operate it. Calling DisplayPanel when a panel is already displayed causes the panel to be completely redrawn.
	DisplayPanel (PanelHandelDAQsettings); //Why do we need to display that at the beginning as well?
	
	
//	DisplayPanel (PanelHandelSpectrarlChart);
	
	RunUserInterface ();//Runs the user interface and issues events to callback functions.

//RunUserInterface does not return until you call QuitUserInterface from within a callback function. RunUserInterface returns the value that you pass to QuitUserInterface.

	DiscardPanels(); //  This function is calling the function in line 360 and its main goal is to Removes a panel and any of its child panels from memory and clears them from the screen if visible.
	
	
	EndProgram_Sequance();
	 
	
	return 0;
	
Error:
	MessagePopup("Error", "Can't Open Resource maneger Session");
return -1;
}


int CVICALLBACK QuitCallback (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			QuitUserInterface (PanelHandleMain);
			break;
	}
	return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			SCAN				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////


int GetXYScanData( int panel )   //This function recieves the panelhandle , it is being called after pressing the start scan button, and it is used for assigning all the data necessary to the global variables to create a scan. Like how many channels are open in the IO and such.
{
	int g1=0,g2=0;

	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_X_SIZE,&sData.X_Size);  // This function Gets the value of the x size dimension from the main panel in the xy parameters on put it in the global variable sData
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_Y_SIZE,&sData.Y_Size);	// This function gets the value of the y size dimension from the main panel in the xy parameters.
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_X,&sData.X_Step);	// This function gets the x step size and puts it in the sData parameter
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_Y,&sData.Y_Step);	// This function gets the y step size and puts it in the sData parameter. 	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_TIME,&sData.StepTime);	// This function gets the step time?!?! WHAT?!!?!!?!?
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_DELAY,&sData.StabTime);	// This function gets the step delay?!?! WHAT?!?!?!?!
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_SCAN_DIRECTION,&sData.ScanDir);	//This function gets the direction of the scan.
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_WAVELENGTH_INDICATOR,&sData.wavelength);	//This function gets the wavelength from the wavelength indicator under the channels list in the main panel.	
	GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_SCAN_TYPE , &sData.Scan_Type);
	sData.AI_Number = GetNumberOfActiveChannelsInEachGroup(PanelHandelDAQsettings, &g1, &g2,NULL);
	
	if( sData.Scan_Type==1) sData.ScanDir= 0;
	else if( sData.Scan_Type==2) sData.ScanDir= 1; 
	
	sData.AI_g1=g1;//Assign the channel group 
	sData.AI_g2=g2;
	EGNG_Sen_Status=0;
	SRS_Sen_Status=0;
	Read_LIAs_Sensitivity();	//Checks wether we read information from the lock in ampliers.  This might be what screwing the scan.
	
	GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_PARTICLE_SEARCH_CHAN,&sData.pSearchChan);
	
	GetFileAndFolderNames( PanelHandleMain);
	
	if(Micronix_Online)
	{
		sData.x0=MicronixPOS_Query(X_AXIS);
		Delay(USB_COM_DELAY);
		sData.y0=MicronixPOS_Query(Y_AXIS);
		Delay(USB_COM_DELAY);
		sData.z0=MicronixPOS_Query(Z_AXIS);
		Delay(USB_COM_DELAY);
	}
	return 0;
	
}


int CVICALLBACK f_start_scan (int panel, int control, int event,void *callbackData, int eventData1, int eventData2) //This function is being called when we press start scan which is a text button.
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp,num=0;  //We should not define variables in switch cases!!!!!!
			GetCtrlVal(panel,control,&tmp);	//Get the value of the Start button - start scan, if it was pushed then the val is 1 otherwise its 0.
		
			
			if(tmp && !ScanRunning)
			{
				ScanRunning=1;
				
				SetGUI_ForXYScan(PanelHandleMain,PanelHandelGraph2,PlotChan2); // This function is inside the GUI_Functions file and it is used to prepare the GUI for scan, like dimming the start scan button and undim the stop scan button.
				GetXYScanData( PanelHandleMain); //This function starts in line 638 and it is used to set the correct values into the sData variable.
			
				X_TMP=Y_TMP=-1;
				
				CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, XY_Scan, NULL, &ScanThreadID);//Create a secondary thread and start the function XY_scan in the thread
			
				CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING); //Wat for the thread to finish
				SetGUI_AfterScan(PanelHandleMain);
				
				ScanRunning=0;
				ScanBreak=0;
				
				GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,num+1);
				
			}
			else if (tmp && ScanRunning) ScanBreak = 1;
			else if (!tmp && ScanRunning) ScanBreak=0;
			break;
	}
	
	return 0;
}

int ClearAlocatedArray_ScanPoint(ScanPoint **arr)
{
	int i;
	if (arr!=NULL)
		for(i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
		{
			free(arr[i]);
		}
		free(arr);
	
	return 0;
}
void InitializeArray_Double(double arr[][GRAPH_SIZE])
{
	int i,j;
	for(i=0;i<GRAPH_SIZE;i++)
		for(j=0;j<GRAPH_SIZE;j++)
			arr[i][j]=0;

}
void MovePreviusResultToArray_ScanPoint (ScanPoint **dataArr,ScanPoint **containerArr)
{
	int x,y,yNum,xNum;
	
	yNum = sizeof(ScanPoint)/sizeof(dataArr[0]);
	xNum=  sizeof(dataArr[0])/sizeof(dataArr[0][0]);
	
	containerArr = (ScanPoint **)malloc((yNum)*sizeof(ScanPoint*));
	
	for(y=0;y<yNum;y++) 
		containerArr[y] = (ScanPoint *)malloc((xNum)*sizeof(ScanPoint));

	for(y=0;y<yNum;y++)   	
		for(x=0;x<xNum;x++)   
			containerArr[y][x]=dataArr[y][x];
		
}			
void MovePreviusResultToArray_DOUBLE (double dataArr[][GRAPH_SIZE],double containerArr[][GRAPH_SIZE])
{
	int x,y,yNum,xNum;
	
	yNum = sizeof(ScanPoint)/sizeof(dataArr[0]);
	xNum=  sizeof(dataArr[0])/sizeof(dataArr[0][0]);
	
	for(y=0;y<yNum;y++)   	
		for(x=0;x<xNum;x++)   
			containerArr[y][x]=dataArr[y][x];
	
	}	

int CreateNewResultArray_SPC(int Y_Points, int X_Points)
{
	
	int i,j,k;
	

	ClearAlocatedArray_ScanPoint(SPCarray);

	
	/////////////////Create New Result Array and initialize it   //////////////////
	SPCarray = (ScanPoint **)malloc((Y_Points)*sizeof(ScanPoint*));
	for(i=0;i<Y_Points;i++)  
	{
		SPCarray[i] = (ScanPoint *)malloc((X_Points)*sizeof(ScanPoint));
	}
	
	for(i=0;i<Y_Points;i++)   	
		for(j=0;j<X_Points;j++)   
		{
			for(k=0;k<MAX_DAQ_AI_CHAN;k++) 
			{
				SPCarray[i][j].data[k]=0.0;
				SPCarray[i][j].Z_Shift= 0.0;
			}
		}
	return 0;	
}
int CreateNewResultArray_XY(int Y_Points, int X_Points) // This function is being called by the xy_scan function
{
	
	int i,j,k;
	
	ClearAlocatedArray_ScanPoint(oldXYarray);
	MovePreviusResultToArray_ScanPoint(XYarray,oldXYarray); 
	ClearAlocatedArray_ScanPoint(XYarray);

	
	/////////////////Create New Result Array and initialize it   //////////////////
	XYarray = (ScanPoint **)malloc((Y_Points)*sizeof(ScanPoint*));
	for(i=0;i<Y_Points;i++)  
	{
		XYarray[i] = (ScanPoint *)malloc((X_Points)*sizeof(ScanPoint));
	}
	
	for(i=0;i<Y_Points;i++)   	
		for(j=0;j<X_Points;j++)   
		{
			for(k=0;k<MAX_DAQ_AI_CHAN;k++) 
			{
				XYarray[i][j].data[k]=0.0;
				XYarray[i][j].Z_Shift= 0.0;
			}
		}
	return 0;	
}


int  GetTaskGroupData (DAQtaskData *data) // This function is being called by the function Create_ScanXY_DAQtask below and it gets an array of DAQtaskData (one for each channel) and fills it with the data in the daq panel.
{
	int k;
	
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)
	{
		data[k] = GetDaqChannelData(k, PanelHandelDAQsettings);	
		strcat(data[k].Dev_Name,"AI_Ch");
		sprintf(data[k].Dev_Name, "%d",k);
	}
return 0;	
}


void  Create_ScanXY_DAQtask(TaskHandle *task1,TaskHandle *task2, int *nPoints_G1, int *nPoints_G2 ,DAQtaskData *data) // This function is being called by XY_SCAN at line 1078 and it gets two TaskHandle addresses, two int addreses and an array of DAQtaskData (one for each channel) 
{
	int freq,samps ;
	double time1=0,aux;

	GetTaskGroupData(data);//This function fills the status of the DAQtaskData array (one for each channel).
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP1,&freq); //Get the frequency sample of acquisition in group 1 channels.
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AI_AVEREGING_G1,&samps); //Get the averaging count of sample acquisition in group 1 channels.
	*nPoints_G1 =samps;
	CreateDAQtask(task1, data, freq, samps,1);
	if(sData.AI_g1) time1=1.0*samps/freq;
	

	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP2,&freq);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AI_AVEREGING_G2,&samps);
	*nPoints_G2 =samps;
	CreateDAQtask(task2, data, freq, samps,2);

	aux=(time1)*1000;
	sData.MeasureCycles=sData.StepTime/aux; 
	if (!sData.MeasureCycles ) sData.MeasureCycles=1;
	
}
void GetScanPointLocations(int Y_Points, int X_Points,double Y_Step,double X_Step, double x0, double y0 )   //This function is being called by XY_Scan function and it is used to create XY matrix of the scan locations
{
	int k,l;

	for(k=0;k<Y_Points;k++)
	  for(l=0;l<X_Points;l++)  	
	  {
		XYarray[k][l].X_Loc = x0-((l*X_Step)-((X_Points/2)*X_Step))/1000; 		 //   + June 2018     
		XYarray[k][l].Y_Loc = y0+((k*Y_Step)-((Y_Points/2)*Y_Step))/1000; 
		XYarray[k][l].Z_Shift = 0;    
	  }
	
}

void GetFastSlowAxesFromScanDirection(int *fastMax,int *slowMax,MicronixData *fastData, MicronixData *slowData,int  X_Points,int  Y_Points, ScanData sData)
{
	switch(sData.ScanDir)
	{
		case 0:
			*fastMax = X_Points;
			*slowMax = Y_Points;
			fastData->Axis = X_AXIS;
			slowData->Axis = Y_AXIS;
			if (sData.Scan_Type==1) slowData->Axis = Z_AXIS; 
			
		break;
		
		case 1:
			*fastMax = Y_Points;
			*slowMax = X_Points;
			fastData->Axis = Y_AXIS;
			slowData->Axis = X_AXIS;
			if (sData.Scan_Type==2) slowData->Axis = Z_AXIS; 
		
		break;
		
		case 2:
			*fastMax = X_Points;
			*slowMax = Y_Points;
			fastData->Axis = X_AXIS;
			slowData->Axis = Y_AXIS;
		break;
		
		case 3:
			*fastMax = Y_Points;
			*slowMax = X_Points;
			fastData->Axis = Y_AXIS;
			slowData->Axis = X_AXIS;
		break;
	}	
	
}

void GetScanPointsNumber(int *X_Points, int *Y_Points, double X_Size ,double X_Step,double Y_Size ,double Y_Step) //This function is being called by XY_Scan in line 1010
{
	*X_Points= RoundRealToNearestInteger(  X_Size/X_Step );
	*Y_Points= RoundRealToNearestInteger(  Y_Size/Y_Step );
	if(!*X_Points/2) *X_Points++;
	if(!*Y_Points/2) *Y_Points++;	
	X_Scan_size=*X_Points;
	Y_Scan_size=*Y_Points;
	
	
}
void StopScanSequance_XY(void )
{
	if(Micronix_Online)
	{
		MicronixParam->Axis=X_AXIS;
		MicronixParam->data1=sData.x0;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
		MicronixParam->Axis=Y_AXIS;
		MicronixParam->data1=sData.y0;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	}
	
}

int GetScaleFactor(void) // This function is being called by the AutoScaleXY_Graph() function, and it returns the matrix scan size divided by the maximum length axis.
{
	int graphScaleFactor;
	
	if(Y_Scan_size*X_Scan_size==0) return 0;
	if(Y_Scan_size>X_Scan_size) graphScaleFactor = GRAPH_SIZE/Y_Scan_size;
	else				  graphScaleFactor = GRAPH_SIZE/X_Scan_size;	
	
	return graphScaleFactor;
	
}
void GetArrayIndexFromScanIndexandDirection(int *Xind,int *Yind,int SlowInd,int FastInd)
{
	switch (sData.ScanDir)
	{
		case SCAN_DIR_FASTx_TOPtoBOTOM_FROM_LEFT:
			*Xind=FastInd;	   //FastInd;
			*Yind=SlowInd;
			break;
  
		case SCAN_DIR_FASTy_RIGHTtoLEFT_FROM_UP:
			*Xind=X_Scan_size-SlowInd-1;
			*Yind=FastInd;
			break;
		case SCAN_DIR_FASTx_BOTOMtoTOP_FROM_RIGHT:
			*Xind=X_Scan_size-FastInd-1; //					 X_Scan_size-FastInd-1
			*Yind=Y_Scan_size-SlowInd-1;
			break; 
 		case SCAN_DIR_FASTy_LEFTtoRIGHT_FROM_BOTOM:
			*Xind=SlowInd;
			*Yind=Y_Scan_size-FastInd-1;
			break; 		
			
	}
	
}
void ClearCurrentDataPointFromResultsArray(int arrY_Pos,int arrX_Pos)
{
	int k;	
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)   XYarray[arrY_Pos][arrX_Pos].data[k] = 0.0;
}

void Build_Refinement_Loc_Array(XY_Point **Loc_arr, int Ref_Step,double refinment_size,double StepSize,int *fastMax, int *slowMax,double X_Loc,double Y_Loc)
{
	int k,l;

	*slowMax=*fastMax= RoundRealToNearestInteger((RoundRealToNearestInteger(refinment_size/StepSize)+1)/Ref_Step);
	for(k=0;k<*slowMax;k++)
		for(l=0;l<*fastMax;l++) 
		{
			Loc_arr[k][l].X = X_Loc-((refinment_size/2) - StepSize*l);	
			Loc_arr[k][l].Y = Y_Loc-((refinment_size/2) - StepSize*k);
		}
	
}

void AssignDaqDataTo_LIAsim_array(int pos, DAQtaskData *daqData,double *pointData,int group,int CollectionTimes)
{
	int k,loc;
	if (pos>5) loc=0;
	else if( pos<-5) loc=1;
	else if (pos>0) loc=2;
	else loc=3;
	
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)  
		if(daqData[k].Dev_Status && daqData[k].Group==group)  pol_LIA_disp_diff[loc][k] +=pointData[k]/CollectionTimes; 

}
int XY_Scan (void *dat ) // This function is being called by the f_stat_scan callback function after pressing the start scan button.
{
	FILE *resFiles[MAX_DAQ_AI_CHAN+1]={NULL};
	char **resFileNames=NULL;
	int X_Points, Y_Points;
	int graphScaleFactor,gY=0,gX=0;
	double PlotPointVal=0.0;
	int i,j,k, l, fastMax=0, slowMax=0, Xind=0, Yind=0,z;
	double pointData[MAX_DAQ_AI_CHAN]={0.0}, Refinment_Step_data[MAX_DAQ_AI_CHAN]={0.0};
	XYZ_Point point;
	TaskHandle DAQtask_G1=0,DAQtask_G2=0;
	int nPoints_G1, nPoints_G2,daqAux;
	DAQtaskData *daqData;
	MicronixData *fastData=NULL,*slowData=NULL;
	int32 error=0;
	int32 DAQmxError = DAQmxSuccess;
	double minVal=1000.0,maxVal=-1000.0;
	int MaxPointLoop=3;
	int aquisitionLoop;
	double EGNG_R_max=0,SRS_R_max=0;
	int LIA_Sen_Loop_maxTimes,LIA_DATA_ERR_FLAG=0;
	double LIA_Sens_Temp=0.0;
	int AltrPolCycles, Pol_1,Pol_2, MeasureCycles2=1; //AltrPolCycles=0,MeasureCycles=1 - ALTR stands for alternating
	int Ref_Step,Refinment_Steps=1,SearchType;
	double MAX_REFINMENT_SIDE,REFINMENT_StepSize ;
	XY_Point  **Refin_Loc_XY ;
	int MAX_REFIN_ARR_SIDE =50;
	int curpol=1;
	int Altr_LIAsimCycles=0, boolBG=0,scanLoc;
	
	//Get POlarization states for alternate scans if needed//
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_ALTR_SCAN_SET , &AltrPolCycles);  //This functions gets the type of scan used to make the scan. For me its regular for now or 0.
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_1 , &Pol_1); // This function gets unknown variable WHAT?!?! for me its RCP or 3
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_2 , &Pol_2); // This function gets unknown variable WHAT?!?! for me its LCP or 1
	if ( AltrPolCycles== ALTR_PIXEL_POL) MeasureCycles2 =sData.MeasureCycles; // For me this if never being implemented. It asks if the scan type is different value then regular. 
	if ( AltrPolCycles== ALTR_LIA_LIKE_MAX_MIN) {GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_LIA_SIM_CYCLS,&MaxPointLoop);MaxPointLoop*=2;Altr_LIAsimCycles=1;}// For me this if never being implemented, it asks if the scan is different type than regular. 		
	
	//Get Particle search type for refinment cycles
	for(z=0;z<MAX_DAQ_AI_CHAN;z++) Refinment_XY_Sum[z]=0.0;
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SEARCH_TYPE_MAX_MIN , &SearchType);// For me the value is zero. Gets the value from the particle search mode edit ring.
	if(SearchType==SEARCH_TYPE_MIN || SearchType==SEARCH_TYPE_MAX) Refinment_Steps=MAX_REFINMENT_STEPS; // Never enter this if.
	for(z=0;z<MAX_DAQ_AI_CHAN;z++) {pol_LIA_disp_diff[0][z]=0.0; pol_LIA_disp_diff[1][z]=0.0;pol_LIA_disp_diff[2][z]=0.0;pol_LIA_disp_diff[3][z]=0.0;}
	
	Refin_Loc_XY=(XY_Point**)malloc(MAX_REFIN_ARR_SIDE*sizeof(XY_Point*));
	for(z=0;z<MAX_REFIN_ARR_SIDE;z++)  
	{
		Refin_Loc_XY[z] = (XY_Point *)malloc((MAX_REFIN_ARR_SIDE)*sizeof(XY_Point));
		for(k=0;k<MAX_REFIN_ARR_SIDE;k++) 
		{Refin_Loc_XY[z][k].X=0.0;Refin_Loc_XY[z][k].Y=0.0;} 	
	}

			
	daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData)); 
	fastData=(MicronixData*)malloc(sizeof(MicronixData));
	slowData=(MicronixData*)malloc(sizeof(MicronixData));

	Read_LIAs_Sensitivity(); // Uses the lock in amplifiers...
	
	GetScanPointsNumber(&X_Points, &Y_Points, sData.X_Size , sData.X_Step, sData.Y_Size ,sData.Y_Step);
	
	resFileNames=CreateOutPutFiles_XY();
	
	CreateNewResultArray_XY(Y_Points, X_Points);
	 
	Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
	
	graphScaleFactor = GetScaleFactor();
	
	//Raster Scan This creates a matrix of the scan locations//
	if( sData.Scan_Type==1)	{	
		GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,sData.x0, sData.z0 ); }  //Here Y acts as Z axis
	
	else if( sData.Scan_Type==2)  {
		GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,sData.z0, sData.y0 );}   //Here X acts as Z axis 
	else {
		GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,sData.x0, sData.y0 );}   //Regular XY Scan
	
	///////////////////////////////////////////////////////////
	

	for (Ref_Step=0;Ref_Step<Refinment_Steps+Altr_LIAsimCycles; Ref_Step++)
	{
	if(!Ref_Step)	GetFastSlowAxesFromScanDirection(&fastMax, &slowMax, fastData, slowData, X_Points, Y_Points, sData);      
	else if((Ref_Step<MAX_REFINMENT_STEPS-1) && Ref_Step)
	{
		if(sData.Y_Step>sData.X_Step) MAX_REFINMENT_SIDE=sData.Y_Step/1000.0;
		else MAX_REFINMENT_SIDE=sData.X_Step/1000.0;
		REFINMENT_StepSize=(20.0/1000/1000); //20nm
		
		if(SearchType==SEARCH_TYPE_MIN) 	 Build_Refinement_Loc_Array(Refin_Loc_XY,Ref_Step,MAX_REFINMENT_SIDE,REFINMENT_StepSize,&fastMax, &slowMax,Min_Location.X,Min_Location.Y);	
		else if(SearchType==SEARCH_TYPE_MAX) Build_Refinement_Loc_Array(Refin_Loc_XY,Ref_Step,MAX_REFINMENT_SIDE,REFINMENT_StepSize,&fastMax, &slowMax,Max_Location.X,Max_Location.Y);
		
	}
	else 
	{
		   slowMax=fastMax=1;
	}

	for(k=0;k<slowMax;k++)
	{
		for(l=0;l<fastMax;l++)		  // 
		{											   
			//For time measwurement//
			//double time1=0,time2=0;
			//time1=Timer(); 
			//time2=Timer();
			//time2=time2-time1;
			////
			
			if(!Ref_Step)
			{
				GetArrayIndexFromScanIndexandDirection(&Xind,&Yind,k,l);

			
				if(sData.ScanDir==1 || sData.ScanDir==3)
				{
					slowData->data1 = XYarray[Yind][Xind].X_Loc;   //on YZ scan acts as Z
					fastData->data1 = XYarray[Yind][Xind].Y_Loc;   
				}
				else
				{
					slowData->data1 = XYarray[Yind][Xind].Y_Loc;   //on XZ scan acts as Z 
					fastData->data1 = XYarray[Yind][Xind].X_Loc; 				 
				}
			}
			else if(Ref_Step<MAX_REFINMENT_STEPS-1)
			{
			//	if(SearchType==SEARCH_TYPE_MIN)  GetArrayIndexFromScanIndexandDirection(&Xind,&Yind,X_Min_Loc_ind,Y_Min_Loc_ind);
			//	else 							 GetArrayIndexFromScanIndexandDirection(&Xind,&Yind,X_Max_Loc_ind,Y_Max_Loc_ind);
				slowData->data1 = Refin_Loc_XY[k][l].Y;   
				fastData->data1 = Refin_Loc_XY[k][l].X; 
			
			}
			else if(Ref_Step==MAX_REFINMENT_STEPS-1) 
			{
				if(SearchType==SEARCH_TYPE_MIN)
				{
					slowData->data1 = Min_Location.Y;   
					fastData->data1 = Min_Location.X; 
				}
				else
				{
					slowData->data1 = Max_Location.Y;   
					fastData->data1 = Max_Location.X; 	
				}
			}
			else
			{
				boolBG=1;
				GetCtrlVal(PanelHandleMain,MAIN_PANEL_SPC_BAGROUND_LOCATION, &scanLoc);
				if(MOVE_ENABLE) MoveToBackground(scanLoc);
				Delay(0.1);
			}
			
			if (AltrPolCycles==ALTR_PIXEL_POL) LCRV_Set_Retardation(sData.wavelength,Pol_1, LCVR_CHAN);
			if(!boolBG)
			{
				if(MOVE_ENABLE) Micronixthreaded(fastData,MOTOR_MOVE_ABS);
				if(!l) 
				{
					if(MOVE_ENABLE) Micronixthreaded(slowData,MOTOR_MOVE_ABS);
					Delay(sData.StepTime/1000); //???????///
				}
				//update Scan Location///
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_CUR_X_POS, XYarray[Yind][Xind].X_Loc);
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_CUR_Y_POS, XYarray[Yind][Xind].Y_Loc);
			}
			/////////////////////////
		
			if(sData.StabTime) Delay(sData.StabTime/1000);
			
			LIA_Sen_Loop_maxTimes=0;
			curpol=1;
			
			do
			{
				if ((AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN)&&((Ref_Step==MAX_REFINMENT_STEPS-1)||boolBG)&&curpol>0) {LCRV_Set_Retardation(sData.wavelength,Pol_1, LCVR_CHAN); Delay(0.015); }
				if ((AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN)&&((Ref_Step==MAX_REFINMENT_STEPS-1)||boolBG)&&curpol<0) {LCRV_Set_Retardation(sData.wavelength,Pol_2, LCVR_CHAN); Delay(0.015); }  
				if (AltrPolCycles==ALTR_PIXEL_POL) LCRV_Set_Retardation(sData.wavelength,Pol_1, LCVR_CHAN);    
				EGNG_Sen_Status=0;
				SRS_Sen_Status=0;
				if(sData.AI_g1)
				{
					if ((AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN) && (curpol>0) && (Ref_Step==MAX_REFINMENT_STEPS-1)) { LCRV_Set_Retardation(sData.wavelength,Pol_1, LCVR_CHAN); Delay(0.015); }
					if ((AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN) && (curpol<0) && (Ref_Step==MAX_REFINMENT_STEPS-1)) {LCRV_Set_Retardation(sData.wavelength,Pol_2, LCVR_CHAN); Delay(0.015); }
					for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles*(Ref_Step+1); aquisitionLoop++)   
					{
						if(!DEBUG_MODE){
							DAQmxErrChk (DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
							
							GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
							DAQmxStopTask(DAQtask_G1);
						}
						else SimulateSigmal(pointData,SIM_2D_HOLE,CHAN_ALL,X_Points,Xind,Y_Points,Yind);
						
						if(!Ref_Step)AssignDaqDataTo_XYarrayChns(daqData, pointData,1,Yind,Xind,sData.MeasureCycles);
						else if (!boolBG && (!LIA_Sen_Loop_maxTimes || AltrPolCycles!=ALTR_LIA_LIKE_MAX_MIN)) AssignDaqDataTo_RefinmentPointData(Refinment_Step_data,daqData,pointData,1,sData.MeasureCycles*(Ref_Step+1));
						if ((AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN)&&(Ref_Step==MAX_REFINMENT_STEPS-1) &&(!boolBG)) AssignDaqDataTo_LIAsim_array(curpol , daqData,pointData,1,sData.MeasureCycles*(Ref_Step+1));
						else if (boolBG) AssignDaqDataTo_LIAsim_array(curpol*10 , daqData,pointData,1,sData.MeasureCycles*(Ref_Step+1)); 
					}
			  
				}
				
				if(sData.AI_g2)//Here you take the data for the second group.
				{
					if (AltrPolCycles==ALTR_PIXEL_POL) LCRV_Set_Retardation(sData.wavelength,Pol_2, LCVR_CHAN);
					Delay(0.015);
					for(aquisitionLoop=0; aquisitionLoop<MeasureCycles2*(Ref_Step+1); aquisitionLoop++)   
					{
						DAQmxErrChk (DAQmxStartTask(DAQtask_G2));
						GetDataFromDAQ(DAQtask_G2,sData.AI_g2 , nPoints_G2, pointData,sData.AI_g1);
						if(!Ref_Step )AssignDaqDataTo_XYarrayChns(daqData, pointData,2,Yind,Xind,MeasureCycles2);
						else if (!boolBG && (!LIA_Sen_Loop_maxTimes || AltrPolCycles!=ALTR_LIA_LIKE_MAX_MIN)) AssignDaqDataTo_RefinmentPointData(Refinment_Step_data,daqData,pointData,2,MeasureCycles2*(Ref_Step+1)); 
						else if ((AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN)&&(Ref_Step==MAX_REFINMENT_STEPS-1) &&(!boolBG)) AssignDaqDataTo_LIAsim_array(curpol , daqData,pointData,2,sData.MeasureCycles*(Ref_Step+1));
						else if (boolBG) AssignDaqDataTo_LIAsim_array(curpol*10 , daqData,pointData,2,sData.MeasureCycles*(Ref_Step+1)); 
						DAQmxStopTask(DAQtask_G2);
					}
				}	
				//check for LIA sensitivity Compatability//
				if(ModulationFlag && EGNG_R_chan>=0) 
				{	
					LIA_DATA_ERR_FLAG=0;
					if(pointData[EGNG_R_chan]>EGNG_R_max &&(EGNG_Sen_Status!=LIA_SEN_STATUS_OVERLOAD)) EGNG_R_max=pointData[EGNG_R_chan];
					if(pointData[EGNG_R_chan]>9.0 || LIA_OverloadCheck() ||pointData[EGNG_R_chan]<0.5 ) 
					{	
						LIA_DATA_ERR_FLAG=1;
						EGNG_Sen_Status=LIA_SEN_STATUS_OVERLOAD;
						if(!Ref_Step)ClearCurrentDataPointFromResultsArray(Yind,Xind);
						LIA_AutoSensitivity();
						//EGNG_Change_SensitivityBy(2);
						Delay(sData.StepTime*10/1000);
						LIA_Sens_Temp=-1; 
						LIA_Sens_Temp= EGNG_Read_Sensitivity_Double(); 
						Delay(0.1);
						if(LIA_Sens_Temp==EGNG_R_Sen_Double||LIA_Sens_Temp<0) 
						{	
							LIA_Sens_Temp= EGNG_Read_Sensitivity_Double();
							Delay(0.3);  
						}
						EGNG_R_Sen_Double= LIA_Sens_Temp;
						//Set Autophase??
						
					}
					
					
				}
				if(ModulationFlag && SRS_R_chan>=0)  
				{	
					if(pointData[SRS_R_chan]>SRS_R_max) SRS_R_max=pointData[SRS_R_chan];
					if(pointData[SRS_R_chan]>9.0|| SRS830_OverloadCheck() || pointData[SRS_R_chan]<0.5) 
					{	
						LIA_DATA_ERR_FLAG=1;
						if(pointData[SRS_R_chan]<0.5) 
						{
							SRS830_Change_SensitivityBy(-1);
						}
						else
						{
							SRS830_Change_SensitivityBy(2);
							//SRS830_LIA_AutoSensitivity(); 
							SRS_Sen_Status=LIA_SEN_STATUS_OVERLOAD;   
						}
						if(!Ref_Step) ClearCurrentDataPointFromResultsArray(Yind,Xind);
						Delay(sData.StepTime*10/1000);
						LIA_Sens_Temp= SRS830_Read_Sensitivity_Double();
						Delay(0.2);
						SRS830_Clear_Status_Bits();
						if(LIA_Sens_Temp==SRS_R_Sen_Double ||LIA_Sens_Temp<=0 ) 
						{
							Delay(0.3);
							LIA_Sens_Temp= SRS830_Read_Sensitivity_Double(); 
						}
						SRS_R_Sen_Double= LIA_Sens_Temp;
						//Set Autophase??
						
					}
					
					
				}
				
				LIA_Sen_Loop_maxTimes++;
				curpol*=-1;  
				///////////////////////////////////////////////////////////
			} while (((LIA_DATA_ERR_FLAG||(AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN))&&(Ref_Step>=MAX_REFINMENT_STEPS-1)) && LIA_Sen_Loop_maxTimes<MaxPointLoop);
	
			boolBG=0;
			if(Ref_Step)  for(z=0;z<MAX_DAQ_AI_CHAN;z++) Refinment_XY_Sum[z]+=XYarray[Yind][Xind].data[z];  
			
			if(!Ref_Step) PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan],XYarray[Yind][Xind].data[RefChan], MAIN_PANEL_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan] );
			
			if(PlotPointVal>maxVal) 
			{
				if(!Ref_Step)
				{
					Max_Location.X= XYarray[Yind][Xind].X_Loc;
					Max_Location.Y= XYarray[Yind][Xind].Y_Loc; 
					Max_Location.Z= XYarray[Yind][Xind].Z_Shift; 
					X_Max_Loc_ind =  Xind;
					Y_Max_Loc_ind =  Yind;
					maxVal=XY_ScanMax = PlotPointVal;
				}
				else if(SearchType==SEARCH_TYPE_MAX)
				{
					Max_Location.X= Refin_Loc_XY[k][l].X;
					Max_Location.Y= Refin_Loc_XY[k][l].Y; 
					AssignRefinmentDataTo_XYarray(daqData, Refinment_Step_data,Y_Max_Loc_ind,X_Max_Loc_ind); 
					maxVal=XY_ScanMax = PlotPointVal;
				}
				 
			}
			if(PlotPointVal<minVal) 
			{
				if(!Ref_Step)
				{
					Min_Location.X= XYarray[Yind][Xind].X_Loc;
					Min_Location.Y= XYarray[Yind][Xind].Y_Loc; 
					Min_Location.Z= XYarray[Yind][Xind].Z_Shift;
					X_Min_Loc_ind =  Xind;
					Y_Min_Loc_ind =  Yind;
					minVal= XY_ScanMin  = PlotPointVal;
				} 
				else if(SearchType==SEARCH_TYPE_MIN)
				{
					Min_Location.X= Refin_Loc_XY[k][l].X;
					Min_Location.Y= Refin_Loc_XY[k][l].Y; 
					AssignRefinmentDataTo_XYarray(daqData, Refinment_Step_data,Y_Min_Loc_ind,X_Min_Loc_ind); 
					minVal= XY_ScanMin  = PlotPointVal;
				}
			//	minVal= XY_ScanMin  = PlotPointVal; //
			}

			//if(DEBUG_MODE)  PointVal=10.0*Yind*Xind/Y_Points/X_Points;
				
			
			PlotScanPoint(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, PlotPointVal, Xind, Yind, graphScaleFactor); 
	
			if  (PlotChan2>=0 && PlotChan2<sData.AI_Number)
			{
				PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan2],XYarray[Yind][Xind].data[RefChan], SECONDARY_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan2] ); 
				PlotScanPoint(PanelHandelGraph2, PLOT_PANEL_XY_SCAN_PLOT_2, PlotPointVal, Xind, Yind, graphScaleFactor); 
			}
			
			while (ScanBreak ==SCAN_BREAK_PAUSE){} 
			if(ScanBreak==SCAN_BREAK_STOP) 
			{
				k=slowMax;
				l=fastMax;
			}
		if(!Ref_Step) for(z=0;z<MAX_DAQ_AI_CHAN ;z++) Refinment_Step_data[z]=0.0;	
		}//fast loop
	} //slow loop
	} //Go back to Max/Min position (in the case of max/min search scan) and refine steps to find the real minima	
	    
	
//Write data to files
	for(i=0;i<sData.AI_Number;i++) 
	{
			resFiles[i]=fopen(resFileNames[i], "a");
			WriteXY_FileHeader(resFiles[i], i);
			
			fprintf(resFiles[i],"Ypos\\Xpos(um)");
			for(l=0; l<X_Points;l++) fprintf(resFiles[i],"\t%0.8lf", 1000*XYarray[0][l].X_Loc);
			fprintf(resFiles[i],"\n\n");
			
			for(k=0; k<Y_Points;k++)
			{	
				fprintf(resFiles[i],"%0.8lf", 1000*XYarray[k][0].Y_Loc);
				for(l=0; l<X_Points;l++)	
				{
					fprintf(resFiles[i],"\t%0.8lf", XYarray[k][l].data[i]); 
				}
				fprintf(resFiles[i],"\n");
			}
			fclose(resFiles[i]);
	} 

//Writes plot1 chan (acording to the chosen equation) to file  
	resFiles[i]=fopen(resFileNames[i], "a");
	WriteXY_FileHeader(resFiles[i], i);
				
	fprintf(resFiles[i],"Ypos\\Xpos(um)");
	for(l=0; l<X_Points;l++) fprintf(resFiles[i],"\t%0.8lf", 1000*XYarray[0][l].X_Loc);
	fprintf(resFiles[i],"\n\n");
			
	int   Equation;
	GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_EQUATION_SELECT,&Equation);
	if(Equation!=EQUATION_NONE)
	{
		for(k=0; k<Y_Points;k++)
		{	
			fprintf(resFiles[i],"%0.8lf", 1000*XYarray[k][0].Y_Loc); 
			for(l=0; l<X_Points;l++)	
			{
				fprintf(resFiles[i],"\t%0.9lf", GetDisplayValFromData(XYarray[k][l].data[PlotChan],XYarray[k][l].data[RefChan],MAIN_PANEL_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan] )); 	
			}
			fprintf(resFiles[i],"\n");
		}
	}
	
	
	for(z=0;z<MAX_REFIN_ARR_SIDE;z++) free(Refin_Loc_XY[z]);
	free(Refin_Loc_XY);	
	fclose(resFiles[i]);
	free(daqData);
	free(fastData);
	free(slowData);
	DAQmxClearTask(DAQtask_G1);
	DAQmxClearTask(DAQtask_G2);
	
	//Compleat LIA Sensitivity validation//
	if(EGNG_R_chan>=0 && EGNG_Sen_Status!=LIA_SEN_STATUS_OVERLOAD) 
	{	
	
		if( EGNG_R_max> 8.5) EGNG_Sen_Status = LIA_SEN_STATUS_LOWER_SEN;
		else if( EGNG_R_max< 0.1) EGNG_Sen_Status = LIA_SEN_STATUS_UNDERLOAD;
		else if( EGNG_R_max< 1.5) EGNG_Sen_Status = LIA_SEN_STATUS_RAISE_SEN;
	}
	if(SRS_R_chan>=0 && SRS_Sen_Status!=LIA_SEN_STATUS_OVERLOAD)    
	{	
		if( SRS_R_max> 8.0) SRS_Sen_Status = LIA_SEN_STATUS_LOWER_SEN;
		else if( SRS_R_max< 0.1) SRS_Sen_Status = LIA_SEN_STATUS_UNDERLOAD;
		else if( SRS_R_max< 1.5) SRS_Sen_Status = LIA_SEN_STATUS_RAISE_SEN;
	}
	

	//////////////////////////////////////
	
	StopScanSequance_XY();
	
	return 0;	
	
Error:
	
return -1;
}
void AssignDaqDataTo_XYarrayChns(DAQtaskData *daqData,double *pointData,int group,int arrY_Pos,int arrX_Pos, int CollectionTimes)   // This function is called by the xy_scan function
{

	int k;
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)  
	{
		if(daqData[k].Dev_Status && daqData[k].Group==group && k==EGNG_R_chan)
			XYarray[arrY_Pos][arrX_Pos].data[k]+= (EGNG_R_Sen_Double * pointData[k]/EGNG_R_FULL_SCALE)/CollectionTimes;
		else if(daqData[k].Dev_Status && daqData[k].Group==group && k==SRS_R_chan) 
			XYarray[arrY_Pos][arrX_Pos].data[k]+= (SRS_R_Sen_Double * pointData[k]/SRS_R_FULL_SCALE)/CollectionTimes;
		else if(daqData[k].Dev_Status && daqData[k].Group==group) XYarray[arrY_Pos][arrX_Pos].data[k]+=pointData[k]/CollectionTimes; 
	}
}
void AssignDaqDataTo_SPCarrayChns(DAQtaskData *daqData,double *pointData,int group,int arrY_Pos,int arrX_Pos, int CollectionTimes)
{

	int k;
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)  
	{
		if(daqData[k].Dev_Status && daqData[k].Group==group && k==EGNG_R_chan)
			SPCarray[arrY_Pos][arrX_Pos].data[k]+= (EGNG_R_Sen_Double * pointData[k]/EGNG_R_FULL_SCALE)/CollectionTimes;
		else if(daqData[k].Dev_Status && daqData[k].Group==group && k==SRS_R_chan) 
			SPCarray[arrY_Pos][arrX_Pos].data[k]+= (SRS_R_Sen_Double * pointData[k]/SRS_R_FULL_SCALE)/CollectionTimes;
		else if(daqData[k].Dev_Status && daqData[k].Group==group) SPCarray[arrY_Pos][arrX_Pos].data[k]+=pointData[k]/CollectionTimes; 
	}
}
void AssignDaqDataTo_RefinmentPointData(double *RefinmentData , DAQtaskData *daqData,double *pointData,int group,int CollectionTimes)
{

	int k;
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)  
	{
		if(daqData[k].Dev_Status && daqData[k].Group==group && k==EGNG_R_chan)
			RefinmentData[k]+= (EGNG_R_Sen_Double * pointData[k]/EGNG_R_FULL_SCALE)/CollectionTimes;
		else if(daqData[k].Dev_Status && daqData[k].Group==group && k==SRS_R_chan) 
			RefinmentData[k]+= (SRS_R_Sen_Double * pointData[k]/SRS_R_FULL_SCALE)/CollectionTimes;
		else if(daqData[k].Dev_Status && daqData[k].Group==group) RefinmentData[k]+=pointData[k]/CollectionTimes; 
	}
}
void AssignRefinmentDataTo_XYarray(DAQtaskData *daqData,double *pointData,int arrY_Pos,int arrX_Pos)
{

	int k;
	for (k=0;k<MAX_DAQ_AI_CHAN;k++)  
	{
		if(daqData[k].Dev_Status) XYarray[arrY_Pos][arrX_Pos].data[k]=pointData[k]; 
	}
}
int CVICALLBACK f_scan_emr_stop (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			ScanBreak=SCAN_BREAK_STOP;
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			Auto Focus   		///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

void BG_AF(int AF_mode, int Wavelength, int AOTF_num , int index , int wavelength_array_size)
{
	double ZCurrnt;
	
	switch (AF_mode)
	{
		case 1:
			f_AutoFocus();
			break;
		case 2:
			f_AutoFocus();
			break;
		case 3:
			f_AutoFocus();
			break;
		case AF_CURVE_ASSISTED_X50:
			ZCurrnt=MicronixPOS_Query(Z_AXIS);
			MicronixParam->Axis=Z_AXIS;
			MicronixParam->data1=ZCurrnt-AF_Z_Curve_Adjusment(Wavelength,AOTF_num,AF_mode );
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			break;
		case AF_CURVE_ASSISTED_X100:
			ZCurrnt=MicronixPOS_Query(Z_AXIS);
			MicronixParam->Axis=Z_AXIS;
			MicronixParam->data1=ZCurrnt-AF_Z_Curve_Adjusment(Wavelength,AOTF_num,AF_mode );
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			break;
		
		case 6:
			Move_Micronix_Af(Equated_AF(Wavelength , index , wavelength_array_size));
			
	}
	
	/*if(AF_active)  
	{	
		f_AutoFocus();
	}
	if (AF_active==AF_CURVE_ASSISTED_X50 || AF_active == AF_CURVE_ASSISTED_X100) 
	{
		ZCurrnt=MicronixPOS_Query(Z_AXIS);
		MicronixParam->Axis=Z_AXIS;
		MicronixParam->data1=ZCurrnt-AF_Z_Curve_Adjusment(Wavelength,AOTF_num,AF_active );
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	}*/
	if(AF_mode && TRANSMISSION_MODE && (AF_mode !=6) )  fAF_Transmission();	
	
}


double Equated_AF(int target_wavelength, int wavelength_array_index , int wavelength_array_size){  //af_adjustment = c+b1*wavelength + b2*wavelength^2 - This function is being called if you use the autofocus during spectral scan
	double af_adjustment=0, prev_location=0, target_location=0, c=0.00139,B1=5.39623*pow(10,-6) , B2=-5.1404*pow(10,-9);
	int prev_wavelength=0;
	//WavelengthArray[i].Wavelength
	if(wavelength_array_index == wavelength_array_size-1) prev_wavelength = AF_WAVELENGTH_BASELINE;		
	else prev_wavelength = WavelengthArray[wavelength_array_index+1].Wavelength;
	
	prev_location = c + B1*prev_wavelength + B2*pow(prev_wavelength,2);
	target_location = c + B1*target_wavelength + B2*pow(target_wavelength,2);
	af_adjustment = target_location - prev_location;
	
	return -af_adjustment;
}

double simple_Equated_AF(void){ //This function is being called if you use the autofocus button
	double af_adjustment=0, prev_location=0, target_location=0, c=0.00139,B1=5.39623*pow(10,-6) , B2=-5.1404*pow(10,-9);
	int prev_wavelength=0, target_wavelength;
	GetCtrlVal (PanelHandleMain, MAIN_PANEL_WAVELENGTH_INDICATOR, &target_wavelength);
	prev_wavelength = AF_WAVELENGTH_BASELINE;		
	
	prev_location = c + B1*prev_wavelength + B2*pow(prev_wavelength,2);
	target_location = c + B1*target_wavelength + B2*pow(target_wavelength,2);
	af_adjustment = target_location - prev_location;
	
	return -af_adjustment;		
}

void Move_Micronix_Af(double af_adjustment)
{
	
	MicronixParam->Axis=Z_AXIS;
	MicronixParam->data1=af_adjustment;
	Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);	
}

void Move_PI_Af(double af_adjustment)
{
	PI_Param->data1=af_adjustment;
	PI_threaded(PI_Param,PI_MOVE_ABS);	
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			SPECTRAL 		///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int GetMaxPowerFromAotf(int dev ,int aotf_VIS_maxP,int aotf_NIR_maxP,int aotf_NIR2_maxP)
{
	switch (dev)
	{
		case VIS:
			return aotf_VIS_maxP;
		case NIR:
			return aotf_NIR_maxP;
		case NIR2:
			return aotf_NIR2_maxP;
			
	}
	return 0;
}

int GetSpectralWavelengthData() //This function is being called by the spectral scan and it is used to fill the WavelengthArray global variable with the wavelengths needed, what spectral line to use and the number of scans. it returns the number of scans.,
{
	int count,i=0,size=0;
	int waveMin1=0, waveMax1=0, res1=0, aotf1=0, size1=0;
	int waveMin2=0, waveMax2=0, res2=0, aotf2=0, size2=0; 
	int waveMin3=0, waveMax3=0, res3=0, aotf3=0, size3=0; 
	int waveMin4=0, waveMax4=0, res4=0, aotf4=0, size4=0;
	int aotf_VIS_maxP=2800,aotf_NIR_maxP=2800,aotf_NIR2_maxP=2800;
	int aotf_1_maxP=2800,aotf_2_maxP=2800,aotf_3_maxP=2800,aotf_4_maxP=2800;
	
	//GetCtrlVal(PanelHandleMain,MAIN_PANEL_VIS_AOTF_POWER_CH0,&aotf_VIS_maxP);
//	GetCtrlVal(PanelHandleMain,MAIN_PANEL_NIR_AOTF_POWER_CH0,&aotf_NIR_maxP);
//	GetCtrlVal(PanelHandleMain,MAIN_PANEL_NIR2_AOTF_POWER_CH0,&aotf_NIR2_maxP);
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_1,&aotf1);//This ifs here check which line to use in the spectral menu.
	if(aotf1)
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_1,&waveMin1);//Wavemin gets the minimum wavelength
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_1,&waveMax1);//Wavemax gets the maximum wavelength	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_1,&res1);//res is the resolution between each wavelength step.	
		size1 =  (waveMax1-waveMin1)/res1;
		if (!((waveMax1-waveMin1)%res1)) size1++;
		aotf_1_maxP=GetMaxPowerFromAotf(aotf1,aotf_VIS_maxP,aotf_NIR_maxP,aotf_NIR2_maxP);
		
	}
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_2,&aotf2);
	if(aotf2)	
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_2,&waveMin2);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_2,&waveMax2);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_2,&res2);	
		size2 = (waveMax2-waveMin2)/res2;
		if (!((waveMax2-waveMin2)%res2)) size2++;
		aotf_2_maxP= GetMaxPowerFromAotf(aotf2,aotf_VIS_maxP,aotf_NIR_maxP,aotf_NIR2_maxP);
	}

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_3,&aotf3);
	if(aotf3)	
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_3,&waveMin3);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_3,&waveMax3);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_3,&res3);	
		size3 = (waveMax3-waveMin3)/res3;
		if (!((waveMax3-waveMin3)%res3)) size3++;
		aotf_3_maxP= GetMaxPowerFromAotf(aotf3,aotf_VIS_maxP,aotf_NIR_maxP,aotf_NIR2_maxP); 
	}

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AOTF_WAVE_4,&aotf4);
	if(aotf4)	
	{
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_4,&waveMin4);
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_4,&waveMax4);	
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_4,&res4);	
		size4 = (waveMax4-waveMin4)/res4;
		if (!((waveMax4-waveMin4)%res4)) size4++;
		aotf_4_maxP= GetMaxPowerFromAotf(aotf4,aotf_VIS_maxP,aotf_NIR_maxP,aotf_NIR2_maxP); 
	}
	size=size1+size2+size3+size4;//Final size of all the wavelength combined.
	WavelengthArray = (SpectralPoint*) calloc(size, sizeof(SpectralPoint));//Create the wavelength array as size. 
	
	count=0; 
	if(aotf1)
		for(i=size1-1; i>=0;i--) //Starts filling the array from 
			if((waveMax1-count*res1)>=waveMin1) 
			{	
				WavelengthArray[i].Wavelength=waveMax1-count*res1;
				WavelengthArray[i].AOTF_num= aotf1;
				WavelengthArray[i].RF_Power= GetAOTF_Power(WavelengthArray[i].Wavelength,aotf1,aotf_1_maxP);//This function does nothing. it returns aotf_1_maxP
				count++;
			}
	count=0;
	if(aotf2)
		for(i=size2-1; i>=0;i--)
			if((waveMax2-count*res2)>=waveMin2) 
			{	
				WavelengthArray[i].Wavelength=waveMax2-count*res2;
				WavelengthArray[i].AOTF_num=aotf2;
				WavelengthArray[i].RF_Power= GetAOTF_Power(WavelengthArray[i].Wavelength,aotf2,aotf_2_maxP);//This function does nothing. it returns aotf_2_maxP
				count++;
			}
	count=0;
	if(aotf3)
		for(i=size3-1; i>=0;i--)
			if((waveMax3-count*res3)>=waveMin3) 
			{	
				WavelengthArray[i].Wavelength=waveMax3-count*res3;
				WavelengthArray[i].AOTF_num=aotf3;
				WavelengthArray[i].RF_Power= GetAOTF_Power(WavelengthArray[i].Wavelength,aotf3,aotf_3_maxP);
				count++;
			}
	count=0;
	if(aotf4)
		for(i=size4-1; i>=0;i--)
			if((waveMax4-count*res4)>=waveMin4) 
			{	
				WavelengthArray[i].Wavelength=waveMax4-count*res4;
				WavelengthArray[i].AOTF_num=aotf4;
				WavelengthArray[i].RF_Power= GetAOTF_Power(WavelengthArray[i].Wavelength,aotf4,aotf_4_maxP);
				count++;
			}
	return size;
}
int GetPOWERControlFromNameSTR(char *Str)
{
int len,test1,result=-1;
char Zero='0';
	len=strlen(Str);
	test1=(Str[len-1])-(int)Zero;
	switch(len)
	{
		case 20:
			switch(test1)
			{
				case 1: return  AOTF_SETTI_W_LIMIT_1;
				case 2: return  AOTF_SETTI_W_LIMIT_2;
				case 3: return  AOTF_SETTI_W_LIMIT_3;
				case 4: return  AOTF_SETTI_W_LIMIT_4;
			}

		case 25:
			switch(test1)
			{
				case 1: return  AOTF_SETTI_W_LIMITPOWER_1;
				case 2: return  AOTF_SETTI_W_LIMITPOWER_2;
				case 3: return  AOTF_SETTI_W_LIMITPOWER_3;
				case 4: return  AOTF_SETTI_W_LIMITPOWER_4;
			}			
 		
		case 26:
			switch(test1)
			{
				case 1: return AOTF_SETTI_SET_PWR_LIMIT_1;
				case 2: return AOTF_SETTI_SET_PWR_LIMIT_2;
				case 3: return AOTF_SETTI_SET_PWR_LIMIT_3;
				case 4: return AOTF_SETTI_SET_PWR_LIMIT_4;
			}			
	}
	return result;	
}
void  GetWavelengthMaxPower(int pos,int limit_source) 
{
	int WevelengthLimit[4]={0},PowerLimit[4]={0};
	int State[4]={0};
	int k,LimitPos;
	char cStateStr[200]="",cPowerStr[200]="" ,cWavelengthStr[200]="";
	
	WavelengthArray[pos].RF_Power=2000;
	if (limit_source==0){
		for (k=1;k<=4;k++)
		{
			sprintf(cStateStr,"AOTF_SETTI_SET_PWR_LIMIT_%d",k);
			GetCtrlVal(PanelHandelAOTFSettings, GetPOWERControlFromNameSTR(cStateStr) ,&State[k-1]); 
		
			sprintf(cPowerStr,"AOTF_SETTI_W_LIMITPOWER_%d",k);
			GetCtrlVal(PanelHandelAOTFSettings, GetPOWERControlFromNameSTR(cPowerStr) ,&PowerLimit[k-1]) ;
		
			sprintf(cWavelengthStr,"AOTF_SETTI_W_LIMIT_%d",k);
			GetCtrlVal(PanelHandelAOTFSettings, GetPOWERControlFromNameSTR(cWavelengthStr) ,&WevelengthLimit[k-1]);
		
			if(WavelengthArray[pos].Wavelength>WevelengthLimit[k-1]) 
			{	
				WavelengthArray[pos].RF_Power=PowerLimit[k-1];
				break;
			}
		} //for
	}		   //if
	else{
			
		WavelengthArray[pos].RF_Power =1500;
		if(WavelengthArray[pos].Wavelength>650)
			   WavelengthArray[pos].RF_Power =600;
		else if(WavelengthArray[pos].Wavelength>629)
			   WavelengthArray[pos].RF_Power =700;
		else if(WavelengthArray[pos].Wavelength>614)
			   WavelengthArray[pos].RF_Power =800;
		else if(WavelengthArray[pos].Wavelength>599)
			   WavelengthArray[pos].RF_Power =900;
		else if(WavelengthArray[pos].Wavelength>574)
			   WavelengthArray[pos].RF_Power =1000;
		else if(WavelengthArray[pos].Wavelength>549)
			   WavelengthArray[pos].RF_Power =1200;
		else if(WavelengthArray[pos].Wavelength>499)
			   WavelengthArray[pos].RF_Power =1700;
		else if(WavelengthArray[pos].Wavelength<499)
			   WavelengthArray[pos].RF_Power =2500;
	}
	
		
	
}
void SetWavelength_PowerNotMonitored ( SpectralPoint CurPoint)  
{
	int Dev, AOTFchan=0;

	double Freq;	
	
	//Set_AOTF_ALL_Zero(); I added remakrs
	Dev= GetAOTFdevID_From_aotf_type(CurPoint.AOTF_num);
	Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength);
	
	if (ActiveAOTF != CurPoint.AOTF_num)
	{	
		char config_msg[120]="Please change system state to the current AOTF configuration: ";
		char tmpSTR[3]="";
			   
		sprintf(tmpSTR,"%d " ,CurPoint.AOTF_num);
		strcat(config_msg,tmpSTR);
		strcat(config_msg,"\n Reminder: 1-vis, 2- nir, 3-nir2");
		
		ConfirmPopup ("System State", config_msg);
	 	ActiveAOTF= CurPoint.AOTF_num;
	}
	
	Set_AOTF_freq_gain(Dev,AOTFchan,Freq, 1500); 
	
}
void  SetCurrentWavelength( SpectralPoint CurPoint)  // This function is being called by the f_start_scan and the f-start_spectral. its main 
{
	int Dev, AOTFchan=0,sign=1,WavelengthOffset=0;
	double powerTest=0.0,powerLast=0.0;
	double Freq;
	double ZCurrnt;
	double maxVoltageReading,minVoltageReading;
	char daqChan[50]="";
	int PowerStep=100, curPower=500;
	
	if (CurPoint.Wavelength >500)
	{
		PowerStep=50, curPower=300;	
	}
	
	//Set_AOTF_ALL_Zero(); I added Remakrs
	
	Dev= GetAOTFdevID_From_aotf_type(CurPoint.AOTF_num);//This function gets the real aotf id.
	Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength);
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_0 ,daqChan);
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_SET_MAX_VOLTAGE ,&maxVoltageReading); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_SET_MIN_VOLTAGE ,&minVoltageReading);
	 
	while((curPower+PowerStep<=CurPoint.RF_Power) && fabs(powerTest) <maxVoltageReading) //While the current power is smaller than the maximum power and the voltage reading is smaller than the voltage reading.
	{
		curPower+=PowerStep;
		Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength);
		Set_AOTF_freq_gain(Dev,AOTFchan,Freq, curPower);
		powerTest = ReadDaqChan(daqChan);
		if (powerTest<powerLast)
			{
			curPower-=PowerStep;
			Set_AOTF_freq_gain(Dev,AOTFchan,Freq, curPower);
			break;
			}
		else powerLast=powerTest;
	}

	//Add extraChannels for 465-430??
	while (powerTest<minVoltageReading && AOTFchan<4)
	{
		AOTFchan++;
		WavelengthOffset=((int)((AOTFchan-1)/2)+1)*sign;  
		Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength+WavelengthOffset);  
		Set_AOTF_freq_gain(Dev,AOTFchan,Freq,2000);
		powerTest = ReadDaqChan(daqChan);
		sign=-sign;
		if (powerTest<powerLast)
		{
			Set_AOTF_freq_gain(Dev,AOTFchan,Freq, 0);
			break;
		}
		else powerLast=powerTest; 
	}

	//////
	SetCtrlVal(PanelHandleMain, MAIN_PANEL_WAVELENGTH_INDICATOR ,CurPoint.Wavelength); 
	sData.wavelength=CurPoint.Wavelength;
	if(PEM_STATUS) 
	{	
		int ret; 
		GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&ret); 
		PEM_change_Wavelength(CurPoint.Wavelength,ret);
	}
}
void  SetCurrentWavelength_Const( SpectralPoint CurPoint, int ShutDownAOTFs)
{
	int Dev, AOTFchan=0;
	double powerTest=0.0;
	double Freq,Freq1,Freq2;

	
	
	
	if (ActiveAOTF != CurPoint.AOTF_num)
	{	
		char config_msg[120]="Please change system state to the current AOTF configuration: ";
		char tmpSTR[3]="";
			   
		sprintf(tmpSTR,"%d " ,CurPoint.AOTF_num);
		strcat(config_msg,tmpSTR);
		strcat(config_msg,"\n Reminder: 1-vis, 2- nir, 3-nir2");
		
		ConfirmPopup ("System State", config_msg);
	 	ActiveAOTF= CurPoint.AOTF_num;
	}
	
	if (ShutDownAOTFs) Set_AOTF_ALL_Zero();
	
	Dev= GetAOTFdevID_From_aotf_type(CurPoint.AOTF_num);
	Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength);
	
	if(CurPoint.RF_Power)	Set_AOTF_freq_gain(Dev,AOTFchan,Freq, CurPoint.RF_Power);
	else 					Set_AOTF_freq(Dev,AOTFchan,Freq);
	
	if(CurPoint.Wavelength<520) //add more chanels
	{
		Freq1=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength+1);
		if(CurPoint.RF_Power)	Set_AOTF_freq_gain(Dev,AOTFchan,Freq1, CurPoint.RF_Power);
		else 					Set_AOTF_freq(Dev,AOTFchan+1,Freq1);
		
		if(CurPoint.RF_Power)	Set_AOTF_freq_gain(Dev,AOTFchan,(Freq+Freq1)/2, CurPoint.RF_Power);
		else 					Set_AOTF_freq(Dev,AOTFchan+2,(Freq+Freq1)/2);
	
		
		Freq2=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength-1);
		if(CurPoint.RF_Power)	Set_AOTF_freq_gain(Dev,AOTFchan,Freq2, CurPoint.RF_Power);
		else 					Set_AOTF_freq(Dev,AOTFchan+3,Freq2);	
		
		if(CurPoint.RF_Power)	Set_AOTF_freq_gain(Dev,AOTFchan,(Freq+Freq2)/2, CurPoint.RF_Power);
		else 					Set_AOTF_freq(Dev,AOTFchan+4,(Freq+Freq2)/2);
		
	}
	

	//////
	SetCtrlVal(PanelHandleMain, MAIN_PANEL_WAVELENGTH_INDICATOR ,CurPoint.Wavelength); 
	sData.wavelength=CurPoint.Wavelength;
}
int MoveToBackground(int Loc)//This function is being called by the spectral scan, and it is used to move the stage to the background point.
{
	int res=0;
	
	if (Micronix_Online) 
	{	res=MoveToLocation(Loc,BACKGROUND_LOC);	
		if(sData.StabTime) Delay(sData.StabTime/1000);
	}
	
	return res;
}

void BG_PowerBalance(int powerBalance_active)	 //This function is being called if the power balance check box is on while taking a spectrum.
{
	int tmp=0,user_intervention;
	double  tolerance;
	double time1, time2;
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,&tolerance); //Get the tolerance value.
	
	if(powerBalance_active) // If the powerBalance check box is on continue, else .	
	{	tmp= SetPowerBalance(tolerance); // Call the function which does...
		
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_ENABLE_USER_CONTROL,&user_intervention);
		if (tmp<-2 && user_intervention) 
		{   
			PanelHandlePopup = LoadPanel (0, "MIC_V2.uir", USER_PROM);
			InstallPopup(PanelHandlePopup);
			SetCtrlAttribute (PanelHandlePopup, USER_PROM_POPUP_TIMER, ATTR_ENABLED, 1);
			SetCtrlAttribute (PanelHandlePopup, USER_PROM_POPUP_TIMER_COUNT, ATTR_ENABLED, 1); 
			
			
			popup_confirm=0;
			time1=Timer();
			time2=Timer();
			while(!popup_confirm && (time2-time1)<400){ DelayWithEventProcessing(0.1);  time2=Timer();}
			 
		}
		
		if (EGNG_LIA_Online && ModulationFlag) 
		{
			LIA_AutoPhase();
			Delay(0.2);
			
		
		}
		if (SRS_LIA_Online && ModulationFlag) 
		{
			SRS830_LIA_AutoPhase();
			Delay(0.2);
		}
	}	
}
/*
void MoveToBG_AFandBalanceSet(int powerBalance_active, int AF_active, int Loc, SpecPoint SpectralPoint)
{
	int tmp=0,user_intervention;
	double  tolerance;
	double time1, time2;
	double ZCurrnt;
	
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,&tolerance);
	if(powerBalance_active||AF_active)
		if (Micronix_Online) MoveToLocation(Loc,BACKGROUND_LOC); 
	

	if(sData.StabTime) Delay(sData.StabTime/1000);
	
	if(AF_active)  
	{	
		f_AutoFocus();
	}
	if (AF_active>=AF_CURVE_ASSISTED_X50) 
	{
		ZCurrnt=MicronixPOS_Query(Z_AXIS);
		MicronixParam->Axis=Z_AXIS;
		MicronixParam->data1=ZCurrnt-AF_Z_Curve_Adjusment(SpecPoint.Wavelength, SpecPoint.AOTF_num,AF_active );
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	}
	if(AF_active && TRANSMISSION_MODE )  fAF_Transmission(); 
	
	if(powerBalance_active)	
	{	tmp= SetPowerBalance(tolerance);
		if (tmp<0 ) tmp= SetPowerBalance(tolerance);
		
		GetCtrlVal(PanelHandleMain,MAIN_PANEL_ENABLE_USER_CONTROL,&user_intervention);
		if (tmp<-2 && user_intervention) 
		{   
			PanelHandlePopup = LoadPanel (0, "MIC_V2.uir", USER_PROM);
			InstallPopup(PanelHandlePopup);
			SetCtrlAttribute (PanelHandlePopup, USER_PROM_POPUP_TIMER, ATTR_ENABLED, 1);
			SetCtrlAttribute (PanelHandlePopup, USER_PROM_POPUP_TIMER_COUNT, ATTR_ENABLED, 1); 
			
			
			popup_confirm=0;
			time1=Timer();
			time2=Timer();
			while(!popup_confirm && (time2-time1)<400){ DelayWithEventProcessing(0.1);  time2=Timer();}
			 
		}
		
		
		if (EGNG_LIA_Online) 
		{
		//	LIA_AutoOffset();
		//	Delay(0.2);
		//	LIA_AutoPhase();
		//	Delay(0.2);
		
		}
		if (SRS_LIA_Online) 
		{
		//	SRS830_LIA_AutoPhase();
		//	Delay(0.2);
		}	
	}
	GetBackgroundValues();
	
}*/
void MoveToScanOrigin(int scanLoc,int pSearchType)
{
	if (!MOVE_ENABLE) return;
	switch(	pSearchType)
	{
		case SEARCH_TYPE_ORIGIN: 
			MoveToLocation(scanLoc,SCAN_LOC); 
			return;
		
		case SEARCH_TYPE_MIN:
			sData.x0=Min_Location.X;
			sData.y0=Min_Location.Y;
			
			MicronixParam->Axis=X_AXIS;
			MicronixParam->data1=Min_Location.X;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			MicronixParam->Axis=Y_AXIS;
			MicronixParam->data1=Min_Location.Y;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			break;
			
		case SEARCH_TYPE_MAX:
			sData.x0=Max_Location.X;
			sData.y0=Max_Location.Y;
			
			MicronixParam->Axis=X_AXIS;
			MicronixParam->data1=Max_Location.X;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			MicronixParam->Axis=Y_AXIS;
			MicronixParam->data1=Max_Location.Y;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			break;
			
		
	}
	
	
}
void AdjustFileNameToCurrentWavelength(int wavelength, char *name)
{
	char tmpStr[6]; 					
	
	strcpy(sData.FileName,name);
	strcat(sData.FileName,"W");
	sprintf(tmpStr,"%d",wavelength);
	strcat(sData.FileName,tmpStr);	
}

void  GetSpectralScanSettings(int *AFcorection, int *powerBalanceCorection, int *scanLoc  ,int *pSearchType, int *AltrPolCycles, int *Pol_1, int *Pol_2,int *VLimit,int PanelHandleMain)
{
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AF_ON_SCAN, AFcorection);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SPLIT_PWR_STEP_ADJ, powerBalanceCorection); //BG Power balance Checkbox.
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SPC_BAGROUND_LOCATION, scanLoc); //Gets the scan location from the numberic in the button right of the spectral menu (bottom right).
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SEARCH_TYPE_MAX_MIN, pSearchType);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_ALTR_SCAN_SET, AltrPolCycles);//Get the type of scan From the scan set buttons. 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_1, Pol_1);//Changing polarisation using the liquid crystal... no longer valid.
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_2, Pol_2); 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SET_VOLTAGE_LIMIT, VLimit);//Checkbox near the max voltage. 
	GetXYScanData(PanelHandleMain);
	
	SaveLocation(0,BACKGROUND_LOC);	
}
FILE* CreateSpecSummeryFile(char *FileNameSum) // This function creates the first file in a spectrum (The SpecSum) This function is being called by f_start_spectra. .
{
	int i,ibool=0,aux;
	char tmp[512];
	FILE *pFile;
	 
	MakeFile(FileNameSum);
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_ALTR_SCAN_SET,&aux);
	if(aux==ALTR_LIA_LIKE_MAX_MIN) ibool=1;
	
	pFile=fopen(FileNameSum, "a"); 
	fprintf(pFile,"Wavelength[nm]\t");
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile,"BG_Val%d\t" , i);
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile,"Min_Val%d\t" , i);
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile,"Max_Val%d\t" , i);
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile,"RefinSum%d\t" , i);
	
	if(ibool)
	{
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile,"BK_Pol1_%d\t" , i); 
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile,"BK_Pol2_%d\t" , i); 
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile,"Pol1_%d\t" , i); 
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile,"Pol2_%d\t" , i);
	}
	
	fprintf(pFile,"\n");
	fclose(pFile);
	return pFile;
	
}
void AddLineToSummeryFile(char *fileName,  double min, double max, int wavelength)
{
 
 FILE *pFile;
 int i,ibool=0,aux;

	pFile=fopen(fileName, "a");
	fprintf(pFile,"%d \t" , wavelength);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_ALTR_SCAN_SET,&aux);
	if(aux==ALTR_LIA_LIKE_MAX_MIN) ibool=1;
	
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile, "%lf\t" , BackgroundVals[i]);
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile, "%lf\t" , XYarray[Y_Min_Loc_ind][X_Min_Loc_ind].data[i]);
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile, "%lf\t" , XYarray[Y_Max_Loc_ind][X_Max_Loc_ind].data[i]);
	for(i=0; i<sData.AI_Number; i++)
		fprintf(pFile, "%lf\t" , Refinment_XY_Sum[i]);
	
	if(ibool)
	{
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile, "%lf\t" , pol_LIA_disp_diff[0][i]); 
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile, "%lf\t" , pol_LIA_disp_diff[1][i]); 
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile, "%lf\t" , pol_LIA_disp_diff[2][i]);
		for(i=0; i<sData.AI_Number; i++) 
			fprintf(pFile, "%lf\t" , pol_LIA_disp_diff[3][i]);
	}
	fprintf(pFile, "\n");
	fclose(pFile);
	
	
}
void SetCurPolState(int CurState,int Pol_1,int Pol_2, int wavelength)//This function is being called by the 
{
	double Pol_1_V,Pol_2_V;
	
	
	if(CurState>0)
		if (Pol_1<CUSTOM_VOLTAGE) LCRV_Set_Retardation (wavelength,  Pol_1,  LCVR_CHAN); 
		else	{ 
					GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_1,&Pol_1_V); 
					LCVR_Set_Modulation_V (LCVR_CHAN, Pol_1_V); 
				}

	else
		if (Pol_2<CUSTOM_VOLTAGE) LCRV_Set_Retardation (wavelength,  Pol_2,  LCVR_CHAN);
		else	{ 
					GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_2,&Pol_2_V); 
					LCVR_Set_Modulation_V (LCVR_CHAN, Pol_2_V); 
				}
}
int  OptimizeParticleLocation(char *daqChanStr )
{
	int StepSizeInt=30,maxSteps=15,NumCycls=3,i_min,i,j,aquisitionLoop,freq,samps;
	double MinVal=10,curVal=0;
	double stepSize;
	double StartPos[2], tmpPos[2] ,MinPos[2]; //0 X, 1 Y
	DAQtaskData data;
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'};
    TaskHandle 	 PowerDAQtask=NULL;
	double pointdata;
	
	
	data.maxIn=10;
	freq=150000;
	samps=4000;

	stepSize=1.0*StepSizeInt/1000000; //50nm in mm.

	StartPos[0]=MicronixPOS_Query(X_AXIS);
	MinPos[0]=StartPos[0];
	Delay(0.02);
	StartPos[1]=MicronixPOS_Query(Y_AXIS);
	MinPos[1]=StartPos[1];
	tmpPos[0]=StartPos[0];
	tmpPos[1]=StartPos[1];  
	   
	DAQmxErrChk(DAQmxCreateTask("ReadChan2", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, daqChanStr,  "Chan", DAQmx_Val_RSE, -10, 10, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));	

	DAQmxStartTask(PowerDAQtask);
	GetDataFromDAQ(PowerDAQtask, 1, samps, &pointdata,0);
	DAQmxStopTask(PowerDAQtask);
	MinVal=pointdata; 

	
for(j=0;j<4;j++)
{
	if(j==0 || j==2)MicronixParam->Axis=X_AXIS;  
	else	MicronixParam->Axis=Y_AXIS;   
	
	i_min=1;
	for(i=0;i<=maxSteps;i++)
	{
		if(!GlobalTrackingState) break;
		MicronixParam->data1=tmpPos[j%2]+stepSize*i;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
		curVal=0;
		
		for(aquisitionLoop=0;aquisitionLoop<NumCycls;aquisitionLoop++)
		{
			DAQmxErrChk (DAQmxStartTask(PowerDAQtask));
			GetDataFromDAQ(PowerDAQtask, 1, samps, &pointdata,0);
			DAQmxStopTask(PowerDAQtask);
			curVal+=pointdata/NumCycls;
		}
		
		
		if((curVal)<(MinVal))
		{
			if(j==0 || j==2)MinPos[0]=MicronixPOS_Query(X_AXIS); 
			else	MinPos[1]=MicronixPOS_Query(Y_AXIS);           
			
			MinVal=pointdata;
			i_min=i;
		}
		else
			if((i-i_min)>2) break;	
	}
	i_min=-1; 
	for(i=0;i>=-maxSteps;i--)
	{
		if(!GlobalTrackingState) break; 
		MicronixParam->data1=tmpPos[j%2]+stepSize*i;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
		curVal=0;
		
		for(aquisitionLoop=0;aquisitionLoop<NumCycls;aquisitionLoop++)
		{
			DAQmxErrChk (DAQmxStartTask(PowerDAQtask));
			GetDataFromDAQ(PowerDAQtask, 1, samps, &pointdata,0);
			DAQmxStopTask(PowerDAQtask);
		 	curVal+=pointdata/NumCycls;
		}
		
		if( (curVal)<(MinVal))
		{
			if(j==0 || j==2)MinPos[0]=MicronixPOS_Query(X_AXIS); 
			else	MinPos[1]=MicronixPOS_Query(Y_AXIS); 
			
			MinVal=pointdata;
			i_min=i;
		}
		else if(abs(i-i_min)>2) break;
	}
	tmpPos[j%2]=MinPos[j%2];
	MicronixParam->data1=tmpPos[j%2];
	Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
		
}
		MicronixParam->Axis=X_AXIS ;
		MicronixParam->data1=MinPos[0];
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);	
		Delay(0.02);
		MicronixParam->Axis=Y_AXIS ;
		MicronixParam->data1=MinPos[1];
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);	
	
Error:	
	DAQmxClearTask(PowerDAQtask);
	return 0;	
	
}

int CVICALLBACK f_simple_spc (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			FILE *specFile;  
			int scanNum,tmp, curWavelength,arrSize=1,MeasureCycles2=1,LoopMax;
			int AFcorection,powerBalanceCorection,scanLoc,pSearchType,AltrPolCycles, Pol_1,Pol_2,ExpTimeLimit ;
			double ExpLimitDelay;
			char FileNameConst[MAX_FILE_NAME_LENGTH]="", FileNameSum1[MAX_FILE_NAME_LENGTH]="", FileNameSum2[MAX_FILE_NAME_LENGTH]="",FileNametmp[MAX_FILE_NAME_LENGTH]="";
			int VoltageLimit=0,z;
			double pointData[MAX_DAQ_AI_CHAN]={0.0} ;
			TaskHandle DAQtask_G1=0,DAQtask_G2=0;
			int nPoints_G1, nPoints_G2,daqAux;
			DAQtaskData *daqData=NULL;
			int32 error=0;
			int32 DAQmxError = DAQmxSuccess;
			int i,j,k,aquisitionLoop,PixelLoop,EnableLocOptimization=0,MonitorChan;
			double Z_Drift=0;
			XY_Point  Samp_Loc;
			char TrackingChan[50]="";
			
			if(control==ADV_SCAN_S_START_SPECTRAL_SCAN_B) j=0; else j=1;
	   
			GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType,&AltrPolCycles, &Pol_1,&Pol_2 ,&VoltageLimit,PanelHandleMain);
			X_TMP=Y_TMP=-1;
			
			
			GetCtrlVal(panel,control,&tmp); 
			GetCtrlVal(panel,ADV_SCAN_S_LIMIT_EXPOSURE,&ExpTimeLimit);  
			GetCtrlVal(panel,ADV_SCAN_S_EXP_DELAY,&ExpLimitDelay);
			GetCtrlVal(panel,ADV_SCAN_S_DAQ_MIN_CHAN, TrackingChan);
			
			GetCtrlVal(PanelHandeladvScanSettings, ADV_SCAN_S_OPTIMIZE_LOC , &EnableLocOptimization);	
	
	

			ExpLimitDelay=ExpLimitDelay/1000.0;
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&scanNum);
			
			if (tmp && ScanRunning) ScanBreak = SCAN_BREAK_PAUSE;
			else if (!tmp && ScanRunning) ScanBreak=RUN_SCAN;
			else if(tmp && !ScanRunning)
			{
			
			ScanBreak=RUN_SCAN;
			ScanRunning=1;
													
			SetGUI_ForSpectralScan(PanelHandleMain,PanelHandelGraph2,PanelHandelSpectrarlChart);
			arrSize=GetSpectralWavelengthData();
			
			if(j){
				strcpy(FileNameConst,sData.FileName);
				strcpy(FileNameSum1,sData.FolderName);
			
				if(sData.FolderName[strlen(sData.FolderName)]!='\\') strcat (FileNameSum1, "\\");
				strcat(FileNameSum1,FileNameConst);
			//	strcpy(FileNameSum2,FileNameSum1);
				sprintf(FileNametmp,"_%d",scanNum);
			
				strcat(FileNameSum1,FileNametmp);
				strcat(FileNameSum1,".SimpleSpec");
				MakeFile(FileNameSum1); 
				}
		
			daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData)); 
			Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
		
			if(!j) CreateNewResultArray_SPC(arrSize, 2); 
			else {for(i=arrSize-1;i>=0;i--)  for(k=0; k<sData.AI_Number; k++)   SPCarray[i][j].data[k]=0.0;}
		
				
		
				
			//if (AOTF_Online) Set_AOTF_ALL_Zero();   //I Added Remarks 
			if(AltrPolCycles) { MeasureCycles2=sData.MeasureCycles; GetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_CYCLES , &LoopMax);  }
			else 				LoopMax=1;
			
			if(!j)
			{
				SimpSpecBG_Loc.X=MicronixPOS_Query(X_AXIS);
			 	SimpSpecBG_Loc.Y=MicronixPOS_Query(Y_AXIS);
			}
			else
			{
				Samp_Loc.X=MicronixPOS_Query(X_AXIS);									
				Samp_Loc.Y=MicronixPOS_Query(Y_AXIS);	
			}
				
			
		//	for(j=0;j<2;j++)
		//	{
		//		if(!j) MoveToBackground(scanLoc); 
		//		else   {MoveToScanOrigin(scanLoc, SEARCH_TYPE_ORIGIN); 
		//				if(EnableLocOptimization) OptimizeParticleLocation(MonitorChan, DAQtask_G1);	}
				
				for(i=arrSize-1;i>=0;i--)   //wavelength loop
				{   
					//New Wavelength Adjustments ///////////////////////////////////////////////
					if(LCVR_Online) { LCRV_Set_Retardation(WavelengthArray[i].Wavelength,Pol_1, LCVR_CHAN);  Delay(400/1000);}	   
					GetWavelengthMaxPower(i,LIMIT_POWER_HARDCODED);
					if(!j || !ExpTimeLimit)SetCurrentWavelength_Const(WavelengthArray[i],TRUE);
					//AF if background or move Z to the right Z position for current wavelength;
					if(!j) {if(AFcorection) f_AutoFocus();  SPCarray[i][0].Z_Shift=MicronixPOS_Query(Z_AXIS); }//AF on background Reflection only save value for when measuring particle
					else   
					{
						if ((i== arrSize-1) && (AFcorection))
							{
								MicronixParam->Axis=X_AXIS; 
								MicronixParam->data1=SimpSpecBG_Loc.X;
								Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
								MicronixParam->Axis=Y_AXIS; 
								MicronixParam->data1=SimpSpecBG_Loc.Y;
								Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
								f_AutoFocus();
								Z_Drift=MicronixPOS_Query(Z_AXIS)-SPCarray[i][0].Z_Shift;	
								MicronixParam->Axis=X_AXIS; 
								MicronixParam->data1=Samp_Loc.X;
								Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
								MicronixParam->Axis=Y_AXIS; 
								MicronixParam->data1=Samp_Loc.Y;
								Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
							}
						MicronixParam->Axis=Z_AXIS; 
						MicronixParam->data1=SPCarray[i][0].Z_Shift+Z_Drift; 
						Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS); 
					}
					if(j && ExpTimeLimit){Set_AOTF_ALL_Zero();}  
					if(j && EnableLocOptimization) 
					{ 
						GlobalTrackingState =TRUE;
						OptimizeParticleLocation(TrackingChan);
						GlobalTrackingState =FALSE; 
					}
					for(PixelLoop=0; PixelLoop<LoopMax; PixelLoop++)
					{
						if(sData.AI_g1)
						{
							if(AltrPolCycles)
							{
									LCRV_Set_Retardation(WavelengthArray[i].Wavelength,Pol_1, LCVR_CHAN);
									Delay(0.05);	
							}
							for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles; aquisitionLoop++)   
							{
								if(ExpTimeLimit && j) SetCurrentWavelength_Const(WavelengthArray[i],FALSE);    
								DAQmxErrChk (DAQmxStartTask(DAQtask_G1));
								GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0);
								if(ExpTimeLimit && j){Set_AOTF_ALL_Zero(); Delay(ExpLimitDelay);}  
								DAQmxStopTask(DAQtask_G1);
								AssignDaqDataTo_SPCarrayChns(daqData, pointData,1,i,j,sData.MeasureCycles*LoopMax);
								
							}
						}
				
						if(sData.AI_g2)
						{
							if(AltrPolCycles)
							{
									LCRV_Set_Retardation(WavelengthArray[i].Wavelength,Pol_2, LCVR_CHAN);
									Delay(0.4);	
							}						
							for(aquisitionLoop=0; aquisitionLoop<MeasureCycles2; aquisitionLoop++)   
							{
								if(ExpTimeLimit && j) SetCurrentWavelength_Const(WavelengthArray[i],FALSE);  
								DAQmxErrChk (DAQmxStartTask(DAQtask_G2));
								GetDataFromDAQ(DAQtask_G2,sData.AI_g2 , nPoints_G2, pointData,sData.AI_g1);
								if(ExpTimeLimit && j){Set_AOTF_ALL_Zero(); Delay(ExpLimitDelay);}  
								DAQmxStopTask(DAQtask_G2);
								AssignDaqDataTo_SPCarrayChns(daqData, pointData,2,i,j,MeasureCycles2*LoopMax);
								
							}
						}	
					}//pixel loop
					if(ScanBreak==SCAN_BREAK_STOP) i=-2;
					else
					{
						if(j) 	{
								AddPointToSpectralChart(PanelHandelSpectrarlChart, WavelengthArray[i].Wavelength, SPCarray[i][0].data[0], SPCarray[i][1].data[0]);
								ScaleXY_Graph (PanelHandleMain, 0, 0,NULL, 0, 0);
								}
						//Change_LIAs_Sensitivity();  //this function changes all needed LIAs sensitivity (EG&G and SRS)	
					}
				}//for i
				
				Set_AOTF_ALL_Zero(); 
				ScanRunning=0;
		//	}//for j

			}//if run
			
			free(daqData);
			DAQmxClearTask(DAQtask_G1);
			DAQmxClearTask(DAQtask_G2);	
		
		if(j)
		{
			//Write data to files

			////////////////////Header//////////////////
			specFile=fopen(FileNameSum1, "a"); 
			if(AltrPolCycles)  fprintf(specFile,"This is an alternating CD scan 0-2 in pol1: %d, and 2-5 in pol2: %d \n",Pol_1,Pol_2);
			fprintf(specFile,"Wavelength[nm]\t");
			fprintf(specFile,"Zpos\t");  
			
			for(k=0; k<sData.AI_Number; k++)
				fprintf(specFile,"BG_Val%d\t" , k);
			for(k=0; k<sData.AI_Number; k++)
				fprintf(specFile,"Val%d\t" , k);
			fprintf(specFile,"Wavelength[nm]");
			fprintf(specFile,"\n");
			////////////////////////////////////////////
			for(i=arrSize-1;i>=0;i--)   //wavelength loop  
			{
				fprintf(specFile,"%d \t" , WavelengthArray[i].Wavelength);
				fprintf(specFile,"%lf \t" , SPCarray[i][0].Z_Shift);   
				for(k=0; k<sData.AI_Number; k++)
					fprintf(specFile, "%lf\t" , SPCarray[i][0].data[k]);      
				for(k=0; k<sData.AI_Number; k++)
					fprintf(specFile, "%lf\t" , SPCarray[i][1].data[k]);   
				fprintf(specFile,"%d" , WavelengthArray[i].Wavelength); 
			   	fprintf(specFile,"\n");
			}
		
			fclose(specFile);
			free(WavelengthArray);
			
			SetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,scanNum+1); 
		}//if j
			SetGUI_AfterScan(PanelHandleMain);
			MessagePopup ("spectra Measurment", "Done"); 
			SetCtrlVal(panel,control,!tmp);  
			break;
	}//switch case
	
	
	
	return 0;
Error:
return -1;
}


int CVICALLBACK f_start_spectral (int panel, int control, int event,
								  void *callbackData, int eventData1, int eventData2)   //This function is being called when clicking the start spectra
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp, curWavelength,arrSize,i; //tmp - the button caller id?.curWavelength - . arrSize- How many wavelengths we have in our scan. i-
			int AFcorection,powerBalanceCorection,scanLoc,pSearchType,AltrPolCycles, Pol_1,Pol_2,CurState=1 ;
			char FileNameConst[MAX_FILE_NAME_LENGTH]="", FileNameSum1[MAX_FILE_NAME_LENGTH]="", FileNameSum2[MAX_FILE_NAME_LENGTH]="",FileNametmp[MAX_FILE_NAME_LENGTH]="";
			int boolFirstSpectralScan =TRUE;
			int VoltageLimit=0,z;
			int Guy_Temp_Scan=-1;
			//ScanBreak - global variable,-1 Stop Scan, 0 - Normal Run, 1 - Puase Scan. ScanRunning-Global Variable
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_ALTR_SCAN_SET , &Guy_Temp_Scan);
			if(Guy_Temp_Scan==5)
			{
				Delay_Line_Scan(panel,control);
				break;
			}
			FILE *specSummery1,*specSummery2;
			
			GetCtrlVal(panel,control,&tmp); 
			X_TMP=Y_TMP=-1;
			
			if (tmp && ScanRunning) ScanBreak = SCAN_BREAK_PAUSE; //Pause the scan?
			else if (!tmp && ScanRunning) ScanBreak=RUN_SCAN;	  // What?
			else if(tmp && !ScanRunning)
			{
				
				ScanBreak=RUN_SCAN;	// Normal Run - Run_Scan=0 definition 
				ScanRunning=1;
													
				SetGUI_ForSpectralScan(PanelHandleMain,PanelHandelGraph2,PanelHandelSpectrarlChart); // This function calls the function in the GUI_FUNCTions file line 400, and it basicly clear the canvases and dimm buttons
				arrSize=GetSpectralWavelengthData(); // This function calls the function in line 1524 which returns how many wavelengths we have in our scan, and also create the wavelength array from max wavelength to minimum.
				
				GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType,&AltrPolCycles, &Pol_1,&Pol_2 ,&VoltageLimit,PanelHandleMain); //int AltrPolCycles choose the type of scan.
				//AFcorrection in from the button list of the type of af established
				strcpy(FileNameConst,sData.FileName);
				strcpy(FileNameSum1,sData.FolderName);
				
				if(sData.FolderName[strlen(sData.FolderName)]!='\\') strcat (FileNameSum1, "\\");
				strcat(FileNameSum1,FileNameConst);
				strcpy(FileNameSum2,FileNameSum1);
				strcat(FileNameSum1,".SpecSum1");
				strcat(FileNameSum2,".SpecSum2");
				specSummery1=CreateSpecSummeryFile(FileNameSum1);
				if(AltrPolCycles==ALTR_SCANS_POL || AltrPolCycles==ALTR_PIXEL_POL )  specSummery2=CreateSpecSummeryFile(FileNameSum2); //Not entering this if.
				
				//if (AOTF_Online) Set_AOTF_ALL_Zero();//I added Remarks
				
				for(i=arrSize-1;i>=0;i--)
				{
					do
					{
						AF_Z_Offset=0;
					
						//New Wavelength Adjustments ///////////////////////////////////////////////
						if(AltrPolCycles==ALTR_SCANS_POL) //You don't go into this if without changing the polarisation with the Liquid Crystal.
							if(CurState>0)
							{ 
								SetCurPolState(CurState,Pol_1,Pol_2,WavelengthArray[i].Wavelength);  
								strcpy(FileNametmp,FileNameConst) ;
								strcat(FileNametmp,"1_pol_") ;
								AdjustFileNameToCurrentWavelength(WavelengthArray[i].Wavelength, FileNametmp);
							
							}
							else 
							{
								SetCurPolState(CurState,Pol_1,Pol_2,WavelengthArray[i].Wavelength);  
								strcpy(FileNametmp,FileNameConst) ;
								strcat(FileNametmp,"2_pol_") ;
								AdjustFileNameToCurrentWavelength(WavelengthArray[i].Wavelength, FileNametmp); 
							}
						else AdjustFileNameToCurrentWavelength(WavelengthArray[i].Wavelength, FileNameConst);
			
						MoveToBackground(scanLoc);
						if(VoltageLimit) SetCurrentWavelength(WavelengthArray[i]); //If the voltage limit checkbox is on, only than you change the wavelength.   
						else
							{
							GetWavelengthMaxPower(i,LIMIT_POWER_HARDCODED);
							SetWavelength_PowerNotMonitored(WavelengthArray[i]);//Here the weird alert shows up.
							}
						if(MANUAL_AJUST_ON_NEW_WAVELENGTH) 
						{
							PanelHandlePopup = LoadPanel (0, "MIC_V2.uir", USER_PROM);
							InstallPopup(PanelHandlePopup);
							popup_confirm=0;
							while(!popup_confirm){ DelayWithEventProcessing(0.1);}
			 
						}	
							
				
						if(!AltrPolCycles && LCVR_Online) SetCurPolState(1,Pol_1,Pol_2,WavelengthArray[i].Wavelength);
						BG_AF(AFcorection,WavelengthArray[i].Wavelength, WavelengthArray[i].AOTF_num, i , arrSize);
						if(VoltageLimit) SetCurrentWavelength(WavelengthArray[i]); 
						BG_PowerBalance(powerBalanceCorection) ;
						for(z=0;z<MAX_DAQ_AI_CHAN;z++) pol_LIA_disp_diff[0][z]=0.0; 
						GetBackgroundValues(); 
						
						
						///////////////////////////////////////////////////////////////////////////
					
						if(! boolFirstSpectralScan)
							MoveToScanOrigin(scanLoc, pSearchType);
						else
							MoveToScanOrigin(scanLoc, SEARCH_TYPE_ORIGIN);
					
						if(AFcorection==AF_ON_BG_AND_PARTICLE)  f_AutoFocus(); 
					
						SetGUI_ForXYScan(PanelHandleMain,PanelHandelGraph2,PlotChan2);
						CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, XY_Scan, NULL, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, 0, &ScanThreadID);
						CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);	
					
						if(ScanBreak==SCAN_BREAK_STOP) i=-2;
						else
						{
							AddPointToSpectralChart(PanelHandelSpectrarlChart, WavelengthArray[i].Wavelength, XY_ScanMax, XY_ScanMin);
							if(AltrPolCycles*CurState>=0 || AltrPolCycles==ALTR_LIA_LIKE_MAX_MIN) AddLineToSummeryFile(FileNameSum1,  XY_ScanMin, XY_ScanMax, WavelengthArray[i].Wavelength);
							else AddLineToSummeryFile(FileNameSum2,  XY_ScanMin, XY_ScanMax, WavelengthArray[i].Wavelength); 
							ScaleXY_Graph (PanelHandleMain, 0, 0,NULL, 0, 0);
				
							Change_LIAs_Sensitivity();  //this function changes all needed LIAs sensitivity (EG&G and SRS)	
						}
					
						CurState=-CurState; 				  
					}while(AltrPolCycles*CurState<0 && AltrPolCycles==ALTR_SCANS_POL  && i>=0);
					
					boolFirstSpectralScan=FALSE;
					 
					
				 }													   
				//Set_AOTF_ALL_Zero(); I added remarks 
				ScanRunning=0;
				free(WavelengthArray);
				SetGUI_AfterScan(PanelHandleMain);//Set scan buttons to on and off where needed.
				
			}
		
			
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////			FILE Save & Load				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK fLoadImage (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		
		case EVENT_COMMIT:
			int  status; 
			char path[MAX_FILE_NAME_LENGTH];
			FILE *pFile;
			char lineStr[MAX_LINE_READ_LEN];
			int i,j,numCols,numLines,scaleFactor,scaleType;
			float val;
			double **arr,minVal=1000,maxVal=-1000;
			
			status = FileSelectPopup ("", "*.*", "*.AI_*", "Load Image File", VAL_LOAD_BUTTON, 0, 0, 1, 0, path);
			if (!status) return -1;
			
			pFile=fopen(path,"r");
			if ( pFile == NULL ) return -2;
			
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
	
			fscanf (pFile, " %s %d [^\n]\n", lineStr, &numLines);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fscanf (pFile, " %s %d [^\n]\n", lineStr, &numCols); 
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile);
			fgets (lineStr, MAX_LINE_READ_LEN, pFile); 
			fgets (lineStr, MAX_LINE_READ_LEN, pFile); 
			
			arr=(double**)malloc(numLines*sizeof(double*));
			for(i=0;i<numLines;i++) arr[i]=(double*)calloc(numCols,sizeof(double));
			
			for(i=0;i<numLines;i++)
			{
				fscanf (pFile, " %f ", &val);
				for(j=0;j<numCols;j++)
				{
					fscanf (pFile, " %f ", &val);
					arr[i][j]=(double)val;
					if(val>maxVal) maxVal=val;
					if(val<minVal) minVal=val;  
				}
			}
			fclose(pFile);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_PLOT_COLORMAP  ,&scaleType);
			LoadColormap( scaleType, maxVal, minVal); 
			PlotScaleBar(panel, MAIN_PANEL_XY_SCAN_PLOT_SCALE_1) ; 
			if(numCols>numLines)	scaleFactor=GRAPH_SIZE/numCols;
			else 					scaleFactor=GRAPH_SIZE/numLines;
			UpdateGraph( panel, MAIN_PANEL_XY_SCAN_PLOT_1, arr,numCols, numLines, scaleFactor);   
			////
			
			break;
	}
	return 0;
}

void GetFileAndFolderNames( int panel)
{
	char tmpStr[MAX_FILE_NAME_LENGTH]="";
	
										   
	GetCtrlVal(panel,MAIN_PANEL_FILE_NAME, tmpStr);
	if(strlen(tmpStr)<1) 
	{
		PromptPopup ("File Name Error", "Please enter a file name", tmpStr, MAX_FILE_NAME_LENGTH);
		SetCtrlVal(PanelHandleMain,MAIN_PANEL_FILE_NAME, tmpStr);
	}
	strcpy (sData.FileName, tmpStr);
	strcpy (tmpStr, "");
	
	GetCtrlVal(panel,MAIN_PANEL_FOLDER_NAME,tmpStr );
	
	if(strlen(tmpStr)<1) 
	{
		f_folder_browse(tmpStr);
		SetCtrlVal (panel, MAIN_PANEL_FOLDER_NAME, tmpStr);	
	}
	strcpy (sData.FolderName, tmpStr);
}

int CVICALLBACK scan_folder_browse (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			char directory_name[MAX_FILE_NAME_LENGTH];  
			f_folder_browse(directory_name);
			
			SetCtrlAttribute (panel, MAIN_PANEL_FOLDER_NAME, ATTR_DFLT_VALUE, directory_name);
			SetCtrlVal (panel, MAIN_PANEL_FOLDER_NAME, directory_name);
			break;
	}
	return 0;
}
int f_create_save_file_name(char * path, int scannumber,char * ftype)
{
	char tmpSTR[MAX_SCAN_NUMBER_LEN]="",tmpSTR2[MAX_SCAN_NUMBER_LEN+1]="";
	
	if (strlen(sData.FolderName)<1) return -1;
	strcpy(path,sData.FolderName);
	if(sData.FolderName[strlen(sData.FolderName)]!='\\') strcat (path, "\\");
	strcat (path, sData.FileName);
	
	sprintf (tmpSTR, "%d", scannumber);
	while((strlen(tmpSTR)+strlen(tmpSTR2))<MAX_SCAN_NUMBER_LEN)
	{
		strcat (tmpSTR2, "0");	
	}
	
	strcat (tmpSTR2, tmpSTR);
	strcat (path, "_");
	strcat(path,tmpSTR2);
	strcat(path,ftype);

	return 0;
}

FILE* MakeFile(char *fileName) // This function create a file to write in and return its pointer.
{
	FILE *pFile;
	if((pFile = fopen (fileName,"w"))==NULL)
	{
		MessagePopup ("Error", "Can't open file for saving data");
		return NULL;
	}	
	fclose(pFile);
	return  pFile;
}
char** CreateOutPutFiles_XY(void) // Creating an array of file names I guess?
{
	int k,scannum;
	char **resFileNames;
	char tmpStr[8]="", AInum[4]="";

	resFileNames = (char **)malloc((sData.AI_Number+1)*sizeof(char*));
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_SCAN_NUMBER, &scannum); //Get the scan number.
	strcpy(tmpStr,".AI_");
	
	for (k=0;k<sData.AI_Number; k++)
	{
		resFileNames[k] = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));  
		strcpy(resFileNames[k],"");
		
		sprintf (AInum, "%d", k);
		strcat(tmpStr,AInum);
		f_create_save_file_name(resFileNames[k], scannum,tmpStr);
		strcpy(AInum,"");
		strcpy(tmpStr,".AI_");
		MakeFile(resFileNames[k]);
	}
	resFileNames[k] = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	f_create_save_file_name(resFileNames[k], scannum,".Output");
	MakeFile(resFileNames[k]);
	return resFileNames;
	
}
int CVICALLBACK fSaveImage (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		
		
		int  scannum;
		char filename[MAX_FILE_NAME_LENGTH/2],foldername[MAX_FILE_NAME_LENGTH/2];
		char path[MAX_FILE_NAME_LENGTH];
		
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_FILE_NAME, filename);
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_FOLDER_NAME, foldername);
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_SCAN_NUMBER, &scannum);
		
		f_create_save_file_name(path,scannum, PNG_TYPE);
		SaveGraphToImage(path,PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1 );
		
		break;
	}
	return 0;
}

double **AlocateDoubleArray(int ySize,int xSize)
{
	double **array;
	int y;
	
	array = (double **)malloc((ySize)*sizeof(double*));
	
	for(y=0;y<ySize;y++) 
		array[y] = (double *)malloc((xSize)*sizeof(double));
	
	return array;
		
}
int FreeArray(double **arr, int ySize)
{
	int k;
	
	for (k=0;k<ySize;k++)
		if (arr[k]!=NULL) free(arr[k]);
	free(arr);
	return 0;
	
}
double GetSellectedChannelData(int graph_num, int y, int x)
{
	
	int chan=0;
	
	if( graph_num ==1)
			GetCtrlVal(PanelHandleMain, MAIN_PANEL_CHANNEL_PLOT_SELECT_1, &chan);
	else if( graph_num ==2) 
			GetCtrlVal(PanelHandelGraph2, PLOT_PANEL_CHANNEL_PLOT_SELECT_2, &chan);   
			
	if (chan>0) 
		return XYarray[y][x].data[chan];
	else
	{
		GetCtrlVal(PanelHandleMain, MAIN_PANEL_CHANNEL_PLOT_SELECT_1, &chan);
		return oldXYarray[y][x].data[chan];
	}

}
int CVICALLBACK ChangeColorMap (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int type,i,j; 
			double max, min,max2, min2;
			double **arr;
			int gScaleFactor;
			
			arr=(double**)malloc((Y_Scan_size)*sizeof(double*));
			for (i=0;i<X_Scan_size;i++)	arr[i]=(double*)calloc(X_Scan_size,sizeof(double));
			
			
			GetCtrlVal(PanelHandleMain, MAIN_PANEL_MAX_SCALE,&max);
			GetCtrlVal(PanelHandleMain, MAIN_PANEL_MIN_SCALE,&min);
			GetCtrlVal(PanelHandelGraph2, PLOT_PANEL_MAX_SCALE,&max2);
			GetCtrlVal(PanelHandelGraph2, PLOT_PANEL_MIN_SCALE,&min2);
			GetCtrlVal(panel,MAIN_PANEL_PLOT_COLORMAP,&type);
			
			LoadColormap(type,max,min);
			LoadColormap2(type,max2,min2);
			PlotScaleBar(PanelHandleMain,MAIN_PANEL_XY_SCAN_PLOT_SCALE_1);
			PlotScaleBar(PanelHandelGraph2,PLOT_PANEL_XY_SCAN_PLOT_SCALE_2);
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
						arr[i][j]=XYarray[i][j].data[PlotChan]/XYarray[i][j].data[RefChan];
			
			gScaleFactor=GetScaleFactor();
			UpdateGraph(PanelHandleMain,MAIN_PANEL_XY_SCAN_PLOT_1, arr  ,X_Scan_size,Y_Scan_size,gScaleFactor);
			
			for (i=0;i<X_Scan_size;i++)	free(arr[i]);  
			free(arr);
			
			break;
	}
	return 0;
}

void WriteXY_FileHeader(FILE* pFile, int index) // This function makes the reference/transmittence/reflection titles for a given file. It is being called by: XY_Scan func in line 1368 and by spectral scan
{
	char ScanTypeStr[50]="";
	
	if (index <MAX_DAQ_AI_CHAN )   fprintf(pFile,"Wavelength[nm]:\t%d\tBalance-Err:\t%f\n",sData.wavelength , BackgroundVals[index]);	
	else   fprintf(pFile,"Wavelength[nm]:\t%d\tBalance-Err:\t%s\n",sData.wavelength , "Not-Calculated");
	
	if (!sData.Scan_Type) {  strcat(ScanTypeStr,"XY Scan");}
	else if (sData.Scan_Type==1) { strcat(ScanTypeStr,"XZ Scan  (Y as Z)");} 
	else if(sData.Scan_Type==2) {strcat(ScanTypeStr,"YZ Scan  (X as Z)"); }
	
	fprintf(pFile,"Y_Scan_Points:\t%d\ty0:\t%f\n",Y_Scan_size, sData.y0);
	fprintf(pFile,"X_Scan_Points:\t%d\tx0:\t%f\tz0:\t%f\n",X_Scan_size, sData.x0, sData.z0); 
	fprintf(pFile,"Y_Scan_Size[um]:\t%f\tY Resolution[um]:\t%f\n",sData.Y_Size,sData.Y_Step ); 
	fprintf(pFile,"X_Scan_Size[um]:\t%f\tX Resolution[um]:\t%f\n",sData.X_Size,sData.X_Step );
	fprintf(pFile,"Scan Direction:\t%d\tScan Type:\t%s\n",sData.ScanDir, ScanTypeStr);
	
	
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////			AOTF				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK Change_AOTF_Dev_IDs (int panel, int control, int event,
									 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			GetAOTF_IDs( PanelHandelAOTFSettings , &VIS_ID, &NIR_ID, &NIR2_ID);
			SetAOTF_IDs(VIS_ID,NIR_ID,NIR2_ID);
			break;
	}
	return 0;
}
int CVICALLBACK AOTFSendString (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			char cmd[MAX_AOTF_CMD_LEN];
			int DevID=-1;
			int aotf_name;
			
			GetCtrlVal(PanelHandelAOTFSettings , AOTF_SETTI_AOTF_CMD_TEXT, cmd);
			GetCtrlVal(PanelHandelAOTFSettings , AOTF_SETTI_AOTF_DEVICE_ID, &aotf_name);
			
			
			switch (aotf_name)
			{
				case VIS:
					DevID=VIS_ID;	
				break;
		
				case NIR:
					 DevID=NIR_ID;
				break;
		
				case NIR2:
					 DevID=NIR2_ID; 
				break;
			
			}
			
			if (AOTF_Online) AOTFSendStringCmd(cmd, DevID);
			
			break;
	}
	return 0;
}
int GetAOTFdevID_From_aotf_type(aotf_type) // This function is being called by SetCurrentWavelength which changes the wavelength during scan. It gets the number from 0-3 where 1 is vis, 2 is nir and 3 is nir2 (which is not exist, and returns the AOTF real id.
{
	int tmp=-1;
	
	switch(aotf_type)
	{
		case VIS:
			return VIS_ID;
		case NIR:
			return NIR_ID;
		case NIR2:
			return NIR2_ID;
	}
	return -1;
}
int CVICALLBACK f_AOTF_UPDATE (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)  // This function is responsible for updating the laser gain and so the power, when the number in the text field VIS_AOTF_POWER_CH0 is being changed.
{
	switch (event)
	{
		case EVENT_COMMIT:
			int control2;
			int wavelength, gain,state,ret;
			int chan, aotf_type, command_Type,state_control;
			int Dev=-1;
			double freq=0.0;
			
			
			control2=GetAOTFUsefullControlNumber(control);
			aotf_type = GetAOTF_ID_FromControlHandle(control2);
			chan = GetAOTF_Channel_FromControlHandle(control2);
			command_Type = GetAOTF_Command_FromControlHandle(control2);
			state_control = GetAOTFControlFromUsfulNumber ((control2/100)*100+10);
			Dev= GetAOTFdevID_From_aotf_type(aotf_type);
			
			GetCtrlVal(panel,state_control,&state);
			if (state)
			{
				switch (command_Type)
				{
					case AOTF_COMMAND_SET_STATE:
						 GetCtrlVal(panel, GetAOTFControlFromUsfulNumber(control2+10),&wavelength);
						 GetCtrlVal(panel, GetAOTFControlFromUsfulNumber(control2+20),&gain);
						 if(AOTF_Online)  Set_AOTF_freq_gain(Dev, chan,Find_Freq_From_Wavelength_Dev(aotf_type,wavelength),gain); 
						 SetCtrlVal(PanelHandleMain,MAIN_PANEL_WAVELENGTH_INDICATOR,wavelength); 
						 if(PEM_STATUS) 
						 {	
							 GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&ret); 
							 PEM_change_Wavelength(wavelength,ret);
						 }
					break;
					
					case AOTF_COMMAND_SET_WAVE:
						 GetCtrlVal(panel,control,&wavelength);
						 if(AOTF_Online) Set_AOTF_freq(Dev, chan, Find_Freq_From_Wavelength_Dev(aotf_type,wavelength));
						 SetCtrlVal(PanelHandleMain,MAIN_PANEL_WAVELENGTH_INDICATOR,wavelength);
						 if(PEM_STATUS) 
						 {	
							 GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&ret); 
							 PEM_change_Wavelength(wavelength,ret);
						 }
					break;
					
					case AOTF_COMMAND_SET_POWER:
						 GetCtrlVal(panel,control,&gain); 
						 if(AOTF_Online) Set_AOTF_gain(Dev,chan,gain);
					break;
				}
				
			}
			else 
			{
				if(AOTF_Online) Set_AOTF_gain(Dev,chan,0);
			}
		
	
		break;
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////			FIANIUM				///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK power_update (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			double tmp; 
			switch(control)
			{
			case MAIN_PANEL_Fu_POWER_OUT:
				GetCtrlVal (panel, MAIN_PANEL_Fu_POWER_OUT, &tmp);
				if(Fianium_Online) LaserPowerUpdate(FUNDAMENTAL_OUTPUT,tmp);
				
				break;
				
			case MAIN_PANEL_SC_POWER_OUT:
				GetCtrlVal (panel, MAIN_PANEL_SC_POWER_OUT, &tmp);
				if(Fianium_Online) LaserPowerUpdate(SC_OUTPUT,tmp);

			}
			break;
			
			
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////			Standa				///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////


int CVICALLBACK Minus_Step (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	int step_size=0,arr[2],units_switch,light_time_delay;
	float speed_of_light=0.299792458,stnda_distance=0;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleStanda,STNDA_PNL_STEPS_UNITS_SWITCH, &units_switch);
			Calculate_Standa_Step(units_switch,arr);
			step_size=arr[0];
			SetCtrlAttribute (PanelHandleStanda, STNDA_PNL_COMMANDBUTTON_2, ATTR_CMD_BUTTON_COLOR, VAL_OFFWHITE);
			SetCtrlAttribute (PanelHandleStanda, STNDA_PNL_COMMANDBUTTON, ATTR_CMD_BUTTON_COLOR, VAL_GRAY);
			SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 1);
			Step(-step_size);
			SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 0);
			Standa_Current_Location-=step_size;
			SetCtrlVal (PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
			stnda_distance=Standa_Current_Location*2.5/1000.0;
			light_time_delay=(int)2*stnda_distance/speed_of_light;
			SetCtrlVal(PanelHandleStanda, STNDA_PNL_STANDA_DISTANCE, stnda_distance);
			SetCtrlVal(PanelHandleStanda,STNDA_PNL_STANDA_DELAY,light_time_delay);
			SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
			break;
	}
	return 0;
}

int CVICALLBACK Plus_Step (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	int step_size=0,arr[2],units_switch,light_time_delay;
	float speed_of_light=0.299792458,stnda_distance=0; 
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleStanda,STNDA_PNL_STEPS_UNITS_SWITCH, &units_switch);
			Calculate_Standa_Step(units_switch,arr);
			step_size=arr[0];
			SetCtrlAttribute (PanelHandleStanda, STNDA_PNL_COMMANDBUTTON, ATTR_CMD_BUTTON_COLOR, VAL_OFFWHITE);
			SetCtrlAttribute (PanelHandleStanda, STNDA_PNL_COMMANDBUTTON_2, ATTR_CMD_BUTTON_COLOR, VAL_GRAY);
			SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 1);
			Step(step_size);
			SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 0);
			Standa_Current_Location+=step_size;
			SetCtrlVal (PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
			stnda_distance=Standa_Current_Location*2.5/1000.0;
			light_time_delay=(int)2*stnda_distance/speed_of_light;
			SetCtrlVal(PanelHandleStanda, STNDA_PNL_STANDA_DISTANCE, stnda_distance);
			SetCtrlVal(PanelHandleStanda,STNDA_PNL_STANDA_DELAY,light_time_delay);
			SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
			break;
	}
	return 0;
}


/*void Delay_Line_Scan(int panel,int control)
{
	int step_size=0,step_counts=0,stage_offset=0,nPoints_G1, nPoints_G2,curWavelength,arrSize,ProbeWavelength=650,VoltageLimit=0,scan_break=0,af;
	DAQtaskData *daqData;
	int tmp,phase,direction,tracking_R=0,tracking_T=0;
	char *path;
	double sensitivity=0,factor=0,amp,pointData[MAX_DAQ_AI_CHAN]= {0.0};
	int AFcorection,powerBalanceCorection,scanLoc,pSearchType,AltrPolCycles, Pol_1,Pol_2,CurState=1 ;
	int32 error=0;
	TaskHandle DAQtask_G1=0,DAQtask_G2=0;

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AF_ON_SCAN , &af);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_PROBE_WAVELENGTH, &ProbeWavelength);
	GetCtrlVal(panel,control,&tmp);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_SIZE, &step_size);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_COUNTS, &step_counts);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_STANDA_OFFSET, &stage_offset);
	stage_offset=-stage_offset;
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_DIRECTION_SWITCH, &direction);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_Tracking_CB, &tracking_R);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_Tracking_CB_2, &tracking_T);
	
	if(direction==1) step_size=(-step_size);
	//stage_offset=-stage_offset;

	if(tmp && !ScanRunning) 
	{
		ScanBreak=RUN_SCAN;	// Normal Run - Run_Scan=0 definition 
		ScanRunning=1;
		daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData));
		FILE *outfile;

		SetGUI_ForDelayScan(PanelHandleMain,PanelHandelGraph2,PanelHandelSpectrarlChart,PanelHandleStanda);  ////This function is being called the scan_spectral and its just deleting previous data, dim buttons and displaying the specpanel
		arrSize=GetSpectralWavelengthData(); // This function calls the function in line 1524 which returns how many wavelengths we have in our scan, and also create the wavelength array from max wavelength to minimum.
		GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType,&AltrPolCycles, &Pol_1,&Pol_2 ,&VoltageLimit,PanelHandleMain);
		GetXYScanData(PanelHandleMain);//
		
		GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType,&AltrPolCycles, &Pol_1,&Pol_2 ,&VoltageLimit,PanelHandleMain);
		
		stage_offset-=Standa_Current_Location;
		SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 1);
		CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, Step2, &stage_offset, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, 0, &ScanThreadID);
		CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);	
		Standa_Current_Location+=stage_offset;
		SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
		sensitivity=EGNG_Read_Sensitivity_Double();
		factor=10/(sensitivity);
		Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
		for (int j=arrSize-1; j>=0;j--)
		{
			GetCtrlVal (PanelHandleStanda, STNDA_PNL_SCAN_SWITCH, &scan_break);
			if(scan_break) break;
			path = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
			Create_Standa_Scan_File_Name(path);
			if((outfile = fopen (path,"w"))==NULL)
			{
				MessagePopup ("Error", "Can't open file for saving data");
			}
			else
			{
				//if(af) PP_AutoFocus();
				if(tracking_R)
				{
					SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Reflection_Track,DAQtask_G1,nPoints_G1,pointData);
					Delay(1);
					Track_Particle_Reflection(DAQtask_G1,nPoints_G1,pointData);
				}
				else
				{
					if(tracking_T)
					{
						Track_Particle_Transmission(DAQtask_G1,nPoints_G1,pointData);
						SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Transmission_Track);
						Delay(1); 
					}
					else
					{
						SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,0);
						Delay(1);	
					}
				}
				
				fprintf(outfile,"amplitude    phase    position    R_PD    Ref_PD    Pump-Wavelength    Probe-Wavelength\n");
				for(int i=0; i<step_counts; i++)
				{

					//				LIA_AutoSensitivity();
					//				Delay(4);
					//LIA_AutoPhase();
					Delay(5);
					amp=LIA_Get_Mag();
					Delay(0.3);
					amp/=factor;
					phase=LIA_Get_Phase();
					Delay(0.3);
					DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
					GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
					fprintf(outfile,"%lf    %d    %d    %lf    %lf    %d    %d\n",amp,phase,Standa_Current_Location,pointData[0],pointData[1],WavelengthArray[j].Wavelength,ProbeWavelength);
					CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, Step2, &step_size, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, 0, &ScanThreadID);
					CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);	
					Standa_Current_Location+=(step_size);
					SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
					DAQmxStopTask(DAQtask_G1);
				}
			}
			fclose(outfile);
			free(path);
			Set_AOTF_ALL_Zero();
			GetCtrlVal (PanelHandleStanda, STNDA_PNL_STANDA_OFFSET, &stage_offset);
			stage_offset=-stage_offset;
			stage_offset-=Standa_Current_Location;
			Step(stage_offset);
			Standa_Current_Location+=stage_offset;
			SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
		}
		ScanRunning=0;
		SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 0);
		free(daqData);
		DAQmxClearTask(DAQtask_G1);
		DAQmxClearTask(DAQtask_G2);
		free(WavelengthArray);
		SetGUI_AfterScan(PanelHandleMain);
		HidePanel(PanelHandleStanda);
Error:
		return;
	}
}
*/

int cmpfunc (const void * a, const void * b) {
    if(*(double*)a > *(double*)b) return 1;
	else return -1;
}

void Delay_Line_Scan(int panel,int control)
{
	int step_size=0,step_counts=0,stage_offset=0,nPoints_G1, nPoints_G2,curWavelength,arrSize,ProbeWavelength=650,VoltageLimit=0,scan_break=0,af,units_switch=0,steparr[2];
	DAQtaskData *daqData;
	int tmp,direction,tracking_R=0,tracking_T=0,num_of_scans=0,light_time_delay,tracking_type=0,tracking_freq;
	char *path;
	double *amp_vals;
	double sensitivity=0,factor=0,amp=0,phase=0,pointData[MAX_DAQ_AI_CHAN]= {0.0};
	int AFcorection,powerBalanceCorection,scanLoc,pSearchType,AltrPolCycles, Pol_1,Pol_2,CurState=1;
	float speed_of_light=0.299792458,stnda_distance=0;
	int32 error=0;
	TaskHandle DAQtask_G1=0,DAQtask_G2=0;
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_RINGSLIDE, &tracking_type);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_RINGSLIDE_2, &tracking_freq);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AF_ON_SCAN , &af);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_PROBE_WAVELENGTH, &ProbeWavelength);
	GetCtrlVal(panel,control,&tmp);
	//GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_SIZE, &step_size);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_COUNTS, &step_counts);
	//GetCtrlVal (PanelHandleStanda, STNDA_PNL_STANDA_OFFSET, &stage_offset);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_DIRECTION_SWITCH, &direction);
//	GetCtrlVal (PanelHandleStanda, STNDA_PNL_Tracking_CB, &tracking_R);
//	GetCtrlVal (PanelHandleStanda, STNDA_PNL_Tracking_CB_2, &tracking_T);
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_NUM_OF_SCANS, &num_of_scans);
	GetCtrlVal(PanelHandleStanda,STNDA_PNL_STEPS_UNITS_SWITCH, &units_switch);
	
	Calculate_Standa_Step(units_switch,steparr);
	step_size=steparr[0];
	stage_offset=steparr[1];
	
	if(direction==1)
	{
		step_size=(-step_size);
		stage_offset=-stage_offset;
	}
	//stage_offset=-stage_offset;

	if(tmp && !ScanRunning) 
	{
		ScanBreak=RUN_SCAN;	// Normal Run - Run_Scan=0 definition 
		ScanRunning=1;
		daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData));
		FILE *outfile;

		SetGUI_ForDelayScan(PanelHandleMain,PanelHandelGraph2,PanelHandelSpectrarlChart,PanelHandleStanda);  ////This function is being called the scan_spectral and its just deleting previous data, dim buttons and displaying the specpanel
		arrSize=GetSpectralWavelengthData(); // This function calls the function in line 1524 which returns how many wavelengths we have in our scan, and also create the wavelength array from max wavelength to minimum.
		GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType,&AltrPolCycles, &Pol_1,&Pol_2 ,&VoltageLimit,PanelHandleMain);
		GetXYScanData(PanelHandleMain);//
		
		GetSpectralScanSettings(&AFcorection, &powerBalanceCorection, &scanLoc  ,&pSearchType,&AltrPolCycles, &Pol_1,&Pol_2 ,&VoltageLimit,PanelHandleMain);
		
		stage_offset-=Standa_Current_Location;
		SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 1);
		CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, Step2, &stage_offset, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, 0, &ScanThreadID);
		CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);	
		Standa_Current_Location+=stage_offset;
		stnda_distance=Standa_Current_Location*2.5/1000.0;
		light_time_delay=(int)2*stnda_distance/speed_of_light;
		SetCtrlVal(PanelHandleStanda,STNDA_PNL_STANDA_DELAY,light_time_delay);
		SetCtrlVal(PanelHandleStanda, STNDA_PNL_STANDA_DISTANCE, stnda_distance);
		SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
		sensitivity=EGNG_Read_Sensitivity_Double();
		factor=10/(sensitivity);
		Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
		for (int i=0; i<step_counts; i++)
		{
			GetCtrlVal (PanelHandleStanda, STNDA_PNL_SCAN_SWITCH, &scan_break);
			if(scan_break) break;
			path = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
			Create_Standa_Scan_File_Name(path); //here I create the files for data
			if((outfile = fopen (path,"w"))==NULL)
			{
				MessagePopup ("Error", "Can't open file for saving data");
			}
			else
			{
				fprintf(outfile,"amplitude    phase    position    R_PD    Ref_PD    Pump-Wavelength    Probe-Wavelength\n");
				for(int j=arrSize-1; j>=0;j--)
				{

					//				LIA_AutoSensitivity();
					//				Delay(4);
					//LIA_AutoPhase();
					//if(af) PP_AutoFocus();
					switch(tracking_freq)
					{
						case 0:
							SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,4,DAQtask_G1,nPoints_G1,pointData);
							break;
						
						case 1:
							if(j==arrSize-1)
							{
								switch(tracking_type)
								{
									case 0:
										SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Reflection_Track,DAQtask_G1,nPoints_G1,pointData);
										//Track_Particle_Reflection(DAQtask_G1,nPoints_G1,pointData); 
										break;
										
									case 1:
										SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Transmission_Track,DAQtask_G1,nPoints_G1,pointData);
										//Track_Particle_Transmission(DAQtask_G1,nPoints_G1,pointData);
										break;
										
									case 2:
										SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,LIA_Track,DAQtask_G1,nPoints_G1,pointData);
										//Track_Particle_LIA();
										break;
										
								}
							}
							else SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,4,DAQtask_G1,nPoints_G1,pointData);
							break;
							
						case 2:
							switch(tracking_type)
								{
									case 0:
										SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Reflection_Track,DAQtask_G1,nPoints_G1,pointData);
										//Track_Particle_Reflection(DAQtask_G1,nPoints_G1,pointData); 
										break;
										
									case 1:
										SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Transmission_Track,DAQtask_G1,nPoints_G1,pointData);
										//Track_Particle_Transmission(DAQtask_G1,nPoints_G1,pointData);
										break;
										
									case 2:
										SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,LIA_Track,DAQtask_G1,nPoints_G1,pointData);
										//Track_Particle_LIA();
										break;
										
								}
							break;
					}
/*					if(tracking_R)
					{
						SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Reflection_Track,DAQtask_G1,nPoints_G1,pointData);
						Delay(1);
						Track_Particle_Reflection(DAQtask_G1,nPoints_G1,pointData);
					}
					else
					{
						if(tracking_T)
						{
							SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,Transmission_Track,DAQtask_G1,nPoints_G1,pointData); 
							Track_Particle_Transmission(DAQtask_G1,nPoints_G1,pointData);
							//Delay(0.2); 
						}
						else
						{
							SetPumpProbeWavelength(WavelengthArray[j],ProbeWavelength,0,DAQtask_G1,nPoints_G1,pointData);
							//Delay(0.2);	
						}
					}*/
					amp=0;
					phase=0;
					amp_vals=(double *) malloc(num_of_scans*sizeof(double));
					Delay(2);
					for(int k=0;k<num_of_scans;k++)
					{
						amp=LIA_Get_Mag();
						amp/=factor;
						amp_vals[k]=amp;
						//printf("%lf \n",amp);
						//Delay(0.3);
						phase+=LIA_Get_Phase();
						Delay(0.2);
					}
					qsort(amp_vals,num_of_scans,sizeof(double),cmpfunc);
					amp=amp_vals[num_of_scans/2];
					free(amp_vals);
/*					for(int k=0;k<num_of_scans;k++)
					{
						printf("%lf \n",amp_vals[k]);
					}
*/					phase/=num_of_scans;
					DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
					GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
					fprintf(outfile,"%lf    %lf    %d    %lf    %lf    %d    %d\n",amp,phase,Standa_Current_Location,pointData[0],pointData[1],WavelengthArray[j].Wavelength,ProbeWavelength);
					DAQmxStopTask(DAQtask_G1);
				}
				
				CmtScheduleThreadPoolFunctionAdv (DEFAULT_THREAD_POOL_HANDLE, Step2, &step_size, THREAD_PRIORITY_TIME_CRITICAL, NULL, EVENT_TP_THREAD_FUNCTION_END, NULL, 0, &ScanThreadID);
				CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
				Standa_Current_Location+=step_size;
				stnda_distance=Standa_Current_Location*2.5/1000.0;
				light_time_delay=(int)2*stnda_distance/speed_of_light;
				SetCtrlVal(PanelHandleStanda,STNDA_PNL_STANDA_DELAY,light_time_delay);
				SetCtrlVal(PanelHandleStanda, STNDA_PNL_STANDA_DISTANCE, stnda_distance);
				SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
			}
			fclose(outfile);
			free(path);
			Set_AOTF_ALL_Zero();
		}
		GetCtrlVal (PanelHandleStanda, STNDA_PNL_STANDA_OFFSET, &stage_offset);
		stage_offset=-stage_offset;
		stage_offset-=Standa_Current_Location;
		Step(stage_offset);
		Standa_Current_Location+=stage_offset;
		stnda_distance=Standa_Current_Location*2.5/1000.0;
		light_time_delay=(int)2*stnda_distance/speed_of_light;
		SetCtrlVal(PanelHandleStanda,STNDA_PNL_STANDA_DELAY,light_time_delay);
		SetCtrlVal(PanelHandleStanda, STNDA_PNL_STANDA_DISTANCE, stnda_distance);
		SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
		ScanRunning=0;
		SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 0);
		free(daqData);
		DAQmxClearTask(DAQtask_G1);
		DAQmxClearTask(DAQtask_G2);
		free(WavelengthArray);
		SetGUI_AfterScan(PanelHandleMain);
		HidePanel(PanelHandleStanda);
Error:
		return;
	}
}

void Calculate_Standa_Step(int units,int *arr)
{
	int step_size,light_time_delay=0,stage_offset;
	float speed_of_light=0.299792458,stnda_distance=0; //In units of mm/picosecond
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_STANDA_OFFSET, &stage_offset);  
	
	if( units ==0)
	{
		GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_SIZE, &light_time_delay);
		stnda_distance=light_time_delay*200*speed_of_light;
		stnda_distance+=0.5;
		step_size=(int)stnda_distance;
		
	}
	if(units==1)
	{
		GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_SIZE, &step_size);
	}
	arr[0]=step_size;
	arr[1]=stage_offset;
}

void Track_Particle_Reflection(TaskHandle DAQtask_G1,int nPoints_G1,double *pointData)
{
	int count=0,count2=0,index_min=0,index_max=0,track_setting,num;
	double prev_ref,min_ref,max_ref,correction_size=0.1,correct_count=3.0;
	char *convert,*path;
	int32 error=0;
	FILE *myfile;
	
	
	path = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	convert=(char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_TRACK_SET, &track_setting); 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
	
	strcpy(path,sData.FolderName);
	strcat(path,"\\Test_");
	sprintf(convert,"%d",num);
	strcat(convert,".txt");
	strcat(path,convert);
	free(convert);
	myfile=fopen(path,"w"); 
	
	if (GUI_Thread_Lock) return;
	else GUI_Thread_Lock =1;
	MicronixParam->Axis=Y_AXIS;
	
	MicronixParam->data1=correct_count*correction_size;
	MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
	if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	MicronixParam->data1=correction_size;
	MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input 
	DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
	GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
	prev_ref=pointData[0];
	min_ref=pointData[0];
	max_ref=pointData[0];  
	DAQmxStopTask(DAQtask_G1);
//	printf("%f  %d\n",pointData[0],index_min);
	fprintf(myfile,"%f  %d\n",pointData[0],index_min);
	
	for(int tmp=0;tmp<(2*correct_count);tmp++)
	{
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
		DelayWithEventProcessing(0.05);
		DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
		GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
		DAQmxStopTask(DAQtask_G1);
		count++;
		
		
		if(pointData[0] < prev_ref)
		{
			if(min_ref>pointData[0])
			{
				min_ref=pointData[0];
				index_min=count;
			}
		}
		else
		{
			if(max_ref<pointData[0])
			{
				max_ref=pointData[0];
				index_max=count;
			}
		}
		prev_ref=pointData[0];
//		printf("%f  %d\n",pointData[0],index_min);
		fprintf(myfile,"%f  %d\n",pointData[0],index_min);
	}


	
	if(track_setting)
	{
		MicronixParam->data1=((2*correct_count)-index_max)*(correction_size);
		MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input   
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	}
	else
	{
		MicronixParam->data1=((2*correct_count)-index_min)*(correction_size);
		MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input   
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	}
	fclose(myfile);
	SaveLocation(1,0);
	GUI_Thread_Lock =0;
	free(path);
Error: 
		return;
}

void Track_Particle_Transmission(TaskHandle DAQtask_G1,int nPoints_G1,double *pointData)
{
	int count=0,count2=0,index_min=0,index_max=0,track_setting,num;
	double prev_ref,min_ref,max_ref,correction_size=0.1,correct_count=3.0;
	char *convert,*path;
	int32 error=0;
	FILE *myfile;
	
	
	path = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	convert=(char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_TRACK_SET, &track_setting); 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
	
	strcpy(path,sData.FolderName);
	strcat(path,"\\Test_");
	sprintf(convert,"%d",num);
	strcat(convert,".txt");
	strcat(path,convert);
	free(convert);
	myfile=fopen(path,"w"); 
	
	if (GUI_Thread_Lock) return;
	else GUI_Thread_Lock =1;
	MicronixParam->Axis=Y_AXIS;
	
	MicronixParam->data1=correct_count*correction_size;
	MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
	if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	MicronixParam->data1=correction_size;
	MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input 
	DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
	GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
	prev_ref=pointData[2];
	min_ref=pointData[2];
	max_ref=pointData[2];  
	DAQmxStopTask(DAQtask_G1);
//	printf("%f  %d\n",pointData[0],index_min);
	fprintf(myfile,"%f  %d\n",pointData[2],index_min);
	
	for(int tmp=0;tmp<(2*correct_count);tmp++)
	{
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
		DelayWithEventProcessing(0.05);
		DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
		GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
		DAQmxStopTask(DAQtask_G1);
		count++;
		
		
		if(pointData[2] < prev_ref)
		{
			if(min_ref>pointData[2])
			{
				min_ref=pointData[2];
				index_min=count;
			}
		}
		else
		{
			if(max_ref<pointData[2])
			{
				max_ref=pointData[2];
				index_max=count;
			}
		}
		prev_ref=pointData[2];
//		printf("%f  %d\n",pointData[0],index_min);
		fprintf(myfile,"%f  %d\n",pointData[2],index_min);
	}


	
	if(track_setting)
	{
		MicronixParam->data1=((2*correct_count)-index_max)*(correction_size);
		MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input   
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	}
	else
	{
		MicronixParam->data1=((2*correct_count)-index_min)*(correction_size);
		MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input   
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	}
	fclose(myfile);
	SaveLocation(1,0);
	GUI_Thread_Lock =0;
	free(path);
Error: 
		return;
}

void Track_Particle_LIA(int wavelength)
{
	int count=0,count2=0,index_min=0,index_max=0,track_setting,num_of_scans=10,num;
	double prev_ref,max_ref,correction_size=0.1,correct_count=3.0,*amp_vals,amp,sensitivity=0,factor=0;
	char *convert,*path;
	int32 error=0;
	FILE *myfile;
	
	path = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	convert=(char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
	strcpy(path,sData.FolderName);
	strcat(path,"\\Test_");
	sprintf(convert,"%d",num);
	strcat(path,convert);
	sprintf(convert,"%d",wavelength);
	strcat(path,convert);
	strcat(path,".txt");
	free(convert);
	myfile=fopen(path,"w"); 
	
	sensitivity=EGNG_Read_Sensitivity_Double();
	factor=10/(sensitivity);
	if (GUI_Thread_Lock) return;
	else GUI_Thread_Lock =1;
	MicronixParam->Axis=Y_AXIS;
	MicronixParam->data1=correct_count*correction_size;
	MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
	if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	MicronixParam->data1=correction_size;
	MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
	
	amp_vals=(double *) malloc(num_of_scans*sizeof(double));
	Delay(2);
	for(int k=0;k<num_of_scans;k++)
	{
		amp=LIA_Get_Mag();
		amp/=factor;
		amp_vals[k]=amp;
		//printf("%lf \n",amp);
		//Delay(0.3);
		Delay(0.2);
	}
	qsort(amp_vals,num_of_scans,sizeof(double),cmpfunc);
	amp=amp_vals[num_of_scans/2];
	free(amp_vals);
	
	
	prev_ref=amp;
	max_ref=amp;
	fprintf(myfile,"%f  %d\n",amp,index_max);				
	for(int tmp=0;tmp<(2*correct_count);tmp++)
	{
		if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
		DelayWithEventProcessing(0.05);
		count++; 
		amp_vals=(double *) malloc(num_of_scans*sizeof(double));
		Delay(2);
		for(int k=0;k<num_of_scans;k++)
		{
			amp=LIA_Get_Mag();
			amp/=factor;
			amp_vals[k]=amp;
			//printf("%lf \n",amp);
			//Delay(0.3);
			Delay(0.2);
		}
		qsort(amp_vals,num_of_scans,sizeof(double),cmpfunc);
		amp=amp_vals[num_of_scans/2];
		free(amp_vals);
		if(max_ref<amp)
		{
			max_ref=amp;
			index_max=count;
		}
		fprintf(myfile,"%f  %d\n",amp,index_max);
	}
	MicronixParam->data1=((2*correct_count)-index_max)*(correction_size);
	MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input   
	if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
	
	fclose(myfile);
	SaveLocation(1,0);
	GUI_Thread_Lock =0;
	free(path);
}

void Create_Standa_Scan_File_Name(char * path)
{
	int num=0;
	char *convert;
	convert=(char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,num+1);
	strcpy(path,sData.FolderName);
	strcat(path,"\\LIA_");
	sprintf(convert,"%d",num);
	strcat(convert,".txt");
	strcat(path,convert);
	free(convert);
	
}

/*int CVICALLBACK Calculate_Stnda_Distance (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int step_size,units=0;
	float speed_of_light=0.299792458; //In units of mm/picosecond
	float stnda_distance=0;
	int light_distance;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(PanelHandleStanda,STNDA_PNL_STEPS_UNITS_SWITCH, &units);
			if(units==1)
			{
				GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_SIZE, &step_size);
				stnda_distance=step_size*2.5/1000.0;
				light_distance=(int)2*stnda_distance/speed_of_light;
				SetCtrlVal(PanelHandleStanda, STNDA_PNL_STANDA_DISTANCE, stnda_distance);
				SetCtrlVal(PanelHandleStanda,STNDA_PNL_STANDA_DELAY,light_distance);
			}
			
			break;
	}
	return 0;
}*/

int CVICALLBACK Delay_Scan (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int step_size=0,step_counts=0,nPoints_G1, nPoints_G2;
			DAQtaskData *daqData;
			int tmp,num=0,amp,phase,direction;
			char *path,*convert;
			double sensitivity=0,factor=0;
			double pointData[MAX_DAQ_AI_CHAN]={0.0};
			int32 error=0;
			TaskHandle DAQtask_G1=0,DAQtask_G2=0;
			daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData));
			FILE *outfile;
			GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_SIZE, &step_size);
			GetCtrlVal (PanelHandleStanda, STNDA_PNL_STEP_COUNTS, &step_counts);
			GetCtrlVal (PanelHandleStanda, STNDA_PNL_DIRECTION_SWITCH, &direction);
			if(direction==1) step_size=(-step_size);
			GetXYScanData(PanelHandleMain); 
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
			SetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,num+1);
			convert=(char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
			path = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
			strcpy(path,sData.FolderName);
			strcat(path,"\\LIA_");
			sprintf(convert,"%d",num);
			strcat(convert,".txt");
			strcat(path,convert);
			if((outfile = fopen (path,"w"))==NULL)
			{
				MessagePopup ("Error", "Can't open file for saving data");
			}
			else
			{
				SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 1);
				sensitivity=EGNG_Read_Sensitivity_Double();
				factor=10/(sensitivity);
				Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );  
				fprintf(outfile,"amplitude    phase    position    R_PD    Ref_PD\n");
				for(int i=0;i<step_counts;i++)
				{
				
	//				LIA_AutoSensitivity();
	//				Delay(4);  
					LIA_AutoPhase();
					Delay(0.2);
					amp=LIA_Get_Mag();
					Delay(0.1);
					//amp/=factor;
					phase=LIA_Get_Phase();
					Delay(0.11);
					DAQmxErrChk(DAQmxStartTask(DAQtask_G1));//Make the task start acquisition.
					GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0); //Here I Read the DATA!!!!  remeber that npoints_g* defines the number of points acquired from each channel. AI_g1  defines how many active channels in that group. pointData is an array of 6 which will consist the median from each channel. And the last variable 0 is the offset from where the channels start.
					fprintf(outfile,"%d    %d    %d    %lf    %lf\n",amp,phase,Standa_Current_Location,pointData[0],pointData[1]);
					Step(step_size);
					Standa_Current_Location+=step_size;
					SetCtrlVal(PanelHandleStanda, STNDA_PNL_POSITION, Standa_Current_Location);
					DAQmxStopTask(DAQtask_G1); 
				}
				SetCtrlVal (PanelHandleStanda, STNDA_PNL_Moving_LED, 0);
			}
			fclose(outfile);
			free(path);
			free(convert);
			free(daqData);
			DAQmxClearTask(DAQtask_G1);
			DAQmxClearTask(DAQtask_G2);
		Error:
			return -1;
	}
	return 0;;
}

void  SetPumpProbeWavelength( SpectralPoint CurPoint,int ProbeWavelength,int track,TaskHandle DAQtask_G1,int nPoints_G1,double *pointData)  // This function is being called by the f_start_scan and the delay_line_scan. its main 
{
	int Dev, AOTFchan=0,sign=1,WavelengthOffset=0,pb_pump,minwavelength;
	double powerTest=0.0,powerLast=0.0;
	double Freq,Freq2,Freq3;
	double ZCurrnt;
	double maxVoltageReading,minVoltageReading;
	char daqChan[50]="";
	int PowerStep=100, curPower=500;
	
	if (CurPoint.Wavelength >500)
	{
		PowerStep=50, curPower=300;	
	}
	
	//Set_AOTF_ALL_Zero(); I added Remakrs
	
	Dev= GetAOTFdevID_From_aotf_type(CurPoint.AOTF_num);//This function gets the real aotf id.
	Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength);
	Freq2=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,ProbeWavelength);
	//GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_1,&minwavelength);
	minwavelength=780;
	Set_AOTF_freq_gain(Dev,5,Freq2,2500);
	if(track==Transmission_Track)
	{
		Track_Particle_Transmission(DAQtask_G1,nPoints_G1,pointData); 
	}
	else
	{
		if(track==Reflection_Track)
		{
			Track_Particle_Reflection(DAQtask_G1,nPoints_G1,pointData); 	
		}
		else
		{
			Freq3=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,minwavelength);
			Set_AOTF_freq_gain(Dev,AOTFchan,Freq3, 2500);
			//printf("%d %f,\n ",minwavelength,Freq3);
			if(track==LIA_Track) Track_Particle_LIA(CurPoint.Wavelength);	
		}
	}
	GetCtrlVal (PanelHandleStanda, STNDA_PNL_PB_PUMB_CB, &pb_pump);
	if(pb_pump)
	{
		GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_1 ,daqChan);
		GetCtrlVal(PanelHandleMain, MAIN_PANEL_SET_MAX_VOLTAGE ,&maxVoltageReading); 
		GetCtrlVal(PanelHandleMain, MAIN_PANEL_SET_MIN_VOLTAGE ,&minVoltageReading);
	 
	//	while((curPower+PowerStep<=1500) && fabs(powerTest) <maxVoltageReading)  
		while((curPower+PowerStep<=CurPoint.RF_Power) && fabs(powerTest) <maxVoltageReading) //While the current power is smaller than the maximum power and the voltage reading is smaller than the voltage reading.
		{
			curPower+=PowerStep;
			Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength);
			Set_AOTF_freq_gain(Dev,AOTFchan,Freq, curPower);
			powerTest = ReadDaqChan(daqChan);
	//		if (powerTest<powerLast)
	//			{
	//			curPower-=PowerStep;
	//			Set_AOTF_freq_gain(Dev,AOTFchan,Freq, curPower);
	//			break;
	//			}
	//		else powerLast=powerTest;
		}

		//Add extraChannels for 465-430??
		while (powerTest<minVoltageReading && AOTFchan<4)
		{
			AOTFchan++;
			WavelengthOffset=((int)((AOTFchan-1)/2)+1)*sign;  
			Freq=Find_Freq_From_Wavelength_Dev(CurPoint.AOTF_num,CurPoint.Wavelength+WavelengthOffset);  
			Set_AOTF_freq_gain(Dev,AOTFchan,Freq,1500);
			powerTest = ReadDaqChan(daqChan);
			sign=-sign;
			if (powerTest<powerLast)
			{
				Set_AOTF_freq_gain(Dev,AOTFchan,Freq, 0);
				break;
			}
			else powerLast=powerTest; 
		}
	}
	else
	{
		Set_AOTF_freq_gain(Dev,AOTFchan,Freq, 2500);	
	}
	//////
	SetCtrlVal(PanelHandleMain, MAIN_PANEL_WAVELENGTH_INDICATOR ,CurPoint.Wavelength); 
	sData.wavelength=CurPoint.Wavelength;
}

int PP_AutoFocus(void)  //This function moves to the BG1 Location and does Autofocus.
{
	int loc,type,tmp=0;
	loc=11;
	type = loc%10;
	loc  = loc/10;
	if (Micronix_Online) tmp= MoveToLocation(loc,type);
	if(tmp<0) return -1;
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_AUTOFOCUS_BUTTON, ATTR_DIMMED, 1);
	f_AutoFocus();
	if (TRANSMISSION_MODE) fAF_Transmission(); 
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_AUTOFOCUS_BUTTON, ATTR_DIMMED, 0);
	if (Micronix_Online) tmp= MoveToLocation(1,0);
	if(tmp<0) return -1;
	return 0;	
	
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////			PI				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void Start_PI_Stages(void)	  //A function which main goal is to 
{
	Open_PI_Port(DevicesSessionManeger); //open a port to contact the device using the visa api.
	Initialize_PI_Stages();		 //initialize stages (give command to start servo)  of the pi and give default values.
	PI_STATUS=1;			  // Change the status of the PI to on.
}





///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////			MICRONIX				///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void  MicronixErrorProcedure()
{
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_SHOW_SETINGS,STATE_ON);
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_LED,STATE_OFF);
	SetCtrlVal(PanelHandelMicronixSettings,MICRONIX_S_MICRONIX_ERR_MSG,MicronixErrorString);   
	DisplayPanel( PanelHandelMicronixSettings );	
}

void StartMicronixStages(void)
{
	GetMotorsAxisIDs(PanelHandelMicronixSettings, &X_AXIS, &Y_AXIS, &Z_AXIS); //This function gets the ID values of the x,y,z axis fiels in the micronixsettings panel.
	SetMotorsAxisIDs(X_AXIS, Y_AXIS, Z_AXIS);// This function defines X/Y/Z IDs in the micronix_Control.c file.
	OpenMicronixPort(DevicesSessionManeger); // This function responsible for the connection of the Micronix to the VISA api
	InitializeMicronixStages(); // This function is defined in micronix_control.c file in line 132 and it uses the micronix commands to give default values to the stage.
	Micronix_STATUS=1; //After all is well, define the status of the micronix as active.
}
int CVICALLBACK fnc_xyz_stop (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MicronixStop(0);
			break;
	}
	return 0;
}
int CVICALLBACK fnc_z_stop (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			MicronixParam->Axis=Z_AXIS;
			MicronixStop(MicronixParam); 
			break;
	}
	return 0;

}
int CVICALLBACK fMpveContinus (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case 	EVENT_LEFT_CLICK:
				SetMouseCursor (VAL_HOUR_GLASS_CURSOR);
				//This fonction initiates a continus move as long as the left mouse button is pressed on the control.
				if (GUI_Thread_Lock) return -1;
				else GUI_Thread_Lock =1;
				
				switch (control)
					{
						case MAIN_PANEL_UP_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Y_AXIS;
						break;
							
						case MAIN_PANEL_DOWN_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Y_AXIS;
						break;
						
						case MAIN_PANEL_LEFT_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=X_AXIS;
						break;
						
						case MAIN_PANEL_RIGHT_CONT:
							GetCtrlVal (panel, MAIN_PANEL_XY_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=X_AXIS;
						break;
						
						case MAIN_PANEL_Z_MINUS:
							GetCtrlVal (panel, MAIN_PANEL_Z_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=-(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Z_AXIS;
						break;
						
						case MAIN_PANEL_Z_Plus:
							GetCtrlVal (panel, MAIN_PANEL_Z_INCREMENT, &MicronixParam->data1);
							MicronixParam->data1=(MicronixParam->data1)/1000.0; //Convert um to mm for micronix stage input
							MicronixParam->Axis=Z_AXIS;
						break;
					  
					}
				int tmp=1;   
				while (tmp)
				{
					if (Micronix_Online) Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_REL);
					DelayWithEventProcessing(0.05);
					GetGlobalMouseState (NULL, NULL, NULL, &tmp, NULL, NULL);
				}
				
				
				if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIX_X_POS, MicronixPOS_Query(X_AXIS)); //updates the display.
				Delay(USB_COM_DELAY);
				if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIX_Y_POS, MicronixPOS_Query(Y_AXIS)); //updates the display.  
				Delay(USB_COM_DELAY);
				if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIXZPOS, MicronixPOS_Query(Z_AXIS)); //updates the display.
				SetMouseCursor(VAL_DEFAULT_CURSOR); 
				
				if (Micronix_STATUS<0)  MicronixErrorProcedure();
				
		break;
	
	
	
	}
	GUI_Thread_Lock =0;
	return 0;
	
}
int CVICALLBACK MicronixPowerOnOff (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			GetCtrlVal(panel,control,&tmp);
			if(tmp) 
			{
				StartMicronixStages();
			}
			else	
			{
				CloseMicronixInstrSession();
				Micronix_STATUS = 0;	
			}
			SetCtrlVal(PanelHandleMain, MAIN_PANEL_MICRONIX_LED, tmp);
			
			break;
	}
	return 0;
}
int CVICALLBACK ChangeMotorIDs (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetMotorsAxisIDs(PanelHandelMicronixSettings,&X_AXIS, &Y_AXIS, &Z_AXIS);
			SetMotorsAxisIDs(X_AXIS, Y_AXIS, Z_AXIS);
			break;
	}
	return 0;
}
int CVICALLBACK ClearErrorMsgBox (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			ResetTextBox (panel, MICRONIX_S_MICRONIX_ERR_MSG, "");
			
			break;
	}
	return 0;
}
int CVICALLBACK fnc_XY_home (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MicronixParam->Axis=X_AXIS;
			Micronix_STATUS = Micronixthreaded(MicronixParam, MOTOR_HOME);
			
			MicronixParam->Axis=Y_AXIS;
			Micronix_STATUS = Micronixthreaded(MicronixParam, MOTOR_HOME);
			break;
	}
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;
}
int CVICALLBACK MicronixSendString (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			char cmd[MAX_MICRONIX_CMD_LEN];
			
			GetCtrlVal(PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_CMD_TEXT, cmd);
			if (Micronix_Online)	MicronixSendCMD(cmd); 
			break;
	}
	return 0;
}
int CVICALLBACK fZPOS_CHK (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_TIMER_TICK:
			ViReal64 output = 0;
			output=MicronixPOS_Query(Z_AXIS);
			SetCtrlVal (PanelHandleMain,MAIN_PANEL_indMICRONIXZPOS, output); //updates the display. 
			break;
			
	}
	return 0;
}
int CVICALLBACK fnc_MicronixSpeed (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(control==MICRONIX_S_XY_SPEED)
			{
				MicronixParam->Axis=X_AXIS;
				GetCtrlVal(panel,control,&MicronixParam->data1);
				Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_SPEED); 
				MicronixParam->Axis=Y_AXIS; 
				Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_SPEED); 
			break;	
			}
			else
			{
				MicronixParam->Axis=Z_AXIS;
				GetCtrlVal(panel,control,&MicronixParam->data1);
				Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_SPEED); 	
			}
			break;
	}
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;
}
int CVICALLBACK fnc_MicronixAcceleration (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			MicronixParam->Axis=X_AXIS;
			GetCtrlVal(panel,control,&MicronixParam->data1);
			Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_ACCELERATION); 
			MicronixParam->Axis=Y_AXIS; 
			Micronix_STATUS=Micronixthreaded(MicronixParam, MOTOR_SET_ACCELERATION); 
			break;
	}
	if (Micronix_STATUS<0) MicronixErrorProcedure();
	return Micronix_STATUS;
}
int fMicronixCenterOnPoint(double xP,double yP)
{
	MicronixParam->Axis=X_AXIS;
	MicronixParam->data1=xP;
	if (Micronix_Online) Micronix_STATUS=Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	
	
	MicronixParam->Axis=Y_AXIS;
	MicronixParam->data1=yP;
	if (Micronix_Online) Micronix_STATUS=Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;
}
int  CVICALLBACK fCenterOnSpot (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			double xi,yi;
			GetCtrlVal (panel, MAIN_PANEL_PLOT1_XPOS, &xi);
			GetCtrlVal (panel, MAIN_PANEL_PLOT1_YPOS, &yi);
			fMicronixCenterOnPoint(xi/1000.0,yi/1000.0);  // Micronix needs the values in mm form
			break;
	}
   return 0;
}
void SaveLocation(int loc,int type)	
{
	switch(type)
	{
		case SCAN_LOC:
			StoredLoc[loc].Scan_Loc.Point_Status = 1;
			if(!Micronix_Online) return;
			StoredLoc[loc].Scan_Loc.X  = MicronixPOS_Query(X_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].Scan_Loc.Y  = MicronixPOS_Query(Y_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].Scan_Loc.Z  = MicronixPOS_Query(Z_AXIS);
			
			
			break;
			
		case BACKGROUND_LOC:
			StoredLoc[loc].BG_Loc.Point_Status = 1;
			if(!Micronix_Online) return;  
			StoredLoc[loc].BG_Loc.X  = MicronixPOS_Query(X_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].BG_Loc.Y  = MicronixPOS_Query(Y_AXIS);
			Delay(USB_COM_DELAY);
			StoredLoc[loc].BG_Loc.Z  = MicronixPOS_Query(Z_AXIS);	
			
			
			break;
	}

}
int MoveToLocation(int loc,int type)
{
	int tmp;
	switch(type)
	{
		case SCAN_LOC:
			if (!StoredLoc[loc].Scan_Loc.Point_Status) return -1;
			MicronixParam->Axis=X_AXIS; 
			MicronixParam->data1=StoredLoc[loc].Scan_Loc.X;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			MicronixParam->Axis=Y_AXIS; 
			MicronixParam->data1=StoredLoc[loc].Scan_Loc.Y;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_STORELOC_Z_MOVE,&tmp);
			if (tmp)
			{
				MicronixParam->Axis=Z_AXIS; 
				MicronixParam->data1=StoredLoc[loc].Scan_Loc.Z+AF_Z_Offset;
				Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			}
			break;
			
		case BACKGROUND_LOC:
			if (!StoredLoc[loc].BG_Loc.Point_Status) return -1;  
			MicronixParam->Axis=X_AXIS; 
			MicronixParam->data1=StoredLoc[loc].BG_Loc.X;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			MicronixParam->Axis=Y_AXIS; 
			MicronixParam->data1=StoredLoc[loc].BG_Loc.Y;
			Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_STORELOC_Z_MOVE,&tmp);
			if (tmp)
			{
				MicronixParam->Axis=Z_AXIS; 
				MicronixParam->data1=StoredLoc[loc].BG_Loc.Z+AF_Z_Offset;
				Micronix_STATUS = Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
			}
			break;
	}
	
	if (Micronix_STATUS<0)  MicronixErrorProcedure();
	return Micronix_STATUS;

		
}
void ResetStoredLocationButtonColors(void )
{
	
	int color[NUMBER_OF_STORED_LOCATIONS][2]={0},k;
	
	for (k=1;k<NUMBER_OF_STORED_LOCATIONS;k++)
	{
		if(StoredLoc[k].Scan_Loc.Point_Status) 	color[k][0] = VAL_YELLOW ;	
		else	color[k][0] = 0x00FF9900 ;				
		if(StoredLoc[k].BG_Loc.Point_Status) 	color[k][1] = VAL_YELLOW ;
		else color[k][1] =  0x00FF9900 ;				 
	}
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_1, 	ATTR_CMD_BUTTON_COLOR, color[1][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG1, 	ATTR_CMD_BUTTON_COLOR, color[1][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_2, 	ATTR_CMD_BUTTON_COLOR, color[2][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG2, 	ATTR_CMD_BUTTON_COLOR, color[2][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_3, 	ATTR_CMD_BUTTON_COLOR, color[3][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG3, 	ATTR_CMD_BUTTON_COLOR, color[3][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_4,	 	ATTR_CMD_BUTTON_COLOR, color[4][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG4, 	ATTR_CMD_BUTTON_COLOR, color[4][1]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_5, 	ATTR_CMD_BUTTON_COLOR, color[5][0]);
	SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_STORED_LOC_BG5, 	ATTR_CMD_BUTTON_COLOR, color[5][1]);
}

int CVICALLBACK fStoredLocEvent (int panel, int control, int event, void *callbackData, int eventData1, int eventData2) //This function called when clicking 1-5 or bg 1-5 locations in order to save or move to location
{
	switch (event)
	{
		case EVENT_COMMIT:
			int loc,type,saveORmove,tmp=0;
			loc=GetLocationTypeandNum_FromControl(control);
			type = loc%10;
			loc  = loc/10;
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_SAVE_MOVE_CHK,&saveORmove);
			
			
			if (loc==-1)
			{
				char str[50]="MAIN_PANEL_STORED_LOC_", strBG[50]="MAIN_PANEL_STORED_LOC_BG",numStr[5]="", crlSTR[50]="";
				for (tmp=1;tmp<6;tmp++)
				{
					sprintf(numStr, "%d", tmp);		
					strcpy(crlSTR,  strcat (str, numStr));
					SetCtrlAttribute (PanelHandleMain, crlSTR, ATTR_CMD_BUTTON_COLOR, VAL_RED);
					strcpy(crlSTR,  strcat (strBG, numStr));  
					SetCtrlAttribute (PanelHandleMain, crlSTR, ATTR_CMD_BUTTON_COLOR, VAL_RED);	
					StoredLoc[tmp].Scan_Loc.Point_Status = 0; 
					StoredLoc[tmp].BG_Loc.Point_Status   = 0;
				}
				return 0;
			}
			
			switch (saveORmove)
			{
				case VAL_SAVE:
					SaveLocation(loc,type);
					SetCtrlAttribute (panel, control, ATTR_CMD_BUTTON_COLOR, VAL_YELLOW);
					break;
					
				case VAL_MOVE:
					if (Micronix_Online) tmp= MoveToLocation(loc,type);
					if(tmp<0) return -1;
					ResetStoredLocationButtonColors();
					SetCtrlAttribute (panel, control, ATTR_CMD_BUTTON_COLOR, VAL_DK_GREEN); 
					break;
					
			}
	}
	return 0;
}

int CVICALLBACK fnc_MicronixPID_SET (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			double  P_PID,I_PID,D_PID=0.0;
			
			
			GetCtrlVal (PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_PID_P, &P_PID);
			GetCtrlVal (PanelHandelMicronixSettings, MICRONIX_S_MICRONIX_PID_I, &I_PID);  
			
			MicronixParam->Axis=MICRONIX_ALL_AXES;      
			MicronixParam->data1=P_PID;	
			MicronixParam->data2=I_PID;	
			MicronixParam->data3=D_PID;	
			Micronixthreaded(MicronixParam, MOTOR_SET_PID);			
			break;
	}
	return 0;
}
int CVICALLBACK f_Focus_Swing (int panel, int control, int event, void *callbackData, int eventData1, int eventData2) //This functions can do wabble to the focus.
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			int i,j;
			double Zinitial=0.0;
			Zinitial=MicronixPOS_Query(Z_AXIS);
			Delay(USB_COM_DELAY);
			for(i=0;i<30;i++)
				for(j=-10;j<10;j++)
				{
					MicronixParam->Axis=Z_AXIS;
					MicronixParam->data1=Zinitial+j/20000.0;
					Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
					Delay(0.05);
				}
	
			MicronixParam->Axis=Z_AXIS;
			MicronixParam->data1=Zinitial;
			Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	
		break;
	}
	return 0;
}
double fAF_Transmission(void)
{
int freq,samps, AF_type,maxSteps=80;
	int i,i_max=0;
	DAQtaskData data;
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'};
    TaskHandle 	 AFdaqTask=NULL;
	double pointdata,MaxVal;
	double  Zinitial,ZmaxReading, stepSize;
    int StepSizeInt=100; //100nm step
	
	data.maxIn=10;
	freq=200000;
	samps=4500;
	
	//GetCtrlVal(PanelHandleMain, MAIN_PANEL_AF_STEP_SIZE , &StepSizeInt);	
	stepSize=1.0*StepSizeInt/1000000; //50nm in mm.
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AF_TRANSMISSION , data.DevID);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AF_METHOD , &AF_type);	
	
	
	Zinitial=PI_POS_Query(PI_AXIS);
	ZmaxReading=Zinitial;
	
	   
	DAQmxErrChk(DAQmxCreateTask("AF_Task", &AFdaqTask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (AFdaqTask, data.DevID,  "AF_Chan", DAQmx_Val_RSE, -data.maxIn, data.maxIn, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (AFdaqTask, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	DAQmxStartTask(AFdaqTask);
	GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata,0);
	DAQmxStopTask(AFdaqTask);
	MaxVal=pointdata; 

	
	for(i=1;i<=maxSteps;i++)
	{
		PI_Param->data1=Zinitial+stepSize*i;
		PI_threaded(PI_Param,PI_MOVE_ABS);

		DAQmxErrChk (DAQmxStartTask(AFdaqTask));
		GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata,0);
		DAQmxStopTask(AFdaqTask);
			
		if(AF_type==AF_ON_MAX)
		{
			if( (pointdata)>=(MaxVal))
			{
				ZmaxReading= PI_Param->data1; //PI_POS_Query(PI_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if((i-i_max)>4) break;	
		}
		else
		{
			if(fabs(pointdata)>=fabs(MaxVal))
			{
				ZmaxReading=PI_Param->data1;// PI_POS_Query(PI_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if((i-i_max)>4) break;	
		}
	}
	for(i=-1;i>=-maxSteps;i--)
	{
		PI_Param->data1=Zinitial+stepSize*i;
		PI_threaded(PI_Param,PI_MOVE_ABS);

		DAQmxErrChk (DAQmxStartTask(AFdaqTask));
		GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata,0);
		DAQmxStopTask(AFdaqTask);
		
		if(AF_type==AF_ON_MAX)
		{
			if( (pointdata)>=(MaxVal))
			{
				ZmaxReading=PI_Param->data1;  //PI_POS_Query(PI_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if(abs(i-i_max)>4) break;	
		}
		else
		{
			if( fabs(pointdata)>=fabs(MaxVal))
			{
				ZmaxReading=PI_Param->data1;  //PI_POS_Query(PI_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if(abs(i-i_max)>4) break;	
		}
		
	}
	
	PI_Param->data1=ZmaxReading;
	PI_threaded(PI_Param,PI_MOVE_ABS);
//	if (PI_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indPI_POS, PI_POS_Query(PI_AXIS)); //updates the display.
	
	DAQmxClearTask (AFdaqTask);
	
	return (ZmaxReading-Zinitial);
		
		

Error:

	PI_Param->data1=Zinitial;
	PI_threaded(PI_Param,PI_MOVE_ABS);
	
	if( DAQmxFailed (error) )
		DAQmxGetExtendedErrorInfo(errBuff,2048);
	if( AFdaqTask!=0 ) 
		DAQmxStopTask(AFdaqTask);
		DAQmxClearTask (AFdaqTask);
		
	if( DAQmxFailed (error) )
		MessagePopup("DAQmx Error",errBuff);
	return 0.0;
}

double f_AutoFocus(void)
{
	int freq,samps, AF_type,maxSteps=150;
	int i,i_max=0;
	DAQtaskData data;
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'};
    TaskHandle 	 AFdaqTask=NULL;
	double pointdata,MaxVal,tmpData;
	double  Zinitial,ZmaxReading, stepSize;
    int StepSizeInt,kk,cycls=4;
	
	data.maxIn=10;
	freq=200000;
	samps=4000;
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_AF_STEP_SIZE , &StepSizeInt);	
	stepSize=1.0*StepSizeInt/1000000; //20nm in mm.
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_AF_CHANNEL , data.DevID);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AF_METHOD , &AF_type);	
	
	
	Zinitial=MicronixPOS_Query(Z_AXIS);
	ZmaxReading=Zinitial;
	MicronixParam->Axis=Z_AXIS;
	   
	DAQmxErrChk(DAQmxCreateTask("AF_Task", &AFdaqTask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (AFdaqTask, data.DevID,  "AF_Chan", DAQmx_Val_RSE, -data.maxIn, data.maxIn, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (AFdaqTask, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	tmpData=0.0;
	for (kk=0; kk<cycls;kk++)
	{
		DAQmxStartTask(AFdaqTask);
		GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata,0);
		DAQmxStopTask(AFdaqTask);
		tmpData=pointdata/cycls;
	}
	pointdata=tmpData;
	MaxVal=pointdata; 

	
	for(i=1;i<=maxSteps;i++)
	{
		MicronixParam->data1=Zinitial+stepSize*i;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);

		tmpData=0.0;
		for (kk=0; kk<cycls;kk++)
		{
			DAQmxErrChk (DAQmxStartTask(AFdaqTask));
			GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata,0);
			DAQmxStopTask(AFdaqTask);
			tmpData=pointdata/cycls;
		}
		pointdata=tmpData;
	
		if(AF_type==AF_ON_MAX)
		{
			if( (pointdata)>=(MaxVal))
			{
				ZmaxReading=MicronixPOS_Query(Z_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if((i-i_max)>4) break;	
		}
		else
		{
			if(fabs(pointdata)>=fabs(MaxVal))
			{
				ZmaxReading=MicronixPOS_Query(Z_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if((i-i_max)>4) break;	
		}
	}
	for(i=-1;i>=-maxSteps;i--)
	{
		MicronixParam->data1=Zinitial+stepSize*i;
		Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);

		tmpData=0.0;
		for (kk=0; kk<cycls;kk++)
		{
			DAQmxErrChk (DAQmxStartTask(AFdaqTask));
			GetDataFromDAQ(AFdaqTask, 1, samps, &pointdata,0);
			DAQmxStopTask(AFdaqTask);
			tmpData=pointdata/cycls;
		}
		pointdata=tmpData;
		
		if(AF_type==AF_ON_MAX)
		{
			if( (pointdata)>=(MaxVal))
			{
				ZmaxReading=MicronixPOS_Query(Z_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if(abs(i-i_max)>4) break;	
		}
		else
		{
			if( fabs(pointdata)>=fabs(MaxVal))
			{
				ZmaxReading=MicronixPOS_Query(Z_AXIS);
				MaxVal=pointdata;
				i_max=i;
			}
			else
				if(abs(i-i_max)>4) break;	
		}
		
	}
	
	AF_Z_Offset=ZmaxReading-Zinitial;
	
	MicronixParam->data1=ZmaxReading;
	Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	if (Micronix_Online) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indMICRONIXZPOS, MicronixPOS_Query(Z_AXIS)); //updates the display.
	
	DAQmxClearTask (AFdaqTask);
	
	return (ZmaxReading-Zinitial);
		
		

Error:

	MicronixParam->data1=Zinitial;
	Micronixthreaded(MicronixParam,MOTOR_MOVE_ABS);
	
	if( DAQmxFailed (error) )
		DAQmxGetExtendedErrorInfo(errBuff,2048);
	if( AFdaqTask!=0 ) 
		DAQmxStopTask(AFdaqTask);
		DAQmxClearTask (AFdaqTask);
		
	if( DAQmxFailed (error) )
		MessagePopup("DAQmx Error",errBuff);
	return 0.0;
}

int CVICALLBACK AutoFocusButton (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	
	int af_mode;
	switch (event)
	{
		case EVENT_COMMIT:
		
		SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_AUTOFOCUS_BUTTON, ATTR_DIMMED, 1);
		GetCtrlVal (PanelHandleMain, MAIN_PANEL_AF_ON_SCAN, &af_mode);
		
		if(af_mode!=6){
			f_AutoFocus();
		
			if (TRANSMISSION_MODE) fAF_Transmission();
		}
		else
		{
			Move_Micronix_Af(simple_Equated_AF());		
		}
		SetCtrlAttribute (PanelHandleMain, MAIN_PANEL_AUTOFOCUS_BUTTON, ATTR_DIMMED, 0); 
	}
	return 0;
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			PEM				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK fPEM_Control (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	if(PEM_ONLINE) 
	{
		switch (event)
		{
			case EVENT_COMMIT:
					int tmp,ret;
					switch (control)
					{
						case MOD_SETTIN_PEM_ON_OFF:
							GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_ON_OFF,&PEM_STATUS);
							if(PEM_STATUS)
							{
								GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&ret); 
								PEM_change_R(ret);
								Delay(0.25); 
								GetCtrlVal(PanelHandleMain,MAIN_PANEL_WAVELENGTH_INDICATOR,&tmp);  
								if(tmp) PEM_change_Wavelength(tmp,ret);
								Delay(0.25);
								PEM_STATUS=1;
								ModulationFlag=1;
							}
							else
							{
								PEM_change_R(0);
								Delay(0.25);  //Make sure No modulation is on
								//Close_PEM_port_RS232() ;
								PEM_STATUS=0;
								ModulationFlag=0;
							}
						break;
					
						case MOD_SETTIN_PEM_RETARDANCE: 
							if(PEM_STATUS)
							{
								GetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_PEM_RETARDANCE,&tmp); 
								PEM_change_R(tmp);
								
							}
						break;
					
					}
				break;
		}
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			DAQ				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
 int CVICALLBACK DAQ_stateChange (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int group1=0, group2=0, activChanSeq[MAX_DAQ_AI_CHAN]={0};
			
			GetNumberOfActiveChannelsInEachGroup(PanelHandelDAQsettings, &group1, &group2, activChanSeq);
			if(group1) SetCtrlAttribute (PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP1, ATTR_MAX_VALUE, DAQ_MAX_SAMPLE_RATE/group1 );
			if(group2) SetCtrlAttribute (PanelHandelDAQsettings, DAQ_SETTI_AI_SAMPLE_RATE_GROUP2, ATTR_MAX_VALUE, DAQ_MAX_SAMPLE_RATE/group2 ); 
			UpdatePlotListControl(activChanSeq, PanelHandleMain, PanelHandelGraph2);
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			Power Balance     /////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int f_rotate_wheel_home(void )
{
	long tmp=0;
	if(!Rotation_Online)  return -1;
	MG17MotorLib__DMG17MotorMoveHome (rotorStageHandle, NULL, 0, VFALSE, &tmp);
	
	return 0;
}

int f_rotate_wheel(double StepSize)
{
	long tmp=0;
	if(!Rotation_Online)  return -1;
	MG17MotorLib__DMG17MotorMoveRelativeEx (rotorStageHandle, NULL, 0, StepSize, 0, VTRUE, &tmp);
	return 0;
}
int SetPowerBalance(double tolerance)  //This function is being called in line 1890 by BG_PowerBalance Function
{
		
	int freq,samps,maxSteps=30;
	int counter=0,tmp;
	DAQtaskData data[2];
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'},tmpStr[3];
    TaskHandle 	 PowerDAQtask=NULL;
	double pointdata[2],delta,lvalue;
	double  stepSize;
	int RotateDirection=1,DeltaSign,DeltaSignLast;


	  
	data[0].maxIn=10; // define the maximum voltage expected from the daq
	data[1].maxIn=10; // define the maximum voltage expected from the daq
	freq=100000; // Sampling rate per second per channel
	samps=1500; // maximum samplings per channel until end of task.
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_REF_CHANNEL , &tmp);
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_DAQ_BALANCE_CHAN , data[1].DevID); //The following lines are used to create the name of the channel. Which for our case is the reference channel. 
	strcpy(data[0].DevID,data[1].DevID);
	data[0].DevID[7]='\0';
	sprintf(tmpStr,"%d",tmp); // Adds the tmp value to tmpStr	
	strcat(data[0].DevID,tmpStr); // Concatenate tmpStr to the DevID.
	
	DAQmxErrChk(DAQmxCreateTask("PowerBalanceTask", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, data[0].DevID,  "RefChan", DAQmx_Val_RSE, -data[0].maxIn, data[0].maxIn, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, data[1].DevID,  "TargetChan", DAQmx_Val_RSE, -data[1].maxIn, data[1].maxIn, DAQmx_Val_Volts, ""));
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, freq, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	do
	{
		
		DAQmxStartTask(PowerDAQtask);
		GetDataFromDAQ(PowerDAQtask, 2, samps, pointdata,0);	
		DAQmxStopTask(PowerDAQtask); 
		if(fabs(pointdata[0])>7)  f_rotate_wheel(RotateDirection*10);
	}while(pointdata[0]>9.5); 
	stepSize = 3;

	
	if (USNIG_NIRVANA_PHOTODIODE) 
	{
		delta=pointdata[1];
		DeltaSignLast=(delta/fabs(delta));
		if (fabs(delta)>1.5)   stepSize = 10;
		else if  (fabs(delta)>0.5)    stepSize = 5; 
	}
	else
	{
		delta=(GetBalanceValFromData(pointdata[1],pointdata[0]));
		DeltaSignLast=(delta/fabs(delta));
		if (fabs(delta)>2)   stepSize = 45;
		else if  (fabs(delta)>1)    stepSize = 25; 	
	}

	if( fabs(delta)<fabs(tolerance)) {DAQmxClearTask(PowerDAQtask);  return 0;}
	lvalue=fabs(delta);
	do 
	{
		f_rotate_wheel(stepSize*RotateDirection);
		
		DAQmxStartTask(PowerDAQtask);
		GetDataFromDAQ(PowerDAQtask, 2, samps, pointdata,0);
		DAQmxStopTask(PowerDAQtask);
		
		delta=GetBalanceValFromData(pointdata[1],pointdata[0]);
		DeltaSign=(delta/fabs(delta)); 
		if(DeltaSign!=DeltaSignLast) RotateDirection=-RotateDirection;
		else if(fabs(delta)>lvalue) RotateDirection=-RotateDirection;
		
		DeltaSignLast=DeltaSign;
		stepSize=stepSize/1.5;
		counter++;
		delta=fabs(delta);
		lvalue=delta;
	} while( fabs(delta)>fabs(tolerance) && counter<maxSteps && stepSize>0.014);	
	
	SetCtrlVal (PanelHandleMain, MAIN_PANEL_BALANCE_ERR, DeltaSign*delta); 
	DAQmxClearTask(PowerDAQtask); 
	
	if (fabs(delta)>fabs(tolerance)*4 && USNIG_NIRVANA_PHOTODIODE) {DAQmxClearTask(PowerDAQtask);  return -3;}
	if (fabs(delta)>fabs(tolerance)) {DAQmxClearTask(PowerDAQtask);  return -1;} 
	
Error:
	
	DAQmxClearTask(PowerDAQtask);
	
	return 0;
	
}



int CVICALLBACK fSplitPowerBalance (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			double tolerance;
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,&tolerance);
			tmp= SetPowerBalance(tolerance);
		
			if (tmp<0 ) tmp= SetPowerBalance(tolerance);
			if (tmp<-2 ) MessagePopup ("Optimization Failed", "Tolerance value couldn't be met, try ajusting referance beam power level");
			else  MessagePopup ("Optical split tuning", "Done");

			
			break;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////			GUI				//////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
int CVICALLBACK gui_function (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
			switch (control)
				{	
					case MAIN_PANEL_DAQ_SHOW_SETTINGS:
						ShowHidePanel(panel,MAIN_PANEL_DAQ_SHOW_SETTINGS, PanelHandelDAQsettings );
					break;
			
					case MAIN_PANEL_AOTF_SHOW_SETTINGS:
						ShowHidePanel(panel,MAIN_PANEL_AOTF_SHOW_SETTINGS, PanelHandelAOTFSettings );
					break;
			
					case MAIN_PANEL_MICRONIX_SHOW_SETINGS:
						ShowHidePanel(panel,MAIN_PANEL_MICRONIX_SHOW_SETINGS, PanelHandelMicronixSettings ); 
					break;
			
					case MAIN_PANEL_SCAN_SHOW_SETINGS:
						ShowHidePanel(panel,MAIN_PANEL_SCAN_SHOW_SETINGS, PanelHandeladvScanSettings ); 
					break;
			
					case MAIN_PANEL_MODUL_SHOW_SETTINGS:
						ShowHidePanel(panel,MAIN_PANEL_MODUL_SHOW_SETTINGS, PanelHandelmodulationSettings );
					break;
			
					case MAIN_PANEL_STAGES_SHOW_SETTINGS:
						ShowHidePanel(panel,MAIN_PANEL_STAGES_SHOW_SETTINGS, PanelHandelStageSettings );
					break;
			
					case MAIN_PANEL_SECONED_PLOT_OPT:
						ShowHidePanel(panel,MAIN_PANEL_SECONED_PLOT_OPT, PanelHandelGraph2 );
					break;
					
					case MAIN_PANEL_OPEN_STANDA_PNL:
						ShowHidePanel(panel,MAIN_PANEL_OPEN_STANDA_PNL, PanelHandleStanda );
						break;
						
					case DAQ_SETTI_DETECTORE_TOGGLE:
						GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_DETECTORE_TOGGLE,&USNIG_NIRVANA_PHOTODIODE);
						if(USNIG_NIRVANA_PHOTODIODE)
							SetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,0.003);
						else
							SetCtrlVal(PanelHandleMain,MAIN_PANEL_BALANCE_TOLERANCE,0.5);
						
					break;
				}
		break;  
	}
	return 0;
}
int CVICALLBACK gui_function_daq (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
			switch (control)
				{	
					case DAQ_SETTI_CLOSE_DAQ_SETTINGS:
						HidePanelAndChangeToggleState(PanelHandelDAQsettings, PanelHandleMain,MAIN_PANEL_DAQ_SHOW_SETTINGS, STATE_OFF); 
					break;
				}
		break;  
	}
	return 0;
}

int CVICALLBACK gui_function_AOTF (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
				switch (control)
				{	
					case AOTF_SETTI_CLOSE_AOTF_SETTINGS:
						HidePanelAndChangeToggleState(PanelHandelAOTFSettings, PanelHandleMain,MAIN_PANEL_AOTF_SHOW_SETTINGS, STATE_OFF); 
					break;
				}
		break;  
	}
	return 0;
}	
int CVICALLBACK gui_function_Micronix (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
				switch (control)
				{	
					case MICRONIX_S_CLOSE_MICRONIX_SET:
						HidePanelAndChangeToggleState(PanelHandelMicronixSettings, PanelHandleMain,MAIN_PANEL_MICRONIX_SHOW_SETINGS, STATE_OFF); 
					break;
				}
		break;  
	}
	return 0;
}				
		
int CVICALLBACK gui_function_mod (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
				switch (control)
				{	
					case MOD_SETTIN_CLOSE_PEM_SETTINGS:
						HidePanelAndChangeToggleState(PanelHandelmodulationSettings, PanelHandleMain,MAIN_PANEL_MODUL_SHOW_SETTINGS, STATE_OFF); 
					break;
				}
		break;  
	}
	return 0;
}			
int CVICALLBACK gui_function_scansettings (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
				switch (control)
				{	
					case ADV_SCAN_S_CLOSE_DAQ_SETTINGS:
						HidePanelAndChangeToggleState(PanelHandeladvScanSettings, PanelHandleMain,MAIN_PANEL_SCAN_SHOW_SETINGS, STATE_OFF); 
					break;
				}
		break;  
	}
	return 0;
}			
		
int CVICALLBACK gui_function_stage (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
				switch (control)
				{	
					case STAGE_SETT_CLOSE_STAGE_SETTINGS:
						HidePanelAndChangeToggleState(PanelHandelStageSettings, PanelHandleMain,MAIN_PANEL_STAGES_SHOW_SETTINGS, STATE_OFF); 
					break;
				}
		break;  
	}
	return 0;
}				
int CVICALLBACK gui_function_spctral (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
	
				switch (control)
				{	
					case SPEC_PANEL_CLOSE_GRAPH:
						ShowHidePanel(panel,SPEC_PANEL_CLOSE_GRAPH, PanelHandelSpectrarlChart ); 
					break;
				}
		break;  
	}
	return 0;
}				
			
int CVICALLBACK PlotChannelSelect (int panel, int control, int event,void *callbackData, int eventData1, int eventData2) //This function is the callback function used when selecting different channels to plot on the canvas
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			switch (control)
			{
				case MAIN_PANEL_CHANNEL_PLOT_SELECT_1:
					GetCtrlVal(PanelHandleMain,MAIN_PANEL_CHANNEL_PLOT_SELECT_1,&tmp);
				   	PlotChan=tmp;
				break;
				
				case PLOT_PANEL_CHANNEL_PLOT_SELECT_2:
					GetCtrlVal(PanelHandelGraph2,PLOT_PANEL_CHANNEL_PLOT_SELECT_2,&tmp);
				   	PlotChan2=tmp;
					break;
				
				
				case DAQ_SETTI_REF_CHANNEL:
					GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_REF_CHANNEL,&tmp);
				   	RefChan=tmp;
					break;
			}
	
	}
	return 0;
}

int CVICALLBACK ScaleXY_Graph (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int colormap,scaleFactor;
			int i,j,chan;  
			double min,max;
			double **arr;
			
	
			arr=(double**)malloc((Y_Scan_size)*sizeof(double*));
			for (i=0;i<Y_Scan_size;i++)	arr[i]=(double*)calloc(X_Scan_size,sizeof(double)); 
			
			GetCtrlVal(panel,MAIN_PANEL_MAX_SCALE,&max);
			GetCtrlVal(panel,MAIN_PANEL_MIN_SCALE,&min);

			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_PLOT_COLORMAP,&colormap);
			
			LoadColormap( colormap,  max,  min); 
			PlotScaleBar( PanelHandleMain,  MAIN_PANEL_XY_SCAN_PLOT_SCALE_1); 
				
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
					arr[i][j]=GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan],MAIN_PANEL_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan] );
			
			scaleFactor=GetScaleFactor();
			UpdateGraph(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, arr, X_Scan_size,  Y_Scan_size,  scaleFactor);
			
			
			for (i=0;i<Y_Scan_size;i++)	free(arr[i]);  
			free(arr);
			
			break;
	}
	return 0;
}
int CVICALLBACK ScaleXY_Graph2 (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	if(PlotChan2<0) return 0;
	switch (event)
	{
		case EVENT_COMMIT:
			int colormap,scaleFactor;
			int i,j,chan;  
			double min,max;
			double **arr;
			
	
			arr=(double**)malloc((Y_Scan_size)*sizeof(double*));
			for (i=0;i<Y_Scan_size;i++)	arr[i]=(double*)calloc(X_Scan_size,sizeof(double)); 
			
			GetCtrlVal(panel,PLOT_PANEL_MAX_SCALE,&max);
			GetCtrlVal(panel,PLOT_PANEL_MIN_SCALE,&min);
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_PLOT_COLORMAP,&colormap);

			LoadColormap2( colormap,  max,  min); 
			PlotScaleBar( PanelHandelGraph2,  PLOT_PANEL_XY_SCAN_PLOT_SCALE_2); 
				
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
					arr[i][j]=GetDisplayValFromData(XYarray[i][j].data[PlotChan2],XYarray[i][j].data[RefChan],SECONDARY_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan2] );
			
			scaleFactor=GetScaleFactor();
			UpdateGraph(PanelHandelGraph2, PLOT_PANEL_XY_SCAN_PLOT_2, arr, X_Scan_size,  Y_Scan_size,  scaleFactor);
			
			
			for (i=0;i<Y_Scan_size;i++)	free(arr[i]);  
			free(arr);
			
			break;
	}
	return 0;
}
int CVICALLBACK AutoScaleXY_Graph (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)	// This function is being called when I click AutoScale.
{
	switch (event)
	{
		case EVENT_COMMIT:
			int colormap,scaleFactor;
			int i,j,chan;  
			double min,max,min2,max2;
			double **arr;
			double aux;
	
			arr=(double**)malloc((Y_Scan_size)*sizeof(double*)); // Define a matrix in the size of Y_scan_size*x_scan_size
			for (i=0;i<Y_Scan_size;i++)	arr[i]=(double*)calloc(X_Scan_size,sizeof(double)); 
			
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_PLOT_COLORMAP,&colormap);
		
			
			max2=max=-1000;
			min2=min=1000;
				
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++)  
				{
					aux=GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan],MAIN_PANEL_IMAGE,BackgroundVals[RefChan] ,BackgroundVals[PlotChan]);
					if (max<aux) max= aux;
					if (min>aux) min= aux;
					if(PlotChan2>=0)
					{
						aux=GetDisplayValFromData(XYarray[i][j].data[PlotChan2],XYarray[i][j].data[RefChan],SECONDARY_IMAGE,BackgroundVals[RefChan] ,BackgroundVals[PlotChan2] );
						if (max2<aux) max2=	aux;
						if (min2>aux) min2=	aux;	
					}
				}
			if(max>0) max=max*1.05; 	  else max=max-(max*0.05);
			if(min>0) min=min-(min*0.05); else min=min*1.05;
			if(max2>0) max2=max2*1.05; 	  else max2=max2-(max2*0.05);
			if(min2>0) min2=min2-(min2*0.05); else min2=min2*1.05;
						
			scaleFactor=GetScaleFactor();  
//Update Main Panel Graph//
			
			LoadColormap( colormap,  max,  min); 
			PlotScaleBar( PanelHandleMain,  MAIN_PANEL_XY_SCAN_PLOT_SCALE_1); 
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
					arr[i][j]=GetDisplayValFromData(XYarray[i][j].data[PlotChan],XYarray[i][j].data[RefChan],MAIN_PANEL_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan] );
			
			UpdateGraph(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, arr, X_Scan_size,  Y_Scan_size,  scaleFactor);
			
//Update Secondary Panel Graph//			
			
			if(PlotChan2>=0)
			{  
			LoadColormap2( colormap,  max2,  min2); 
			PlotScaleBar( PanelHandelGraph2,  PLOT_PANEL_XY_SCAN_PLOT_SCALE_2); 
			
			for(i=0;i<Y_Scan_size;i++)
				for(j=0;j<X_Scan_size;j++) 
					arr[i][j]=GetDisplayValFromData(XYarray[i][j].data[PlotChan2],XYarray[i][j].data[RefChan],SECONDARY_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan2] );
			
			UpdateGraph(PanelHandelGraph2, PLOT_PANEL_XY_SCAN_PLOT_2, arr, X_Scan_size,  Y_Scan_size,  scaleFactor);
			}
			
			//free resources///
			for (i=0;i<Y_Scan_size;i++)	free(arr[i]);  
			free(arr);
			
			break;
	}
return 0;
}

void fUpdateTimeEst(void)
{
	double time,stepTime,delayTime,XstepSize,Xsize,YstepSize,Ysize;
	int numPoints;
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_X,&XstepSize); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_X_SIZE,&Xsize);
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_Y,&YstepSize); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_Y_SIZE,&Ysize);
	numPoints=(1+RoundRealToNearestInteger(Xsize/XstepSize))*(1+RoundRealToNearestInteger(Ysize/YstepSize));
	
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_TIME,&stepTime); 
	GetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_DELAY,&delayTime);
	
	time=(stepTime/1000.0 +delayTime/1000.0 +USB_COM_DELAY)*numPoints/60/60;
	SetCtrlVal(PanelHandleMain, MAIN_PANEL_EST_SCAN_TIME,time);	
}

int CVICALLBACK UpdateScanTime (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			fUpdateTimeEst();
			break;
	}
	return 0;
}

int CVICALLBACK StepSizeChange (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp;
			double stepSize;
			
			GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_ENABLE_UNIQUE_STEP_XY ,&tmp);
			if (!tmp)
			{
				GetCtrlVal(panel,control ,&stepSize); 
				SetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_X,stepSize);
				SetCtrlVal(PanelHandleMain, MAIN_PANEL_STEP_SIZE_Y,stepSize);
			}
			fUpdateTimeEst();
			break;
	}
	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

int CVICALLBACK f_samps_chan_change (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK f_in_scan_corrections (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK ChangeMicronixIO_Out (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			break;
	}
	return 0;
}

int CVICALLBACK fCanvasPointPress (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	
	int xi,yi,xi2=-1,yi2=-1,tmp,Scaling,xtmp,ytmp,boundsCHK=1;
	switch (event)
	{
		case EVENT_LEFT_CLICK:
			
			
			
			GetRelativeMouseState (panel, MAIN_PANEL_XY_SCAN_PLOT_1, &xi, &yi, NULL, NULL, NULL); 
			Scaling=GetScaleFactor();
			if(!Scaling) return -1;
			xtmp=xi/Scaling;
			ytmp=yi/Scaling;

			SetCtrlAttribute (panel, MAIN_PANEL_XY_SCAN_PLOT_1, ATTR_PEN_COLOR, MakeColor(255,255,255));
  			CanvasDrawPoint  (panel, MAIN_PANEL_XY_SCAN_PLOT_1, MakePoint(xi,yi));
			
			if (xtmp>=X_Scan_size)
			{
				MessagePopup ("Out of scan Area", "Chosen point X value is out of the scan area");
				boundsCHK=0;
			}
			if (ytmp>=Y_Scan_size)
			{
				MessagePopup ("Out of scan Area", "Chosen point Y value is out of the scan area");
				boundsCHK=0;
			}
			if (xtmp<0)
			{
				MessagePopup ("Out of scan Area", "Chosen point X value is out of the scan area");
				boundsCHK=0;
			}
			if (ytmp<0)
			{
				MessagePopup ("Out of scan Area", "Chosen point Y value is out of the scan area");
				boundsCHK=0;
			}
			if (XYarray && boundsCHK)
			{
				
				SetCtrlVal (panel, MAIN_PANEL_CANVAS_DATA_POINT,GetDisplayValFromData(XYarray[ytmp][xtmp].data[PlotChan],XYarray[ytmp][xtmp].data[RefChan],MAIN_PANEL_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan] ));
				SetCtrlVal (panel, MAIN_PANEL_PLOT1_XPOS,  1000*XYarray[ytmp][xtmp].X_Loc);
				SetCtrlVal (panel, MAIN_PANEL_PLOT1_YPOS,  1000*XYarray[ytmp][xtmp].Y_Loc);
				X_TMP=xtmp;
				Y_TMP=ytmp;
			}

			break;
			
		case EVENT_RIGHT_CLICK: 
			
			GetRelativeMouseState (panel, MAIN_PANEL_XY_SCAN_PLOT_1, &xi, &yi, NULL, &tmp, NULL);
			Scaling=GetScaleFactor();
			if(!Scaling) return -1;
			xtmp=xi/Scaling;
			ytmp=yi/Scaling;
			while(tmp>0)
			{
				GetRelativeMouseState (panel, MAIN_PANEL_XY_SCAN_PLOT_1, &xi2, &yi2, NULL, &tmp, NULL);
			}
			SetCtrlAttribute (panel, MAIN_PANEL_XY_SCAN_PLOT_1, ATTR_PEN_COLOR, MakeColor(255,255,255));
			if (abs(xi-xi2)>abs(yi-yi2))
			{
				double *arr;
				int i,j;
				
				arr=(double*)calloc(X_Scan_size*Scaling,sizeof(double));
				for(i=0;i<X_Scan_size;i++)
					for(j=0;j<Scaling;j++)
						arr[i*Scaling+j]=XYarray[ytmp][i].data[PlotChan]; 
				
				ClearStripChart (PanelHandleMain, MAIN_PANEL_LINECHART);
				
				PlotStripChart (PanelHandleMain, MAIN_PANEL_LINECHART, arr, X_Scan_size*Scaling, 0, 0, VAL_DOUBLE);
			    free(arr);	
				CanvasDrawLine(panel,MAIN_PANEL_XY_SCAN_PLOT_1,MakePoint(xi,yi),MakePoint(xi2,yi)); 
			}
			else
			{
				double *arr;
				int i,j;
				
				arr=(double*)calloc(Y_Scan_size*Scaling,sizeof(double));
				for(i=0;i<Y_Scan_size;i++) 
					for(j=0;j<Scaling;j++) 
						arr[i*Scaling+j]=XYarray[i][xtmp].data[PlotChan]; 
				ClearStripChart (PanelHandleMain, MAIN_PANEL_LINECHART);
				PlotStripChart (PanelHandleMain, MAIN_PANEL_LINECHART, arr, Y_Scan_size*Scaling, 0, 0, VAL_DOUBLE);
			    free(arr);
				CanvasDrawLine(panel,MAIN_PANEL_XY_SCAN_PLOT_1,MakePoint(xi,yi),MakePoint(xi,yi2));
			}
	}
	return 0;
}
double GetDisplayValFromData(double valData, double valRef, int ScanImage, double backRef, double backval)
{
	int Equation;
	
	if (ScanImage==MAIN_PANEL_IMAGE)
		GetCtrlVal(PanelHandelDAQsettings,DAQ_SETTI_EQUATION_SELECT,&Equation);
	else
		GetCtrlVal(PanelHandelGraph2,PLOT_PANEL_EQUATION_SELECT,&Equation);
	
	switch (Equation)
	{
		case EQUATION_LOG:		
			if (valData<=0) return -1000;
			else 		   return 	-log((valRef/valData)); 
		
		case EQUATION_NORMALIZED_LOG:
			if (valData<=0) return -1000;
			else if(backval<=0) return 	-log((valRef/valData));
			else 		   return 	-log((valRef/valData))+log((backRef/backval)); 	
			
			
		case EQUATION_FRACTION:	return 	valData/valRef;
		
		case EQUATION_NONE:		return 	valData;
		
		case EQUATION_TIMES1000:		return 	valData*1000; 
		
		case EQUATION_CH_BG_COR:	return valData-backval;
		
		case EQUATION_CD:	return (valData/valRef-backval/backRef);
		
	}
	return 0;
}
double GetBalanceValFromData(double Target,double ref)
{
	if (USNIG_NIRVANA_PHOTODIODE)  return Target;
	else  return  ref-Target;
}

int CVICALLBACK fMove_pi (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int stepSize,showPos=0;  
			switch(control)
			{
				
				if (GUI_Thread_Lock) return -1;
				else GUI_Thread_Lock =1;
				
				case MAIN_PANEL_PI_DOWN_JOG:
					GetCtrlVal(PanelHandleMain,MAIN_PANEL_PI_STEP_SIZE,&PI_Param->data1);
					PI_Param->data1=-(PI_Param->data1)/1000.0; //Convert um to mm for PI stage input
					PI_Param->Axis=PI_AXIS;
				break;
				
				
				case MAIN_PANEL_PI_UP_JOG:
					GetCtrlVal(PanelHandleMain,MAIN_PANEL_PI_STEP_SIZE,&PI_Param->data1);
					PI_Param->data1=(PI_Param->data1)/1000.0; //Convert um to mm for PI stage input
					PI_Param->Axis=PI_AXIS;

				break;
				
			}
			int tmp=1;   
			while (tmp)
				{
					if (PI_Online)  PI_threaded(PI_Param,PI_MOVE_REL);      	  
					DelayWithEventProcessing(0.1);
					GetGlobalMouseState (NULL, NULL, NULL, &tmp, NULL, NULL);
				}
				
				GetCtrlVal(PanelHandleMain,MAIN_PANEL_PI_POS_CHK,&showPos);   
				if ((PI_Online && showPos)) SetCtrlVal(PanelHandleMain, MAIN_PANEL_indPI_POS, PI_POS_Query(PI_AXIS)); //updates the display.
				SetMouseCursor(VAL_DEFAULT_CURSOR); 
			break;
	}
	GUI_Thread_Lock =0;   
	return 0;
}

int CVICALLBACK fTransmissionState (int panel, int control, int event,
									void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(panel,control,&TRANSMISSION_MODE);
			break;
	}
	return 0;
}


int CVICALLBACK Change_LIA_GPIB_address (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			setup_LIA ( PanelHandelmodulationSettings);
			break;
	}
	return 0;
}
int CVICALLBACK Change_SRS830_LIA_GPIB_address (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SRS830_setup_LIA ( PanelHandelmodulationSettings);
			break;
	}
	return 0;
}


int CVICALLBACK LIA_cmds (int panel, int control, int event,
						  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			switch (control)
			{
				//EGNG LIA
				case MOD_SETTIN_LIA_AUTO_PHASE:
					LIA_AutoPhase();
					break;
					
				case MOD_SETTIN_LIA_AUTO_OFFSET:
					LIA_AutoOffset();
					break;
					
					
				case MOD_SETTIN_LIA_SEND_TEXT:
					char cmd[50]="";
					
					GetCtrlVal(PanelHandelmodulationSettings, MOD_SETTIN_LIA_TEXT_CMD,cmd);
					LIA_SendGPIB_cmd(cmd);
					break;
				//SRS LIA	
				case MOD_SETTIN_SRS830_LIA_AUTO_PHASE:
					SRS830_LIA_AutoPhase();
					break;
					
				case MOD_SETTIN_SRS830LIA_AUTO_OFFSET:
					SRS830_LIA_AutoOffset();
					break;
					
					
				case MOD_SETTIN_SRS830_LIA_SEND_TEXT:
					char cmd2[50]="";
					
					GetCtrlVal(PanelHandelmodulationSettings, MOD_SETTIN_SRS830_LIA_TEXT_CMD,cmd2);
					SRS830_LIA_SendGPIB_cmd(cmd2);
					break;
			
					
			}
			
			
			break;
	}
	return 0;
}

void GetBackgroundValues(void)
{
	double powerTest;
	char daqChan[40]="";
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_0 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	BackgroundVals[0] =powerTest;
		
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_1 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	BackgroundVals[1] =powerTest;
		
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_2 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	BackgroundVals[2] =powerTest;	
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_3 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	BackgroundVals[3] =powerTest;
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_4 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	BackgroundVals[4] =powerTest;
	
	GetCtrlVal(PanelHandelDAQsettings, DAQ_SETTI_AI_CHAN_5 ,daqChan);
	powerTest = ReadDaqChan(daqChan);
	BackgroundVals[5] =powerTest;
	
	if (ModulationFlag)
	{
		if(EGNG_R_chan>=0)  BackgroundVals[EGNG_R_chan] =EGNG_R_Sen_Double *BackgroundVals[EGNG_R_chan]/EGNG_R_FULL_SCALE; 
		
		if(SRS_R_chan>=0)   BackgroundVals[SRS_R_chan] =SRS_R_Sen_Double *BackgroundVals[SRS_R_chan]/SRS_R_FULL_SCALE;   
	}
	
	
}


int CVICALLBACK SetBackgroundValue (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
		
		GetBackgroundValues();
	
		break;
	}
	return 0;
}

int CVICALLBACK fChange_LIA_R_Chan (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_VAL_CHANGED:
			int SourceType,chanNum=0;
			char tmpStr[15]="";
			GetCtrlVal(panel,control,&SourceType);
			if (SourceType!=1 && SourceType!=2) return 0;
			switch (control)
			{
				case DAQ_SETTI_SOURCE_CH_0:
					GetCtrlVal(panel,DAQ_SETTI_AI_CHAN_0,tmpStr);
					chanNum=0;
					break;
				
				case DAQ_SETTI_SOURCE_CH_1:
					GetCtrlVal(panel,DAQ_SETTI_AI_CHAN_1,tmpStr);
					chanNum=1;
					break;
					
				case DAQ_SETTI_SOURCE_CH_2:
					GetCtrlVal(panel,DAQ_SETTI_AI_CHAN_2,tmpStr);
					chanNum=2;
					break;
					
				case DAQ_SETTI_SOURCE_CH_3:
					GetCtrlVal(panel,DAQ_SETTI_AI_CHAN_3,tmpStr);
					chanNum=3;
					break;
					
				case DAQ_SETTI_SOURCE_CH_4:
					GetCtrlVal(panel,DAQ_SETTI_AI_CHAN_4,tmpStr);
					chanNum=4;
					break;
				
				case DAQ_SETTI_SOURCE_CH_5:
					GetCtrlVal(panel,DAQ_SETTI_AI_CHAN_5,tmpStr);
					chanNum=5;
					break;
			}
			if (SourceType==EGNG_R_SOURCE)
			{
				if(EGNG_LIA_Online)
				{
					SetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_EGNG_R_CHAN,tmpStr );
					EGNG_R_chan=chanNum;
					EGNG_R_Sen_Double=EGNG_Read_Sensitivity_Double();
				}   
				else
				{
					MessagePopup ("EGNG offline", "EGNG variable is offline mode");
					
				}
			}
			else if (SourceType==SRS_R_SOURCE) 
			{
				if(SRS_LIA_Online)
				{
					SetCtrlVal(PanelHandelmodulationSettings,MOD_SETTIN_SRS_R_CHAN,tmpStr );
					SRS_R_chan=chanNum;
					SRS_R_Sen_Double=SRS830_Read_Sensitivity_Double(); 
				}
				else
				{
					MessagePopup ("SRS offline", "SRS variable is offline mode");
					
				}
				
			}
			
			break;
	}
	return 0;
}
void Change_LIAs_Sensitivity(void)
{
	if (ModulationFlag && EGNG_Sen_Status) EGNG_Change_SensitivityBy(EGNG_Sen_Status);
	if (ModulationFlag && SRS_Sen_Status)  SRS830_Change_SensitivityBy(SRS_Sen_Status); 
	Read_LIAs_Sensitivity();
	EGNG_Sen_Status=0;
	SRS_Sen_Status=0;
}
void Read_LIAs_Sensitivity(void)// This function is being called by the xy_scan function
{
	if (EGNG_LIA_Online) EGNG_R_Sen_Double=EGNG_Read_Sensitivity_Double();	
	if (SRS_LIA_Online)  SRS_R_Sen_Double=SRS830_Read_Sensitivity_Double();
	
}

int CVICALLBACK fCreateGrapthForPixel (int panel, int control, int event,
									   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			if (X_TMP<0 || Y_TMP<0) return 0;
			
			double *SpectralPointArray[MAX_DAQ_AI_CHAN];
		
			
			break;
	}
	return 0;
}

int CVICALLBACK SimulateUserClick (int panel, int control, int event, void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_TIMER_TICK:
			popup_confirm=1;
			SetCtrlAttribute (panel, USER_PROM_POPUP_TIMER, ATTR_ENABLED, 0);
			SetCtrlAttribute (panel, USER_PROM_POPUP_TIMER_COUNT, ATTR_ENABLED, 0);
			DiscardPanel(panel); 
			break;
		case EVENT_COMMIT:
			popup_confirm=1;
			SetCtrlAttribute (panel, USER_PROM_POPUP_TIMER, ATTR_ENABLED, 0);
			SetCtrlAttribute (panel, USER_PROM_POPUP_TIMER_COUNT, ATTR_ENABLED, 0);
			DiscardPanel(panel);  
			break;
	}
	
	return 0;
}

int CVICALLBACK CounterTick (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_TIMER_TICK:
			int tmp;
			GetCtrlVal(panel, USER_PROM_COUNTDOWN, &tmp);
			SetCtrlVal(panel, USER_PROM_COUNTDOWN, tmp-1);
			break;
	}
	return 0;
}
void ResetAllDAQRelatedVariables(void)
{
	EGNG_R_chan=-1;
	SRS_R_chan=-1;
}
int CVICALLBACK DaqSettingsSaveLoad (int panel, int control, int event,
									 void *callbackData, int eventData1, int eventData2)// This function is being called by the Save Settings and Load Settings cuttons in the DAQ panel. It used to save the settings defined there.
{
	switch (event)
	{
		case EVENT_COMMIT:
			int ind;					
			GetCtrlVal(panel,DAQ_SETTI_SETTINGS_INDEX,&ind);
			switch (control)
			{
						
			case DAQ_SETTI_SAVE_SETTINGS:		
				SavePanelState (panel, "DAQ_Panel_Settings.ini", ind);
				break;
				
				
			case DAQ_SETTI_LOAD_SETTINGS:		
				RecallPanelState(panel,"DAQ_Panel_Settings.ini",ind);
				
				ResetAllDAQRelatedVariables();
				
				fChange_LIA_R_Chan (panel, DAQ_SETTI_SOURCE_CH_0, EVENT_VAL_CHANGED, NULL,0, 0);
				fChange_LIA_R_Chan (panel, DAQ_SETTI_SOURCE_CH_1, EVENT_VAL_CHANGED, NULL,0, 0);
				fChange_LIA_R_Chan (panel, DAQ_SETTI_SOURCE_CH_2, EVENT_VAL_CHANGED, NULL,0, 0);
				fChange_LIA_R_Chan (panel, DAQ_SETTI_SOURCE_CH_3, EVENT_VAL_CHANGED, NULL,0, 0);
				fChange_LIA_R_Chan (panel, DAQ_SETTI_SOURCE_CH_4, EVENT_VAL_CHANGED, NULL,0, 0);
				fChange_LIA_R_Chan (panel, DAQ_SETTI_SOURCE_CH_5, EVENT_VAL_CHANGED, NULL,0, 0);
				
				DAQ_stateChange (panel, 0,EVENT_COMMIT, NULL, 0, 0) ;
				
				break;	
					
			}
			
			break;
	}
	return 0;
}

double AF_Z_Curve_Adjusment(int Wavelength, int AOTF_num, int AF_Curve) //This function returns 0!!!!! XD
{
double AF_Adjusment=0;
	

	if(AOTF_num==VIS)
	{
		if (AF_Curve == AF_CURVE_ASSISTED_X50)
			AF_Adjusment=0*AF_CURVE_VIS_MAIN_WAVELENGTH;	
		if (AF_Curve == AF_CURVE_ASSISTED_X100)
			AF_Adjusment=0*AF_CURVE_VIS_MAIN_WAVELENGTH;
	}
	else if(AOTF_num==NIR)
	{
		if (AF_Curve == AF_CURVE_ASSISTED_X50)
			AF_Adjusment=0*AF_CURVE_NIR_MAIN_WAVELENGTH;		
		if (AF_Curve == AF_CURVE_ASSISTED_X100)
			AF_Adjusment=0*AF_CURVE_NIR_MAIN_WAVELENGTH;		
	}
	else
	{
		if (AF_Curve == AF_CURVE_ASSISTED_X50)
			AF_Adjusment=0*AF_CURVE_NIR2_MAIN_WAVELENGTH;		
		if (AF_Curve == AF_CURVE_ASSISTED_X100)
			AF_Adjusment=0*AF_CURVE_NIR2_MAIN_WAVELENGTH;		
	}
	return AF_Adjusment;
}
void Test_Retardance_vs_Voltage_short(void)
{
	
	int WavelengthStart=470,WavelengthEnd=710,WavelengthJump=5;				//430
	int CurWavelength;
	double Vstart=1.0,Vend=6.8,Vcur,Vjump=0.002;		 //Vjump=0.005   //	1 to 6.5
	double Vlow,Vhigh;
	double **Results,tempData;
	int YPoints,Xpoints;				
	int i,j,k,FirstFlag;
	FILE* resFile;
	char *resFileName;
	SpectralPoint Wpoint={0,0,2500};
	int samps=4000;
	DAQtaskData data[2];
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'},tmpStr[3];
    TaskHandle 	 PowerDAQtask=NULL;
	int DataRepetitions=100;
	double V_RCP,V_LCP;


	
	DAQmxErrChk(DAQmxCreateTask("ReadChan", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, "Dev1/ai4",  "Chan", DAQmx_Val_RSE, -1, 1, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, 250000, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_1,&WavelengthStart);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_1,&WavelengthEnd); 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_1,&WavelengthJump);
	
	/////////////////Create New Result Array and initialize it   //////////////////
	YPoints=RoundRealToNearestInteger(  (Vend-Vstart)/Vjump  )+1; 
	Xpoints=RoundRealToNearestInteger(  (WavelengthEnd-WavelengthStart)/WavelengthJump  )+1;
	
	Results = (double **)malloc(YPoints*sizeof(double*));
	for(i=0;i<YPoints;i++)  
	{
		Results[i] = (double *)calloc (Xpoints, sizeof(double));
	}
	
	GetFileAndFolderNames(PanelHandleMain);
	resFileName = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	f_create_save_file_name(resFileName, 0,".RET_Test");
	MakeFile(resFileName);
	i=0;
	Wpoint.AOTF_num=VIS;
	for (CurWavelength=WavelengthStart; CurWavelength<=WavelengthEnd; CurWavelength+=WavelengthJump)
	{
		j=0; 
		V_RCP=LCRV_Get_Retardation_Voltage(CurWavelength,THREE_QWP_LAMBDA);
		V_LCP=LCRV_Get_Retardation_Voltage(CurWavelength,QWP_LAMBDA);
		Vlow=0.9*LCRV_Get_Retardation_Voltage(CurWavelength,ZERO_LAMBDA);
		Vhigh=1.05*LCRV_Get_Retardation_Voltage(CurWavelength,QWP_LAMBDA);
		
		Wpoint.Wavelength= CurWavelength;
		Wpoint.RF_Power =1500;
		if(CurWavelength>630)
			   Wpoint.RF_Power =1000;
		else if(CurWavelength>600)
			   Wpoint.RF_Power =1300;
		else if(CurWavelength>531)
			   Wpoint.RF_Power =1500;
		else if(CurWavelength>500)
			   Wpoint.RF_Power =1700;
		else if(CurWavelength<499)
			   Wpoint.RF_Power =2000;

		
		SetCurrentWavelength_Const(Wpoint,TRUE);
		FirstFlag=1;
		for	(Vcur=Vstart; Vcur<Vend; Vcur+=Vjump)
		{
			if((Vcur>=Vlow && Vcur<=Vhigh))
			{												   
				if( ((Vcur>=V_RCP-0.07)&&(Vcur<=V_RCP+0.07)) || ((Vcur>=V_LCP-0.07)&&(Vcur<=V_LCP+0.07)))
				{

					if(LCVR_Set_Modulation_V (2, Vcur)==0)
					{
						Delay(0.120);
						for(k=0;k<DataRepetitions;k++)
						{
							DAQmxStartTask(PowerDAQtask);
							GetDataFromDAQ(PowerDAQtask, 1, samps, &tempData,0);	
							DAQmxStopTask(PowerDAQtask);	
							Results[j][i]+=tempData/DataRepetitions;
						}
					}
					else Results[j][i]=-1;
				}
				else
				{
					Results[j][i]=-1;
				}
			
			}
			else Results[j][i]=-1;  
			j++;
			
		}
		i++;
	}
	
	
	LCVR_Set_Modulation_V (2, 0);  
	resFile=fopen(resFileName, "a");	
	fprintf(resFile,"V\\Wavelength\t");
	for (CurWavelength=WavelengthStart; CurWavelength<WavelengthEnd; CurWavelength+=WavelengthJump)  
	{
		fprintf(resFile,"%d\t", CurWavelength);		
	}
	fprintf(resFile,"\n");
	for(i=0;i<YPoints;i++)
	{
		fprintf(resFile,"%lf\t", Vstart+i*Vjump);
		for(j=0;j<Xpoints;j++)
		{
			
			fprintf(resFile,"%lf\t", Results[i][j]);	
		}
		fprintf(resFile,"\n"); 	
	}
	fclose(resFile); 

Error:
	
	DAQmxClearTask(PowerDAQtask);	
}
void Test_Retardance_vs_Voltage_Thorlabs_controller(void)
{
	
	int WavelengthStart=470,WavelengthEnd=710,WavelengthJump=5,Vskip=3;				//430
	int CurWavelength;
	double Vstart=0.5,Vend=6,Vcur,Vjump=0.001,SkipStep;		 //Vjump=0.005   //	1 to 6.5         
	double Vlow,Vhigh;
	double **Results,tempData[2];
	int YPoints,Xpoints;				
	int i,j,k,Counter,FirstFlag,auxloop;
	FILE* resFile;
	char *resFileName;
	SpectralPoint Wpoint={0,0,2500};
	int samps=100;
	DAQtaskData data[2];
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'},tmpStr[3];
    TaskHandle 	 PowerDAQtask=NULL;
	int DataRepetitions=20,nightLoop=0,refJ;
	
	

	for(nightLoop=0;nightLoop<=	0;nightLoop++)
	{
	
	
	SkipStep=Vskip*Vjump;
 
	DAQmxErrChk(DAQmxCreateTask("ReadChan", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, "Dev1/ai2",  "Chan", DAQmx_Val_RSE, -10, 10, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, "Dev1/ai4",  "Chan2", DAQmx_Val_RSE, -10, 10, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, 100000, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));
	DAQmxErrChk(DAQmxCfgInputBuffer (PowerDAQtask, samps)); 

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_1,&WavelengthStart);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_1,&WavelengthEnd); 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_1,&WavelengthJump);
	
	/////////////////Create New Result Array and initialize it   //////////////////
	YPoints=RoundRealToNearestInteger(  (Vend-Vstart)/Vjump  )+1; 
	Xpoints=RoundRealToNearestInteger(  (WavelengthEnd-WavelengthStart)/WavelengthJump  )+1;
	
	Results = (double **)malloc((YPoints+1)*sizeof(double*));
	for(i=0;i<YPoints;i++)  
	{
		Results[i] = (double *)calloc (Xpoints, sizeof(double));
	}
	
	GetFileAndFolderNames(PanelHandleMain);
	resFileName = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	

	f_create_save_file_name(resFileName, nightLoop,".RET_Test");
	MakeFile(resFileName);
	i=0;
	Wpoint.AOTF_num=VIS;
	for (CurWavelength=WavelengthStart; CurWavelength<=WavelengthEnd; CurWavelength+=WavelengthJump)
	{
		j=0;
		Vlow=0.9*LCRV_Get_Retardation_Voltage(CurWavelength,ZERO_LAMBDA);//Vstart;////ZERO_LAMBDA
		Vhigh=1.1*LCRV_Get_Retardation_Voltage(CurWavelength,QWP_LAMBDA);//Vend;//QWP_LAMBDA
		Wpoint.Wavelength= CurWavelength;
		Wpoint.RF_Power =1500;
		if(CurWavelength>694)
			   Wpoint.RF_Power =1200;
		if(CurWavelength>630)
			   Wpoint.RF_Power =1450;
		else if(CurWavelength>600)
			   Wpoint.RF_Power =1500;
		else if(CurWavelength>500)
			   Wpoint.RF_Power =1700;
		else if(CurWavelength<499)
			   Wpoint.RF_Power =2000;

		
		SetCurrentWavelength_Const(Wpoint,TRUE);
		LCVR_Set_Modulation_V (2,Vlow );   		
		Delay(1);
		Vcur=Vlow;
		Counter=0;
		
		THORLABS_test_Seq(Vlow, Vhigh,  350 ,  SkipStep); 
		
		while(Vcur<=Vhigh)
		{
			DAQmxStartTask(PowerDAQtask);
			GetDataFromDAQ_Thorlabs_Cal(PowerDAQtask, 2, samps, tempData,0);
			DAQmxStopTask(PowerDAQtask);
			if(tempData[1]>Vcur-SkipStep/1.6 && tempData[1]<Vcur+SkipStep/1.6 )
			{
				Results[j][i]+=tempData[0];   ///DataRepetitions;   	
				Counter+=1;
				
			}
			
			else
			{
				Results[j][i]=Results[j][i]/ Counter;
				Vcur=Vcur+SkipStep;
				Counter=0; 
				Delay(0.05);
				for(auxloop= j;auxloop<j+Vskip; auxloop++) Results[auxloop][i]=-1;   
				j=auxloop;
				
			}
		}
		for(auxloop= j;auxloop<YPoints; auxloop++) Results[auxloop][i]=-1;
		i++;
	}
	
	LCVR_Set_Modulation_V (2,0 ); 
	

Error:
	
	DAQmxClearTask(PowerDAQtask);
	
	resFile=fopen(resFileName, "a");	
	fprintf(resFile,"V\\Wavelength\t");
	for (CurWavelength=WavelengthStart; CurWavelength<WavelengthEnd; CurWavelength+=WavelengthJump)  
	{
		fprintf(resFile,"%d\t", CurWavelength);		
	}
	fprintf(resFile,"\n");
	for(i=0;i<YPoints;i++)
	{
		fprintf(resFile,"%lf\t", Vstart+i*Vjump);
		for(j=0;j<Xpoints;j++)
		{
			
			fprintf(resFile,"%lf\t", Results[i][j]);	
		}
		fprintf(resFile,"\n"); 	
	}
	fclose(resFile); 
	}
	

	
}

void Test_Retardance_vs_Voltage(void)
{
	
	int WavelengthStart=470,WavelengthEnd=710,WavelengthJump=5,Vskip=2,Vskip_orig;		//skip 2		//430
	int CurWavelength;
	double Vstart=0.5,Vend=6,Vcur,Vjump=0.0025,SkipStep;		 //Vjump=0.0025   //	1 to 6.5         
	double Vlow,Vhigh;
	double **Results,tempData;
	int YPoints,Xpoints;				
	int i,j,k,FirstFlag;
	FILE* resFile;
	char *resFileName;
	SpectralPoint Wpoint={0,0,2500};
	int samps=2000;
	DAQtaskData data[2];
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'},tmpStr[3];
    TaskHandle 	 PowerDAQtask=NULL;
	int DataRepetitions=10,nightLoop=1,refJ;   //DataRep=50;
	double maxVal,maxV,minVal,minV,V_HWP;

	
	Vskip_orig=Vskip;
	
	DAQmxErrChk(DAQmxCreateTask("ReadChan", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, "Dev1/ai2",  "Chan", DAQmx_Val_RSE, -10, 10, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, 250000, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	GetCtrlVal(PanelHandleMain,MAIN_PANEL_MIN_WAVE_1,&WavelengthStart);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_MAX_WAVE_1,&WavelengthEnd); 
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_RESULOTION_WAVE_1,&WavelengthJump);
	
	/////////////////Create New Result Array and initialize it   //////////////////
	YPoints=RoundRealToNearestInteger(  (Vend-Vstart)/Vjump  )+1; 
	Xpoints=RoundRealToNearestInteger(  (WavelengthEnd-WavelengthStart)/WavelengthJump  )+1;
	
	
for(nightLoop=0;nightLoop<50;nightLoop++)
{
	
	
	SkipStep=Vskip_orig/1000.0;
 
	
	
	Results = (double **)malloc(YPoints*sizeof(double*));
	for(i=0;i<YPoints;i++)  
	{
		Results[i] = (double *)calloc (Xpoints, sizeof(double));
	}
	
	GetFileAndFolderNames(PanelHandleMain);
	resFileName = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	

	f_create_save_file_name(resFileName, nightLoop,".RET_Test");
	MakeFile(resFileName);
	i=0;
	Wpoint.AOTF_num=VIS;
	for (CurWavelength=WavelengthStart; CurWavelength<=WavelengthEnd; CurWavelength+=WavelengthJump)
	{
		j=0;
		maxVal=-10;
		minVal=10;
		Vlow=0.5;//0.95*LCRV_Get_Retardation_Voltage(CurWavelength,ZERO_LAMBDA);//Vstart;////ZERO_LAMBDA
		Vhigh=4.5;//1.05*LCRV_Get_Retardation_Voltage(CurWavelength,QWP_LAMBDA);//Vend;//QWP_LAMBDA
		V_HWP= 1.05*LCRV_Get_Retardation_Voltage(CurWavelength,HWP_LAMBDA);
		Wpoint.Wavelength= CurWavelength;
		Wpoint.RF_Power =1500;
		if(CurWavelength>650)
			   Wpoint.RF_Power =600;
		else if(CurWavelength>629)
			   Wpoint.RF_Power =700;
		else if(CurWavelength>614)
			   Wpoint.RF_Power =800;
		else if(CurWavelength>599)
			   Wpoint.RF_Power =900;			 //900
		else if(CurWavelength>574)
			   Wpoint.RF_Power =1200;			//1000
		else if(CurWavelength>549)
			   Wpoint.RF_Power =1500;		   //1200
		else if(CurWavelength>500)
			   Wpoint.RF_Power =1900;		 //1700
		else if(CurWavelength<499)
			   Wpoint.RF_Power =2500;	 //2000

		
		SetCurrentWavelength_Const(Wpoint,TRUE);
		FirstFlag=1;
		for	(Vcur=Vstart; Vcur<Vend; Vcur+=Vjump)
		{
			if (Vcur>V_HWP) Vskip=2*Vskip_orig;
			else		   Vskip=Vskip_orig;
			if((Vcur>=Vlow && Vcur<=Vhigh) && !(j%Vskip))
			{
				if(LCVR_Set_Modulation_V (2, Vcur)==0)
				{
					if(FirstFlag) {Delay(0.3); FirstFlag=0; }
					Delay(0.06);
					for(k=0;k<DataRepetitions;k++)
					{
						DAQmxStartTask(PowerDAQtask);
						GetDataFromDAQ(PowerDAQtask, 1, samps, &tempData,0);	
						DAQmxStopTask(PowerDAQtask);	
						Results[j][i]+=tempData/DataRepetitions;
					}
					if(maxVal< Results[j][i]) {maxVal= Results[j][i];maxV=Vcur; }
					if(minVal> Results[j][i]) {minVal= Results[j][i];minV=Vcur; } 
				}
				else Results[j][i]=-1;
			
			}
			else Results[j][i]=-1;  
			j++;
			
		}
		
/*		//Refine around maximum
		LCVR_Set_Modulation_V (2, maxV) ;
		Delay(0.1) ;
		FirstFlag=1;
		refJ=(maxV-Vstart-SkipStep)/Vjump;
		for (Vcur=maxV-SkipStep; Vcur<maxV+SkipStep; Vcur+=2*Vjump)   
		{
			
			if(LCVR_Set_Modulation_V (2, Vcur)==0)
			{
				if(FirstFlag) {Delay(0.2); FirstFlag=0; }
				Delay(0.05);
				Results[refJ][i]=0;
				for(k=0;k<DataRepetitions*5;k++)
					{
						DAQmxStartTask(PowerDAQtask);
						GetDataFromDAQ(PowerDAQtask, 1, samps, &tempData,0);	
						DAQmxStopTask(PowerDAQtask);	
						Results[refJ][i]+=tempData/(DataRepetitions*5);
					}
			}
			else Results[refJ][i]=-1;
			refJ=refJ+2;
		}
		
		
		//Refine around min
		LCVR_Set_Modulation_V (2, minV) ;
		Delay(0.1) ;
		FirstFlag=1;
		refJ=(minV-Vstart-2*SkipStep)/Vjump;
		for (Vcur=minV-2*SkipStep; Vcur<minV+2*SkipStep; Vcur+=Vjump)   
		{
			
			if(LCVR_Set_Modulation_V (2, Vcur)==0)
			{
				if(FirstFlag) {Delay(0.2); FirstFlag=0; }
				Delay(0.05);
				Results[refJ][i]=0;
				for(k=0;k<DataRepetitions*5;k++)
					{
						DAQmxStartTask(PowerDAQtask);
						GetDataFromDAQ(PowerDAQtask, 1, samps, &tempData,0);	
						DAQmxStopTask(PowerDAQtask);	
						Results[refJ][i]+=tempData/(DataRepetitions*5);
					}
			}
			else Results[refJ][i]=-1;
			refJ++;
		}
		*/
		i++;
		LCVR_Set_Modulation_V (2,Vlow ); 
	}
	
	
	 
	resFile=fopen(resFileName, "a");	
	fprintf(resFile,"V\\Wavelength\t");
	for (CurWavelength=WavelengthStart; CurWavelength<WavelengthEnd; CurWavelength+=WavelengthJump)  
	{
		fprintf(resFile,"%d\t", CurWavelength);		
	}
	fprintf(resFile,"\n");
	for(i=0;i<YPoints;i++)
	{
		fprintf(resFile,"%lf\t", Vstart+i*Vjump);
		for(j=0;j<Xpoints;j++)
		{
			
			fprintf(resFile,"%lf\t", Results[i][j]);	
		}
		fprintf(resFile,"\n"); 	
	}
	fclose(resFile); 
} //nightloop
Error:
	
	DAQmxClearTask(PowerDAQtask);
}

void Test_CD_Calibration(void)
{
	
	int WavelengthStart=470,WavelengthEnd=710,WavelengthJump=5;				//430
	int CurWavelength;
	double **Results,tempData;
	int YPoints,Xpoints;				
	int i,j,k;
	FILE* resFile;
	char *resFileName;
	SpectralPoint Wpoint={0,0,2500};
	int samps=2000;
	DAQtaskData data[2];
	int32		 DAQmxError = DAQmxSuccess;
	int32    	 error=0;		
    char       	 errBuff[2048]={'\0'},tmpStr[3];
    TaskHandle 	 PowerDAQtask=NULL;
	int DataRepetitions=50;

	
	DAQmxErrChk(DAQmxCreateTask("ReadChan", &PowerDAQtask)); 
	DAQmxErrChk(DAQmxCreateAIVoltageChan (PowerDAQtask, "Dev1/ai2",  "Chan", DAQmx_Val_RSE, -10, 10, DAQmx_Val_Volts, ""));	
	DAQmxErrChk(DAQmxCfgSampClkTiming (PowerDAQtask, NULL, 250000, DAQmx_Val_Rising, DAQmx_Val_FiniteSamps, samps));		

	
	/////////////////Create New Result Array and initialize it   //////////////////
	YPoints=2; 
	Xpoints=RoundRealToNearestInteger(  (WavelengthEnd-WavelengthStart)/WavelengthJump  )+1;
	
	Results = (double **)malloc(YPoints*sizeof(double*));
	for(i=0;i<YPoints;i++)  
	{
		Results[i] = (double *)calloc (Xpoints, sizeof(double));
	}
	
	GetFileAndFolderNames(PanelHandleMain);
	resFileName = (char *)malloc( MAX_FILE_NAME_LENGTH*sizeof(char));
	f_create_save_file_name(resFileName, 0,".RET_Test");
	MakeFile(resFileName);
	i=0;
	Wpoint.AOTF_num=VIS;
	for (CurWavelength=WavelengthStart; CurWavelength<=WavelengthEnd; CurWavelength+=WavelengthJump)
	{
		j=0; 
		Wpoint.Wavelength= CurWavelength;
		Wpoint.RF_Power =1500;
		if(CurWavelength>650)
			   Wpoint.RF_Power =600;
		else if(CurWavelength>629)
			   Wpoint.RF_Power =700;
		else if(CurWavelength>614)
			   Wpoint.RF_Power =800;
		else if(CurWavelength>599)
			   Wpoint.RF_Power =900;
		else if(CurWavelength>574)
			   Wpoint.RF_Power =1000;
		else if(CurWavelength>549)
			   Wpoint.RF_Power =1200;
		else if(CurWavelength>500)
			   Wpoint.RF_Power =1700;
		else if(CurWavelength<499)
			   Wpoint.RF_Power =2000;
		
		SetCurrentWavelength_Const(Wpoint,TRUE);

		LCRV_Set_Retardation(CurWavelength,THREE_QWP_LAMBDA,LCVR_CHAN);    
		Delay(0.5);
		for(k=0;k<DataRepetitions;k++)
		{
			DAQmxStartTask(PowerDAQtask);
			GetDataFromDAQ(PowerDAQtask, 1, samps, &tempData,0);	
			DAQmxStopTask(PowerDAQtask);	
			Results[j][i]+=tempData/DataRepetitions;
		}
	
		j++;
		
		LCRV_Set_Retardation(CurWavelength,QWP_LAMBDA,LCVR_CHAN);    
		Delay(0.5) ;
		for(k=0;k<DataRepetitions;k++)
		{
			DAQmxStartTask(PowerDAQtask);
			GetDataFromDAQ(PowerDAQtask, 1, samps, &tempData,0);	
			DAQmxStopTask(PowerDAQtask);	
			Results[j][i]+=tempData/DataRepetitions;
		}
		
		
	i++;		
	}
		

	
	LCVR_Set_Modulation_V (2, 0);  
	resFile=fopen(resFileName, "a");	
	fprintf(resFile,"V\\Wavelength\t");
	for (CurWavelength=WavelengthStart; CurWavelength<WavelengthEnd; CurWavelength+=WavelengthJump)  
	{
		fprintf(resFile,"%d\t", CurWavelength);		
	}
	fprintf(resFile,"\n");
	for(i=0;i<YPoints;i++)
	{
		if(!i) fprintf(resFile,"RCP\t");
		else   fprintf(resFile,"LCP\t");
		for(j=0;j<Xpoints;j++)
		{
			
			fprintf(resFile,"%lf\t", Results[i][j]);	
		}
		fprintf(resFile,"\n"); 	
	}
	fclose(resFile); 

Error:
	
	DAQmxClearTask(PowerDAQtask);	
}
int CVICALLBACK TEST_RETARDANCE (int panel, int control, int event,
								 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			
			switch (control)
			{
				case ADV_SCAN_S_CMD_Test_Ret:
					//OPEN_LCVR_port_RS232();
					//Test_Retardance_vs_Voltage_Thorlabs_controller(); 
					 Test_Retardance_vs_Voltage();
					//Close_LCVR_port_RS232();
					MessagePopup ("Ret_Test", "Done");
			
					break;
				
				case ADV_SCAN_S_CMD_Test_Ret_2:
					//OPEN_LCVR_port_RS232();
					Test_Retardance_vs_Voltage_short();
					//Close_LCVR_port_RS232();
					MessagePopup ("Ret_Test", "Done");
			
					break;		
				case ADV_SCAN_S_CD_CAL_TEST:
					Test_CD_Calibration();
					break;
			}
			break;
			
	}
	return 0;
}

int CVICALLBACK Set_Pol_State (int panel, int control, int event,
							   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int wavelength,pol=0;
			double VoltageCase=0.0;
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_WAVELENGTH_INDICATOR,&wavelength);
			
			switch (control)
			{
				case MAIN_PANEL_SET_POL_STATE_1:
					
						GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_1,&pol);
						if(pol<CUSTOM_VOLTAGE)  SetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_1,LCRV_Get_Retardation_Voltage(wavelength, pol) ); 
						else GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_1,&VoltageCase);
					break;
				
				case MAIN_PANEL_SET_POL_STATE_2:
						  GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_2,&pol); 
						 if(pol<CUSTOM_VOLTAGE) SetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_1,LCRV_Get_Retardation_Voltage(wavelength, pol) );
						 else GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_2,&VoltageCase); 
					break;
			}	
			
			if(pol<CUSTOM_VOLTAGE)  LCRV_Set_Retardation(wavelength,pol,LCVR_CHAN);
			else	 				LCVR_Set_Modulation_V (LCVR_CHAN, VoltageCase);
						 
			
			MessagePopup ("Retardance Set", "Done");
			break;
			
	}
	return 0;
}
int CVICALLBACK f_change_spec_pause_state (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(panel,control,&MANUAL_AJUST_ON_NEW_WAVELENGTH);
			
			break;
	}
	return 0;
}

int CD_Scan (void *dat )
{
	FILE *resFiles[MAX_DAQ_AI_CHAN+1]={NULL};
	char **resFileNames=NULL;
	int X_Points, Y_Points;
	int graphScaleFactor,gY=0,gX=0;
	double PlotPointVal=0.0;
	int i,j,k, l, fastMax=0, slowMax=0, Xind=0, Yind=0,z;
	double pointData[MAX_DAQ_AI_CHAN]={0.0};
	XYZ_Point point;
	TaskHandle DAQtask_G1=0,DAQtask_G2=0;
	int nPoints_G1,nPoints_G2,daqAux;
	DAQtaskData *daqData;
	MicronixData *fastData=NULL,*slowData=NULL;
	int32 error=0;
	int32 DAQmxError = DAQmxSuccess;
	double minVal=1000.0,maxVal=-1000.0;
	int aquisitionLoop,PixelLoop,LoopMax;
	int Pol_1,Pol_2;
	double Pol_1_V,Pol_2_V;
	int AF=0;
	
	
	GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_1,&Pol_1_V); 
	GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_2,&Pol_2_V);
	
	//Get POlarization states for alternate scans if needed//
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_1 , &Pol_1);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_2 , &Pol_2);		   
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_CYCLES , &LoopMax);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AF_ON_SCAN , &AF);  

	daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData)); 
	fastData=(MicronixData*)malloc(sizeof(MicronixData));
	slowData=(MicronixData*)malloc(sizeof(MicronixData));

	
	GetScanPointsNumber(&X_Points, &Y_Points, sData.X_Size , sData.X_Step, sData.Y_Size ,sData.Y_Step);
	
	resFileNames=CreateOutPutFiles_XY();
	
	CreateNewResultArray_XY(Y_Points, X_Points);
	 
	Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
	
	graphScaleFactor = GetScaleFactor();
	
	//Raster Scan This creates a matrix of the scan locations//
	GetFastSlowAxesFromScanDirection(&fastMax, &slowMax, fastData, slowData, X_Points, Y_Points, sData); 
	GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,sData.x0, sData.y0 );
	///////////////////////////////////////////////////////////
	

	for(k=0;k<slowMax;k++)
	{
		for(l=0;l<fastMax;l++)
		{											   

			GetArrayIndexFromScanIndexandDirection(&Xind,&Yind,k,l);

			
			if(sData.ScanDir==1 || sData.ScanDir==3)
			{
				slowData->data1 = XYarray[Yind][Xind].X_Loc;   //on YZ scan acts as Z
				fastData->data1 = XYarray[Yind][Xind].Y_Loc;   
			}
			else
			{
				slowData->data1 = XYarray[Yind][Xind].Y_Loc;   //on XZ scan acts as Z 
				fastData->data1 = XYarray[Yind][Xind].X_Loc; 				 
			}
		
			
			if(MOVE_ENABLE) Micronixthreaded(fastData,MOTOR_MOVE_ABS);
			if(!l) 
			{
				if(MOVE_ENABLE) Micronixthreaded(slowData,MOTOR_MOVE_ABS);
				Delay(sData.StepTime/1000); //???????///
				if(AF) 
				{	
					f_AutoFocus();    
					fAF_Transmission();			   //AF Background
				}
					
			}
			//update Scan Location///
			SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_CUR_X_POS, XYarray[Yind][Xind].X_Loc*1000);
			SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_CUR_Y_POS, XYarray[Yind][Xind].Y_Loc*1000);
		
			/////////////////////////
		
			if(sData.StabTime) Delay(sData.StabTime/1000);
			
	
			for(PixelLoop=0; PixelLoop<LoopMax; PixelLoop++)
			{
				if(sData.AI_g1)
				{
					if(Pol_1<CUSTOM_VOLTAGE) LCRV_Set_Retardation(sData.wavelength,Pol_1, LCVR_CHAN);
					else				     LCVR_Set_Modulation_V (LCVR_CHAN, Pol_1_V); 
					
					Delay(0.05);
					if(sData.StabTime) Delay(sData.StabTime/1000);    
					for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles; aquisitionLoop++)   
					{
					
						DAQmxErrChk (DAQmxStartTask(DAQtask_G1));
						GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0);
						DAQmxStopTask(DAQtask_G1);
						AssignDaqDataTo_XYarrayChns(daqData, pointData,1,Yind,Xind,sData.MeasureCycles*LoopMax);
					
					}
					if(Pol_2<CUSTOM_VOLTAGE) LCRV_Set_Retardation(sData.wavelength,Pol_2, LCVR_CHAN);
					else				     LCVR_Set_Modulation_V (LCVR_CHAN, Pol_2_V);   
					Delay(0.05);		
					if(sData.StabTime) Delay(sData.StabTime/1000);    
					for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles; aquisitionLoop++)   
					{
					
						DAQmxErrChk (DAQmxStartTask(DAQtask_G2));
						GetDataFromDAQ(DAQtask_G2,sData.AI_g2 , nPoints_G2, pointData,sData.AI_g1); 
					//	GetDataFromDAQ(DAQtask_G2,sData.AI_g2 , nPoints_G2, pointData,0);
						DAQmxStopTask(DAQtask_G2);
						AssignDaqDataTo_XYarrayChns(daqData, pointData,2,Yind,Xind,sData.MeasureCycles*LoopMax);
					
						
					
					}
			  
				}
	
				///////////////////////////////////////////////////////////
			}
	
 
			
			PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan],XYarray[Yind][Xind].data[RefChan] , MAIN_PANEL_IMAGE ,XYarray[Yind][Xind].data[RefChan+3] , XYarray[Yind][Xind].data[PlotChan+3]);
		
			if(PlotPointVal>maxVal) 
			{
	
					Max_Location.X= XYarray[Yind][Xind].X_Loc;
					Max_Location.Y= XYarray[Yind][Xind].Y_Loc; 
					Max_Location.Z= XYarray[Yind][Xind].Z_Shift; 
					X_Max_Loc_ind =  Xind;
					Y_Max_Loc_ind =  Yind;
					maxVal=XY_ScanMax = PlotPointVal;
			}
			if(PlotPointVal<minVal) 
			{
					Min_Location.X= XYarray[Yind][Xind].X_Loc;
					Min_Location.Y= XYarray[Yind][Xind].Y_Loc; 
					Min_Location.Z= XYarray[Yind][Xind].Z_Shift;
					X_Min_Loc_ind =  Xind;
					Y_Min_Loc_ind =  Yind;
					minVal= XY_ScanMin  = PlotPointVal;
			
			}

				
			
			PlotScanPoint(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, PlotPointVal, Xind, Yind, graphScaleFactor); 
	
			if  (PlotChan2>=0 && PlotChan2<sData.AI_Number)
			{
				PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan2],XYarray[Yind][Xind].data[RefChan], SECONDARY_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan2] ); 
				PlotScanPoint(PanelHandelGraph2, PLOT_PANEL_XY_SCAN_PLOT_2, PlotPointVal, Xind, Yind, graphScaleFactor); 
			}
			
			while (ScanBreak ==SCAN_BREAK_PAUSE){} 
			if(ScanBreak==SCAN_BREAK_STOP) 
			{
				k=slowMax;
				l=fastMax;
			}
		}//fast loop
	} //slow loop

	
//Write data to files
	for(i=0;i<sData.AI_Number;i++) 
	{
			resFiles[i]=fopen(resFileNames[i], "a");
			WriteXY_FileHeader(resFiles[i], i);
			
			fprintf(resFiles[i],"Ypos\\Xpos(um)");
			for(l=0; l<X_Points;l++) fprintf(resFiles[i],"\t%0.8lf", 1000*XYarray[0][l].X_Loc);
			fprintf(resFiles[i],"\n\n");
			
			for(k=0; k<Y_Points;k++)
			{	
				fprintf(resFiles[i],"%0.8lf", 1000*XYarray[k][0].Y_Loc);
				for(l=0; l<X_Points;l++)	
				{
					fprintf(resFiles[i],"\t%0.8lf", XYarray[k][l].data[i]); 
				}
				fprintf(resFiles[i],"\n");
			}
			fclose(resFiles[i]);
	} 
	free(daqData);
	free(fastData);
	free(slowData);
	DAQmxClearTask(DAQtask_G1);
	DAQmxClearTask(DAQtask_G2);
	
	StopScanSequance_XY();
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_START , 0); 
	return 0;	
	
Error:
	
return -1;
}
int CD_Scan_Alt_Full_Scan (void *dat )
{
	FILE *resFiles[MAX_DAQ_AI_CHAN+1]={NULL};
	char **resFileNames=NULL;
	int X_Points, Y_Points;
	int graphScaleFactor,gY=0,gX=0;
	double PlotPointVal=0.0;
	int i,j,k, l, fastMax=0, slowMax=0, Xind=0, Yind=0,z;
	double pointData[MAX_DAQ_AI_CHAN]={0.0};
	XYZ_Point point;
	TaskHandle DAQtask_G1=0,DAQtask_G2=0;
	int nPoints_G1,nPoints_G2,daqAux;
	DAQtaskData *daqData;
	MicronixData *fastData=NULL,*slowData=NULL;
	int32 error=0;
	int32 DAQmxError = DAQmxSuccess;
	double minVal=1000.0,maxVal=-1000.0;
	int aquisitionLoop,ScanLoop,LoopMax;
	int Pol_1,Pol_2,Pol_State=1;
	double Pol_1_V,Pol_2_V;
	int AF=0;
	int SearchType;
	
	
	GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_1,&Pol_1_V); 
	GetCtrlVal(PanelHandeladvScanSettings,ADV_SCAN_S_POL_V_2,&Pol_2_V);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_SEARCH_TYPE_MAX_MIN , &SearchType);

	
	//Get POlarization states for alternate scans if needed//
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_1 , &Pol_1);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_POL_2 , &Pol_2);		   
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_CYCLES , &LoopMax);
	GetCtrlVal(PanelHandleMain,MAIN_PANEL_AF_ON_SCAN , &AF);  

	daqData=(DAQtaskData*)malloc((MAX_DAQ_AI_CHAN)*sizeof(DAQtaskData)); 
	fastData=(MicronixData*)malloc(sizeof(MicronixData));
	slowData=(MicronixData*)malloc(sizeof(MicronixData));

	
	GetScanPointsNumber(&X_Points, &Y_Points, sData.X_Size , sData.X_Step, sData.Y_Size ,sData.Y_Step);
	
	resFileNames=CreateOutPutFiles_XY();
	
	CreateNewResultArray_XY(Y_Points, X_Points);
	 
	Create_ScanXY_DAQtask(&DAQtask_G1, &DAQtask_G2, &nPoints_G1, &nPoints_G2, daqData );
	
	graphScaleFactor = GetScaleFactor();
	
	//Raster Scan This creates a matrix of the scan locations//
	GetFastSlowAxesFromScanDirection(&fastMax, &slowMax, fastData, slowData, X_Points, Y_Points, sData); 
	
	///////////////////////////////////////////////////////////
	
	for(ScanLoop=-1; ScanLoop<LoopMax*2; ScanLoop++)
	{
		minVal=1000.0,maxVal=-1000.0;
		if(ScanLoop<0)GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,sData.x0, sData.y0 );   
		else
		{
			if(SearchType==SEARCH_TYPE_MAX) GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,Max_Location.X, Max_Location.Y ); 
			else		  				    GetScanPointLocations(Y_Points, X_Points, sData.Y_Step, sData.X_Step,Min_Location.X, Min_Location.Y );        
			SetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_CYCLES , ScanLoop); 
		
			if(Pol_State>0)
			{
				if(Pol_1<CUSTOM_VOLTAGE) LCRV_Set_Retardation(sData.wavelength,Pol_1, LCVR_CHAN);
				else				     LCVR_Set_Modulation_V (LCVR_CHAN, Pol_1_V); 
			
			}
			else
			{
				if(Pol_2<CUSTOM_VOLTAGE) LCRV_Set_Retardation(sData.wavelength,Pol_2, LCVR_CHAN);
				else				     LCVR_Set_Modulation_V (LCVR_CHAN, Pol_2_V);   	
			}
			Delay(0.05);//Let LCVR to stabalize
		}
		for(k=0;k<slowMax;k++)
		{
			for(l=0;l<fastMax;l++)
			{											   

				GetArrayIndexFromScanIndexandDirection(&Xind,&Yind,k,l);

			
				if(sData.ScanDir==1 || sData.ScanDir==3)
				{
					slowData->data1 = XYarray[Yind][Xind].X_Loc;   //on YZ scan acts as Z
					fastData->data1 = XYarray[Yind][Xind].Y_Loc;   
				}
				else
				{
					slowData->data1 = XYarray[Yind][Xind].Y_Loc;   //on XZ scan acts as Z 
					fastData->data1 = XYarray[Yind][Xind].X_Loc; 				 
				}
		
			
				if(MOVE_ENABLE) Micronixthreaded(fastData,MOTOR_MOVE_ABS);
				if(!l) 
				{
					if(MOVE_ENABLE) Micronixthreaded(slowData,MOTOR_MOVE_ABS);
					Delay(sData.StepTime/1000); //???????///

					
				}
				if(!k && !l && AF) 
				{	
					f_AutoFocus();    
					fAF_Transmission();
				}
				//update Scan Location///
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_CUR_X_POS, XYarray[Yind][Xind].X_Loc*1000);
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_MICRONIX_CUR_Y_POS, XYarray[Yind][Xind].Y_Loc*1000);
		
				/////////////////////////
		
				if(sData.StabTime) Delay(sData.StabTime/1000);
				if(Pol_State>0)
				{
					for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles; aquisitionLoop++)   
					{
						DAQmxErrChk (DAQmxStartTask(DAQtask_G1));
						GetDataFromDAQ(DAQtask_G1,sData.AI_g1 , nPoints_G1, pointData,0);
						DAQmxStopTask(DAQtask_G1);
						if(ScanLoop>=0) AssignDaqDataTo_XYarrayChns(daqData, pointData,1,Yind,Xind,sData.MeasureCycles*LoopMax);
						else break;
					}
				}  //pol state	  >0
				else
				{
					for(aquisitionLoop=0; aquisitionLoop<sData.MeasureCycles; aquisitionLoop++)   
					{
						DAQmxErrChk (DAQmxStartTask(DAQtask_G2));
						GetDataFromDAQ(DAQtask_G2,sData.AI_g2 , nPoints_G2, pointData,sData.AI_g1); 
						DAQmxStopTask(DAQtask_G2);
						if(ScanLoop>=0) AssignDaqDataTo_XYarrayChns(daqData, pointData,2,Yind,Xind,sData.MeasureCycles*LoopMax);
						else break; 
					}
			     }  //else pol state  <0

				///////////////////////////////////////////////////////////
					
				if  (PlotChan>=0 && PlotChan<sData.AI_Number)
				{					
					if(ScanLoop<0)  PlotPointVal=GetDisplayValFromData(pointData[PlotChan],pointData[RefChan] , MAIN_PANEL_IMAGE ,pointData[RefChan+3] , pointData[PlotChan+3]);
					else 			 PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan],XYarray[Yind][Xind].data[RefChan] , MAIN_PANEL_IMAGE ,XYarray[Yind][Xind].data[RefChan+3] , XYarray[Yind][Xind].data[PlotChan+3]);
				
					PlotScanPoint(PanelHandleMain, MAIN_PANEL_XY_SCAN_PLOT_1, PlotPointVal, Xind, Yind, graphScaleFactor); 
					
				}
				
				if(PlotPointVal>maxVal) 
				{
					Max_Location.X= XYarray[Yind][Xind].X_Loc;
					Max_Location.Y= XYarray[Yind][Xind].Y_Loc; 
					Max_Location.Z= XYarray[Yind][Xind].Z_Shift; 
					X_Max_Loc_ind =  Xind;
					Y_Max_Loc_ind =  Yind;
					maxVal=XY_ScanMax = PlotPointVal;
				}
				if(PlotPointVal<minVal) 
				{
					Min_Location.X= XYarray[Yind][Xind].X_Loc;
					Min_Location.Y= XYarray[Yind][Xind].Y_Loc; 
					Min_Location.Z= XYarray[Yind][Xind].Z_Shift;
					X_Min_Loc_ind =  Xind;
					Y_Min_Loc_ind =  Yind;
					minVal= XY_ScanMin  = PlotPointVal;
				}
				
				while (ScanBreak ==SCAN_BREAK_PAUSE){} 
				if(ScanBreak==SCAN_BREAK_STOP) 
				{
					k=slowMax;
					l=fastMax;
				}
			}//fast loop
		} //slow loop

				
		if  (PlotChan2>=0 && PlotChan2<sData.AI_Number)
		{
			PlotPointVal=GetDisplayValFromData(XYarray[Yind][Xind].data[PlotChan2],XYarray[Yind][Xind].data[RefChan], SECONDARY_IMAGE,BackgroundVals[1] ,BackgroundVals[PlotChan2] ); 
			PlotScanPoint(PanelHandelGraph2, PLOT_PANEL_XY_SCAN_PLOT_2, PlotPointVal, Xind, Yind, graphScaleFactor); 
		}
		if(ScanLoop>=0) Pol_State=-Pol_State;
	}  //scan loop 
	
//Write data to files
	for(i=0;i<sData.AI_Number;i++) 
	{
			resFiles[i]=fopen(resFileNames[i], "a");
			WriteXY_FileHeader(resFiles[i], i);
			
			fprintf(resFiles[i],"Ypos\\Xpos(um)");
			for(l=0; l<X_Points;l++) fprintf(resFiles[i],"\t%0.8lf", 1000*XYarray[0][l].X_Loc);
			fprintf(resFiles[i],"\n\n");
			
			for(k=0; k<Y_Points;k++)
			{	
				fprintf(resFiles[i],"%0.8lf", 1000*XYarray[k][0].Y_Loc);
				for(l=0; l<X_Points;l++)	
				{
					fprintf(resFiles[i],"\t%0.8lf", XYarray[k][l].data[i]); 
				}
				fprintf(resFiles[i],"\n");
			}
			fclose(resFiles[i]);
	} 
	free(daqData);
	free(fastData);
	free(slowData);
	DAQmxClearTask(DAQtask_G1);
	DAQmxClearTask(DAQtask_G2);
	
	StopScanSequance_XY();
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_START , 0);
	SetCtrlVal(PanelHandleMain,MAIN_PANEL_CD_CYCLES , LoopMax);
	return 0;	
	
Error:
	
return -1;
}
int CVICALLBACK f_start_cd_scan (int panel, int control, int event,
								 void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			int tmp,num=0;
			int SearchType;
			GetCtrlVal(panel,control,&tmp);
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_SEARCH_TYPE_MAX_MIN , &SearchType);

			
			if(tmp && !ScanRunning)
			{
				ScanRunning=1;
				
				SetGUI_ForXYScan(PanelHandleMain,PanelHandelGraph2,PlotChan2);
				GetXYScanData( PanelHandleMain);
			
				X_TMP=Y_TMP=-1;
				
				
				if(SearchType==SEARCH_TYPE_MAX || SearchType==SEARCH_TYPE_MIN)
								CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, CD_Scan_Alt_Full_Scan, NULL, &ScanThreadID);
				else
					CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, CD_Scan, NULL, &ScanThreadID);
				
				
				CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, ScanThreadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
				SetGUI_AfterScan(PanelHandleMain);
				
				
				ScanRunning=0;
				ScanBreak=0;
				
				GetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,&num);
				SetCtrlVal(PanelHandleMain,MAIN_PANEL_SCAN_NUMBER,num+1);
				
			}
			else if (tmp && ScanRunning) ScanBreak = 1;
			else if (!tmp && ScanRunning) ScanBreak=0;
			break;
	}
	
	return 0;
}


int CVICALLBACK fnc_change_method (int panel, int control, int event,
								   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(panel,control,&LCRV_CalMethod);
			
			break;
	}
	return 0;
}

int CVICALLBACK fTrackParticle (int panel, int control, int event,
								void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

	
			GetCtrlVal(PanelHandleMain,MAIN_PANEL_PARTICLE_TRACKING,&GlobalTrackingState);
			while (GlobalTrackingState)
			{
				SetMouseCursor (VAL_HOUR_GLASS_CURSOR);
				DelayWithEventProcessing(20);
				OptimizeParticleLocation("Dev1/ai0");
				GetCtrlVal(PanelHandleMain,MAIN_PANEL_PARTICLE_TRACKING,&GlobalTrackingState); 
				 
			}
			SetMouseCursor (VAL_DEFAULT_CURSOR);
			
			
			break;
	}
	return 0;
}

int CVICALLBACK spec_char_cb (int panel, int event, void *callbackData,
							  int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			HidePanel (PanelHandelSpectrarlChart);
			break;
	}
	return 0;
}



